#!/usr/bin/perl

print "Removing old eff* files.\n";
system( "rm -f /home/mccann/public_html/private/efficiencyvslayer/eff{_,underave_}{{2,3,4}{0,1,2,3,4,5,6,7,8,9},ave}{.dat,.dat.noruns}" );
system( "rm -f /home/mccann/public_html/private/efficiencyvslayer/eff_problem{1,2}{.dat,.dat.noruns}" );

foreach $file ( "eff_ave.dat",
                "eff_21.dat", "eff_22.dat", "eff_23.dat", "eff_24.dat",
                "eff_41.dat", "eff_42.dat", "eff_43.dat", "eff_44.dat",
                "eff_25.dat", "eff_26.dat", "eff_27.dat", "eff_28.dat",
                "eff_37.dat", "eff_38.dat", "eff_39.dat", "eff_40.dat",
"effunderave_21.dat", "effunderave_22.dat", "effunderave_23.dat", "effunderave_24.dat",
"effunderave_41.dat", "effunderave_42.dat", "effunderave_43.dat", "effunderave_44.dat",
"effunderave_25.dat", "effunderave_26.dat", "effunderave_27.dat", "effunderave_28.dat",
"effunderave_37.dat", "effunderave_38.dat", "effunderave_39.dat", "effunderave_40.dat",
"eff_problem1.dat", "eff_problem2.dat" )
{
    print "Initiallizing $file with all blanks.\n";
    open( FILE, "> $file" );
    foreach $run ( 103493..107045 )
    {
	print FILE "$run\t0\n";
    }
    close( FILE );
}

# Find all the files
opendir( DIR, "/home/dlk/build/SunOS/Pass1Rzns/" );
@allfiles = readdir( DIR );
@rzn = (); @rzngz = ();
foreach $file ( @allfiles )
{
    if ( $file =~ /^hist_([0-9]{6})\.rzn$/ )
    {
	push( @rzn, $file );
    }
    elsif ( $file =~ /^hist_([0-9]{6})\.rzn\.gz$/ )
    {
	push( @rzngz, $file );
    }
}

# Get the efficiency data for each file
foreach $rznfile ( @rzn )
{
    print "Running PAW to gather data and calculate efficiencies from $rznfile\n";
    $run = substr( $rznfile, 5, 6 ); 
    &makekumac( $rznfile );
    open( PAW, "( cd /home/dlk/build/SunOS/Pass1Rzns/ ; paw < /home/mccann/public_html/private/efficiencyvslayer/tmp.kumac ) |" );
    &getinfo( $run );
    close( PAW );
}

# Decompress and get the efficiency data for each file
foreach $gzfile ( @rzngz )
{
    print "Running gunzip and PAW to gather data and calculate efficiencies from $gzfile\n";
    $run = substr( $gzfile, 5, 6 );
    system( "gunzip -c /home/dlk/build/SunOS/Pass1Rzns/$gzfile > /home/mccann/public_html/private/efficiencyvslayer/hist_tmp.rzn" );
    &makekumac("hist_tmp.rzn");
    open( PAW, "( cd /home/mccann/public_html/private/efficiencyvslayer/ ; paw < tmp.kumac ) |" );
    &getinfo( $run );
    close( PAW );
}

sub makekumac
{
    local( $rzn ) = @_[0];
    open( KUMAC, "> /home/mccann/public_html/private/efficiencyvslayer/tmp.kumac" );
    # The first line defines the "Workstation type"
    print KUMAC "0
h/file 1 $rzn
cdir p1trackmonproc
hist/create/1dhisto 2000 'Efficiency vs. Layer' 47 0.5 47.5
hist/op/div 1002 1003 2000
vect/cr effvsl(47)
hist/get_vect/contents 2000 effvsl
vect/print effvsl
exit
";
    close( KUMAC );
}

sub getinfo
{
    local( $run ) = @_[0];
    $eave = 0;
    $total = 0;

    %e = ();
    while( $_ = <PAW> )
    {
	chop( $_ );
	if ( $_ =~ /EFFVSL\(([ 0-9]{2})\) = ([\.0-9]*)/ )
	{
	    $eave += $2;
	    $total++;

	    $e{$1} = $2;
	}
    }
    $eave /= $total;
    system( "echo '$run\t$eave' >> /home/mccann/public_html/private/efficiencyvslayer/eff_ave.dat" );
    foreach $r ( 21, 22, 23, 24,
		 41, 42, 43, 44,
		 25, 26, 27, 28,
		 37, 38, 39, 40 )
    {
	system( "echo '$run\t$e{$r}' >> /home/mccann/public_html/private/efficiencyvslayer/eff_$r.dat" ) if ( defined( $e{$r} ) && $e{$r} != 0 );
    }
    $problem1 = 0; $p1tot = 0;
    foreach $r ( 21, 22, 23, 24,
		 41, 42, 43, 44 )
    {
	if ( defined( $e{$r} ) && $e{$r} != 0 )
	{
	    $effunderave = $eave - $e{$r};
	    $problem1 += $effunderave;
	    $p1tot++;
	    system( "echo '$run\t$effunderave' >> /home/mccann/public_html/private/efficiencyvslayer/effunderave_$r.dat" );
	}
    }
    $problem2 = 0; $p2tot = 0;
    foreach $r ( 25, 26, 27, 28,
		 37, 38, 39, 40 )
    {
	if ( defined( $e{$r} ) && $e{$r} != 0 )
	{
	    $effunderave = $eave - $e{$r};
	    $problem2 += $effunderave;
	    $p2tot++;
	    system( "echo '$run\t$effunderave' >> /home/mccann/public_html/private/efficiencyvslayer/effunderave_$r.dat" );
	}
    }
    $problem1 /= $p1tot if ( $p1tot != 0 );
    $problem2 /= $p2tot if ( $p2tot != 0 );
    system( "echo '$run\t$problem1' >> /home/mccann/public_html/private/efficiencyvslayer/eff_problem1.dat" );
    system( "echo '$run\t$problem2' >> /home/mccann/public_html/private/efficiencyvslayer/eff_problem2.dat" );

}

# Sorting so that they make nice graphs
foreach $file ( "eff_ave.dat",
	        "eff_21.dat", "eff_22.dat", "eff_23.dat", "eff_24.dat",
	        "eff_41.dat", "eff_42.dat", "eff_43.dat", "eff_44.dat",
	        "eff_25.dat", "eff_26.dat", "eff_27.dat", "eff_28.dat",
	        "eff_37.dat", "eff_38.dat", "eff_39.dat", "eff_40.dat",
"effunderave_21.dat", "effunderave_22.dat", "effunderave_23.dat", "effunderave_24.dat",
"effunderave_41.dat", "effunderave_42.dat", "effunderave_43.dat", "effunderave_44.dat",
"effunderave_25.dat", "effunderave_26.dat", "effunderave_27.dat", "effunderave_28.dat",
"effunderave_37.dat", "effunderave_38.dat", "effunderave_39.dat", "effunderave_40.dat",
"eff_problem1.dat", "eff_problem2.dat" )
{
    print "Sorting file $file by run number.\n";
    %e = ();
    open( FILE, $file );
    while( $_ = <FILE> )
    {
	chop( $_ );
	( $run, $value ) = split( "\t", $_ );
	$e{$run} = $value;
    }
    close( FILE );

    open( FILE, "> $file" );
    open( NORUNS, "> $file.noruns" );
    foreach $run ( sort numly keys %e )
    {
	print FILE "$run\t$e{$run}\n";
	print NORUNS "$e{$run}\n" if ( $e{$run} != 0 );
    }
    close( NORUNS );
    close( FILE );
}

sub numly { $a <=> $b; }

system( "cd $olddir" );
print "All done!\n";
