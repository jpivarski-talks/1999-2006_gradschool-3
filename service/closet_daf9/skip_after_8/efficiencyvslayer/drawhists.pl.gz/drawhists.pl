#!/usr/bin/perl

$lastend = 106891;   # so that I don't rodo old work

$olddir = `pwd`;

# Find all the files
opendir( DIR, "/home/dlk/build/SunOS/Pass1Rzns/" );
@allfiles = readdir( DIR );
@rzn = (); @rzngz = ();
foreach $file ( @allfiles )
{
    if ( $file =~ /^hist_([0-9]{6})\.rzn$/ && $1 > $lastend )
    {
	push( @rzn, $file );
    }
    elsif ( $file =~ /^hist_([0-9]{6})\.rzn\.gz$/ && $1 > $lastend )
    {
	push( @rzngz, $file );
    }
}

# Make postscripts
foreach $rznfile ( @rzn )
{
    $psfile = $rznfile; $psfile =~ s/\.rzn$/.ps/;

    open( PAW, "| ( cd /home/dlk/build/SunOS/Pass1Rzns/ ; paw )" );
  
    # The first line defines the "Workstation type"
    print PAW "0
h/file 1 $rznfile
cdir p1trackmonproc
hist/create/1dhisto 2000 'Efficiency vs. Layer' 47 0.5 47.5
hist/op/div 1002 1003 2000
h/plot 2000

fortran/file 76 /home/mccann/public_html/private/efficiencyvslayer/$psfile
graphics/metafile 76 -111
igset mtype 1
h/plot 2000

exit
";
    close( PAW );
    system( "pstogif -out $psfile.small.gif -depth 1 -density 25 $psfile" );
    system( "pstogif -out $psfile.big.gif -depth 1 -density 50 $psfile" );
    system( "rm $psfile" );
}

# Decompress and make postscripts
foreach $gzfile ( @rzngz )
{
    system( "gunzip -c /home/dlk/build/SunOS/Pass1Rzns/$gzfile > /home/mccann/public_html/private/efficiencyvslayer/hist_tmp.rzn" );

    $psfile = $gzfile; $psfile =~ s/\.rzn\.gz$/.ps/;

    open( PAW, "| ( cd /home/mccann/public_html/private/efficiencyvslayer/ ; paw )" );

    # The first line defines the "Workstation type"
    print PAW "0
h/file 1 hist_tmp.rzn
cdir p1trackmonproc
hist/create/1dhisto 2000 'Efficiency vs. Layer' 47 0.5 47.5
hist/op/div 1002 1003 2000
h/plot 2000

fortran/file 76 /home/mccann/public_html/private/efficiencyvslayer/$psfile
graphics/metafile 76 -111
igset mtype 1
h/plot 2000

exit
";
    close( PAW );
    system( "pstogif -out $psfile.small.gif -depth 1 -density 25 $psfile" );
    system( "pstogif -out $psfile.big.gif -depth 1 -density 50 $psfile" );
    system( "rm $psfile" );
}

system( "cd $olddir" );

