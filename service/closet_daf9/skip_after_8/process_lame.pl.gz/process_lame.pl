#!/usr/bin/perl

format STDOUT_TOP =
   Run Number    Hits per Track   Efficiency vs. Layer
========================================================
.

format STDOUT =
   @|||||||||    @|||||||||||||   @|||||||||||||||||||
$run, $hitsT, $effL
.

$hitsave = 0;
$effLave = 0;
$bothave = 0;
$total = 0;

while( $_ = <> )
{
    chop( $_ );
    ( $run, $hitsT, $effL ) = split( "\t", $_ );
    if ( $run !~ /[^0-9]/ )
    {
	write;

	if ( $hitsT ne "missing" && $effL ne "missing" )
	{
	    if ( $hitsT eq "good" )
	    { $h = 1; }
	    elsif ( $hitsT eq "maybe" )
	    { $h = 0; }
	    else
	    { $h = -1; }
	    
	    if ( $effL eq "good" )
	    { $e = 1; }
	    elsif ( $effL eq "maybe" )
	    { $e = 0; }
	    else
	    { $e = -1; }
	    
	    $hitsave += $h;
	    $effLave += $e;
	    $bothave += $h * $e;
	    $total++;
	}
    }
}

$hitsave /= $total;
$effLave /= $total;
$bothave /= $total;

$cor = $bothave - $hitsave * $effLave;
print "\n
Average Hits: $hitsave
Average EffL: $effLave
 Correlation:  $cor
";
