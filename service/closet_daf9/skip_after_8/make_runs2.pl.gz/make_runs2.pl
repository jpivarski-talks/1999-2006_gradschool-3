#!/usr/bin/perl

while( ($d=<>) !~ /<A NAME="DATA">Run/ )
{ }

while( ($d=<>) !~ /^<TD><FONT SIZE=SMALL>/ )
{ }

while( <> )
{
    $d .= $_;
}

$d =~ s/<\/TD>\n<TD><FONT SIZE=SMALL>/\t/g;
$d =~ s/<TD><FONT SIZE=SMALL>//g;
$d =~ s/<\/TD>\n<\/TR>\n<TR>//g;

print $d . "\n";
