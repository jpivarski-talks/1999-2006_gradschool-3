#!/usr/bin/perl

$max_cols = 3;
$max_rows = 2;    # only relevant for paged data
$spacewidth = 20;
$spaceheight = 20;
$startingrun = 105755;   # this is May 3

%run = ();
%byevents = ();
open( RUNS1, "runs.txt" );
while( $_ = <RUNS1> )
{
    chop( $_ );
    ( $num, $date, $time, $events, $barrelLuminosity, $numBarrelBhabha, $trigger, $detectors, $comments )
	= split( "\t", $_ );
    if ( $num !~ /[^0-9]/ )
    {
#	print "$num\n$date\n$time\n$events\n$trigger\n$comments\n\n";
	$run{$num} = "$date\t$time\t$events\t$trigger\t$comments";
    }

    &fill_byevents( $events );
}
close( RUNS1 );
open( RUNS2, "../runs2.txt" );
while( $_ = <RUNS2> )
{
    chop( $_ );
    ( $num, $disk1, $disk2, $date, $time, $events, $barrelLuminosity, $numBarrelBhabha, $trigger, $detectors, $comments )
	= split( "\t", $_ );
    if ( $num !~ /[^0-9]/ )
    {
#	print "$num\n$date\n$time\n$events\n$trigger\n$comments\n\n";
	$run{$num} = "$date\t$time\t$events\t$trigger\t$comments";
    }

    &fill_byevents( $events );
}
close( RUNS2 );

sub fill_byevents
{
    local( $numEvents ) = @_[0];
    $numEvents =~ s/^\~//;
    $numEvents =~ s/^\&gt\;//;
    if ( $numEvents =~ /k$/ )
    {
	$numEvents =~ s/k$//;
	$numEvents *= 1000;
    }
    if ( $numEvents !~ /[^0-9]/ )
    {
	$byevents{$numEvents} = $num;
    }
}

opendir( DIR, "." );
@files = readdir( DIR );
closedir( DIR );
@known = ();
foreach $file ( @files )
{
    if ( $file =~ /^hist_([0-9]{6})\.ps\.small\.gif$/ && defined($run{$1}) )
    {
	push( @known, $1 );
    }
}

$numplots = 0;
@thingstoplot = ();

open( WEB, "> by_run.html" );
print WEB "<html><title>Distributions of Number of Hits per Track (Sorted by Run)</title>
<body bgcolor=\"#FFFFFF\">
<tt>http://www.lns.cornell.edu/~mccann/private/skipafter8/by_run.html</tt>
<h2>Distributions of Number of Hits per Track</h2>
<center><table width=90%><tr>
  <td align=center>Sorted by Run Number</td>
  <td align=center><a href=\"by_run.1.html\">Sorted by Run Number and Paged</a></td>
  <td align=center><a href=\"by_events.html\">Sort by Number of Events</a></td>
</tr></table><br><img src=\"space.gif\" height=20></center>
";
$col = 1;
foreach $num ( sort( numerical @known ) )
{
    if ( $num > $startingrun )
    {
	$numplots++;
	push( @thingstoplot, $num );

	&drawrunplot( $num );
	
	$col++;
	if ( $col > $max_cols )
	{
	    print WEB "\n<br clear=left><img src=\"space.gif\" height=10><br>\n";
	    $col = 1;
	}
    }
}
print WEB "\n</body></html>\n";
close( WEB );

$numpages = $numplots / ($max_cols*$max_rows);
if ( $numpages != int($numpages) )
{
    $numpages = int($numpages) + 1;
}

$plot = 0;
foreach $page ( 1..$numpages )
{
    open( WEB, "> by_run.$page.html" );
    print WEB "<html><title>Distributions of Number of Hits per Track (Sorted by Run)</title>
<body bgcolor=\"#FFFFFF\">
";
    if ( $page == 1 )
    {
	print WEB "<tt>http://www.lns.cornell.edu/~mccann/private/skipafter8/by_run.$page.html</tt>
<table width=100\%><tr><td align=left><h2>Distributions of Number of Hits per Track</h2></td>
                       <td align=right><h3>Page $page</h3></td></tr></table>
<center><table width=90%><tr>
  <td align=center><a href=\"by_run.html\">Sorted by Run Number</a></td>
  <td align=center>Sorted by Run Number and Paged</td>
  <td align=center><a href=\"by_events.html\">Sort by Number of Events</a></td>
</tr></table></center>
";
    }
    else
    {
	print WEB "
<table width=100\%><tr><td>
";
    }
    print WEB "
<center><table width=80\%><tr><td><b>";
    foreach $p ( 1..$numpages )
    {
	if ( $p != $page )
	{
	    print WEB " <a href=\"by_run.$p.html\">$p</a>";
	}
	else
	{
	    print WEB " [$p]";
	}
    }
    print WEB "</b></td></tr></table></center>
";
    if ( $page == 1 )
    {
	print WEB "<br><img src=\"space.gif\" height=5><br>";
    }
    else
    {
	print WEB "</td><td align=right><h3>Page $page</h3></td></tr></table>";
    }
    $col = 1;
    foreach $i ( 1..6 )
    {
	if ( $plot <= $#thingstoplot )
	{
	    &drawrunplot( $thingstoplot[$plot] );
	    $plot++;
	    
	    $col++;
	    if ( $col > $max_cols )
	    {
		print WEB "\n<br clear=left><img src=\"space.gif\" height=10><br>\n";
		$col = 1;
	    }
	}
    }
    print WEB "\n</body></html>\n";
    close( WEB );
}

open( WEB, "> by_events.html" );
print WEB "<html><title>Distributions of Number of Hits per Track (Sorted by Events)</title>
<body bgcolor=\"#FFFFFF\">
<tt>http://www.lns.cornell.edu/~mccann/private/skipafter8/by_events.html</tt>
<h2>Distributions of Number of Hits per Track</h2>
<center><table width=90\%><tr>
  <td align=center><a href=\"by_run.html\">Sort by Run Number</a></td>
  <td align=center>Sorted by Number of Events</td>
</tr></table><br><img src=\"space.gif\" height=20></center>
";
$col = 1;
foreach $numEvents ( reverse( sort( numerical keys( %byevents ) ) ) )
{
    $num = $byevents{$numEvents};

    if ( &isknown( $num ) )
    {
	&drawrunplot( $num );
	
	$col++;
	if ( $col > $max_cols )
	{
	    print WEB "\n<br clear=left><img src=\"space.gif\" height=$spaceheight><br>\n";
	    $col = 1;
	}
    }
}

sub isknown
{
    local( $num ) = @_[0];

    return 0 if ( $num < $startingrun );

    local( $n );
    foreach $n ( @known )
    {
	return 1 if ( $num == $n );
    }
    return 0;
}

sub drawrunplot
{
    local( $num ) = @_[0];
    local( $date, $time, $events, $trigger, $comments ) = split( "\t", $run{$num} );
    print WEB "
<table align=left>
  <tr><td align=center><b>Run $num</b></td></tr>
  <tr><td align=center><a href=\"hist_$num.ps.big.gif\">
        <img src=\"hist_$num.ps.small.gif\" border=0 width=168 height=170></a></td></tr>
  <tr><td><table width=100\% cellspacing=0 cellpadding=0>
    <tr><td align=center><b>Date</b></td><td align=center><b>Time</b></td><td align=center><b>Events</b></td></tr>
    <tr><td align=center>$date</td><td align=center>$time</td><td align=center>$events</td></tr>
  </table></td></tr>
  <tr><td><table width=168 cellspacing=0 cellpadding=2>
    <tr><td align=left><b>Trigger:</b> $trigger</td></tr>
    <tr><td align=left><b>Comments:</b> $comments</td></tr>
  </table></td></tr>
</table>
<img src=\"space.gif\" width=$spacewidth align=left>
";
}

sub numerical { $a <=> $b; }
