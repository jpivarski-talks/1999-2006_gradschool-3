#!/usr/local/bin/perl

open( LOG, $ARGV[0] );

$minchi2 = 1.E40;
$miniter = 0;
$chi2 = $oldchi2 = 0;
$mean = $oldmean = 0;
$sigma = $oldsigma = 0;
@minimum = @current = @old = ( 0, 0, 0, 0, 0, 0 );
%runnersup = ();
print "All geometry changes reported in microns.\n\n";
print "iteration: west_x, west_y, west_z, east_x, east_y, east_z ;      chi2 ;      mean ;     sigma \n";
print "==============================================================================================\n";

while( $line = <LOG> )
{
    if ( $line =~ /cake ([0-9])/ )
    {
	$whichcake = $1;
    }
    if ( $line =~ /Iteration ([0-9]+): calculating/ )
    {
	$iteration = $1;
    }
    elsif ( $line =~ /west \(X, Y, ROTZ\) = \(([0-9\.\-eE\+]+), ([0-9\.\-eE\+]+), ([0-9\.\-eE\+]+)\)/ )
    {
	$current[0] = $1;
	$current[1] = $2;
	$current[2] = $3;
    }
    elsif ( $line =~ /east \(X, Y, ROTZ\) = \(([0-9\.\-eE\+]+), ([0-9\.\-eE\+]+), ([0-9\.\-eE\+]+)\)/ )
    {
	$current[3] = $1;
	$current[4] = $2;
	$current[5] = $3;
    }
    elsif ( $line =~ /mean norm resid = ([0-9\.\-]+)/ )
    {
	$mean = $1;
    }
    elsif ( $line =~ /sigma norm resid = ([0-9\.]+)/ )
    {
	$sigma = $1;
    }
    elsif ( $line =~ /chi2 \/ dof = ([0-9\.]+)/ )
    {
	$chi2 = $1;
	if ( $minchi2 > $chi2  &&  $chi2 > 0.1 )
	{
	    @minimum = @current;
	    $miniter = $iteration;
	    $minchi2 = $chi2;
	}

	$iterchi2 = sprintf( "%d%03d", $chi2, $iteration );
	$runnersup{$iterchi2} = sprintf( "iter %4d: %7d %7d %7d %7d %7d %7d; %9.1f ; %9.5f ; %9.5f \n",
					 $iteration,
					 $current[0] * 1000000,
					 $current[1] * 1000000,
					 $current[2] * 1000000,
					 $current[3] * 1000000,
					 $current[4] * 1000000,
					 $current[5] * 1000000,
					 $chi2,
					 $mean,
					 $sigma );

	printf( "iter %4d: %7d %7d %7d %7d %7d %7d; %9.1f ; %9.5f ; %9.5f \n",
		$iteration,
		( $current[0] - $old[0] ) * 1000000,
		( $current[1] - $old[1] ) * 1000000,
		( $current[2] - $old[2] ) * 1000000,
		( $current[3] - $old[3] ) * 1000000,
		( $current[4] - $old[4] ) * 1000000,
		( $current[5] - $old[5] ) * 1000000,
		( $chi2 - $oldchi2 ),
		( $mean - $oldmean ),
		( $sigma - $oldsigma ) );
	$oldchi2 = $chi2;
	$oldmean = $mean;
	$oldsigma = $sigma;
	@old = @current;
    }
}

printf( "\nMinimuim chi^2 = $minchi2 at iteration $miniter:

%2d %9.6f %9.6f 0 0 0 %9.6f
%2d %9.6f %9.6f 0 0 0 %9.6f

",      ( $whichcake + 2 ), $minimum[0], $minimum[1], $minimum[2],
	( $whichcake + 10 ), $minimum[3], $minimum[4], $minimum[5] );

foreach $iterchi2 ( sort numly keys %runnersup )
{
    print $runnersup{$iterchi2};
}

sub numly { $a <=> $b; }
