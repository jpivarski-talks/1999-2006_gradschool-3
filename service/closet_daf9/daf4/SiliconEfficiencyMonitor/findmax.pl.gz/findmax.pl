#!/usr/local/bin/perl

open( FF, "fitfunc.dat" );
$max = 0;
while(<FF>)
{
    chop;
   $max = $_ if ( abs($_) > abs($max) );
}
print "$max\n";
