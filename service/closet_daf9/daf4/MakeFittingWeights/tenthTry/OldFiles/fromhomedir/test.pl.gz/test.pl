#!/usr/bin/perl

format STDOUT =
    @>>>>>>>>    @>>>>>>>>    @>> @>>    @||||||||
$value, $backval, $bin, $backbin, $alarm
.

open( FILE, "$ENV{USER_DAF}/MakeFittingWeights/secondTry/hitdata_nozeros.txt" );
$numBins = 10;
$lowerEdge = -1.;
$upperEdge = 1.;
while( <FILE> )
{
    ( $fixedLambda, $layer, $cosTheta, $absDrift, @rest ) = split( "\t", $_ );

    if ( $value != $cosTheta )
    {
	$value = $cosTheta;
	$bin = int( ( ( $value - $lowerEdge ) / ( $upperEdge - $lowerEdge ) )
		   * ( $numBins ) );

	$backval = ( int( $bin ) + 0.5 ) * ( $upperEdge - $lowerEdge ) / ( $numBins )
	    + $lowerEdge;

	$backbin = int( ( ( $backval - $lowerEdge ) / ( $upperEdge - $lowerEdge ) )
		       * ( $numBins ) );

	if ( $backbin != $bin )
	{ $alarm = "ack!"; }
	else { $alarm = ""; }

	write;
    }
}
close( FILE );
