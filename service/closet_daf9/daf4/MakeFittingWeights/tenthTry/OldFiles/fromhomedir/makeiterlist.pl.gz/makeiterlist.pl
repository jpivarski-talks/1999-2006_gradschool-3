#!/usr/bin/perl

if ( $#ARGV == 0 )
{
    $start = $end = $ARGV[0];
}
elsif ( $#ARGV == 1 )
{
    $start = $ARGV[0];
    $end = $ARGV[1];
}
else
{
    die "usage: makeiterlist.pl iternum       where iternum is the number of the iteration.\n";
}

foreach $which ( $start..$end )
{
    open( LAYERIN, "iter$which.drweightlayer" );
    open( LAYEROUT, "> vectlayer$which.txt" );
    while( <LAYERIN> )
    {
	chop;
	( $layer, $lambda ) = split( /\s+/ );
	if ( $layer > 0  &&  $layer < 48  &&  $_ !~ /DEFAULT/  &&  $lambda ne "" )
	{
	    print LAYEROUT "$lambda\n";
	}
    }
    close LAYEROUT;
    close LAYERIN;

    open( THETAIN, "iter$which.drweighttheta" );
    open( THETAOUT, "> vecttheta$which.txt" );
    @thetadep = ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 );
    while( <THETAIN> )
    {
	chop;
	( $index, $layer, $theta, $lambda ) = split( /\s+/ );
	if ( $layer > 0  &&  $layer < 48  &&  $_ !~ /DEFAULT/  &&  $lambda ne "" )
	{
	    $thetadep[ ( $theta - 1 ) ] += $lambda;
	}
    }
    close THETAIN;
    
    foreach $t ( @thetadep )
    {
	print THETAOUT "$t\n";
    }
    close THETAOUT;
    
    open( DRIFTIN, "iter$which.drweightdrift" );
    open( DRIFTOUT, "> vectdrift$which.txt" );
    @driftdep = ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 );
    while( <DRIFTIN> )
    {
	chop;
	( $index, $layer, $drift, $lambda ) = split( /\s+/ );
	if ( $layer > 0  &&  $layer < 48  &&  $_ !~ /DEFAULT/  &&  $lambda ne "" )
	{
	    $driftdep[ ( $drift - 1 ) ] += $lambda;
	}
    }
    close DRIFTIN;
    
    foreach $d ( @driftdep )
    {
	print DRIFTOUT "$d\n";
    }
    close DRIFTOUT;
}

open( KUMAC, "> readvects.kumac" );
foreach $which ( $start..$end )
{
    $layerid = 100 + $which;
    $thetaid = 200 + $which;
    $driftid = 300 + $which;
    print KUMAC "ve/read LAYERITER$which 'vectlayer$which.txt'\n";
    print KUMAC "h/cr/1d $layerid 'iteration $which' 47 0.5 47.5\n";
    print KUMAC "h/put_vect/contents $layerid LAYERITER$which\n";
    print KUMAC "ve/read THETAITER$which 'vecttheta$which.txt'\n";
    print KUMAC "h/cr/1d $thetaid 'iteration $which' 20 -1. 1.\n";
    print KUMAC "h/put_vect/contents $thetaid THETAITER$which\n";
    print KUMAC "ve/read DRIFTITER$which 'vectdrift$which.txt'\n";
    print KUMAC "h/cr/1d $driftid 'iteration $which' 15 0. 1.5\n";
    print KUMAC "h/put_vect/contents $driftid DRIFTITER$which\n";
}
close KUMAC;
