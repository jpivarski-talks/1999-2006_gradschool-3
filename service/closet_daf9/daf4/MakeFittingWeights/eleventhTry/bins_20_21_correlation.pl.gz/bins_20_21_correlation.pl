#!/usr/local/bin/perl

open( HITDATA, "hitdata5.txt" );
open( LOOKATME, "> lookatme_ntuple_opposite_edca.txt" );

$prevcostheta = 0;
$done = 0;
for( $l = 0;  ! $done;  $l++ )
{
    print "on line $l...\n" if ( $l % 1000 == 0 );

    %trackhit = ();

    do {
	$done = 1
	    if ( ! ( $line = <HITDATA> ) );
	
	( $lambda, $layer, $costheta, $absdrift, $dca, $drift, $edca, $edrift )
	    = split( /\t/, $line );

# 	$driftbin = int( $absdrift * 20 + 1 );
#  	if ( $driftbin == 20  ||  $driftbin == 21 )
#  	{
#	    $residual = ( $dca - $drift );
#  	    $normresidual = ( $residual /
#  			      sqrt( $edca * $edca + $edrift * $edrift ) );

	$sign = 1 if ( $drift > 0 );
	$sign = -1 if ( $drift < 0 );

#	$trackhit{$layer}{$sign*$absdrift} = $residual;
	$trackhit{$layer}{$sign*$absdrift} = $edca;
# 	}
    } while ( $costheta == $prevcostheta );
    $prevcostheta = $costheta;

    foreach $layer ( 1..47 )
    {
	@layerNhits = sort numly keys %{ $trackhit{$layer} };

	if ( $#layerNhits == 1  &&  ( $layerNhits[0] * $layerNhits[1] < 0 ) )
	{
	    $small_absdrift = $layerNhits[0];
	    $large_absdrift = $layerNhits[1];

	    print LOOKATME "$layer\t$small_absdrift\t$trackhit{$layer}{$small_absdrift}\t$large_absdrift\t$trackhit{$layer}{$large_absdrift}\n";
	}
    }

}

sub numly { $a <=> $b; }
