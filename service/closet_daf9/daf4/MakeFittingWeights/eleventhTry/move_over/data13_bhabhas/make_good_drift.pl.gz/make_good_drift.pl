#!/usr/local/bin/perl

%fw_before = ();
%fw_after = ();
%fw = ();

open( ITER0, "iter0.drweightdrift" );
while( <ITER0> )
{
    chop;
    my ( $n, $layer, $driftbin, $fw ) = split( /\s+/ );

    if ( $n > 3  &&  $fw ne "" )
    {
	$fw_before{$layer}{$driftbin} = $fw;
    }
}
close( ITER0 );

$n = 0;
open( ITER0, "iter0.drweightlayer" );
while( <ITER0> )
{
    chop;
    my ( $layer, $fw ) = split( /\s+/ );

    if ( $n > 1 )
    {
	foreach my $drifbin ( 1..30 )
	{
	    $fw_before{$layer}{$driftbin} *= $fw;
	}
    }
    $n++;
}
close( ITER0 );

open( ITER6, "iter6.drweightdrift" );
while( <ITER6> )
{
    chop;
    my ( $n, $layer, $driftbin, $fw ) = split( /\s+/ );

    if ( $n >= 3  &&  $fw ne "" )
    {
	$fw_after{$layer}{$driftbin} = $fw;
    }
}
close( ITER6 );

$n = 0;
open( ITER6, "iter6.drweightlayer" );
while( <ITER6> )
{
    chop;
    my ( $layer, $fw ) = split( /\s+/ );

    if ( $n > 1 )
    {
	foreach my $drifbin ( 1..30 )
	{
	    $fw_after{$layer}{$driftbin} *= $fw;
	}
    }
    $n++;
}
close( ITER6 );

foreach my $layer ( 1..47 )
{
    foreach my $driftbin ( 1..30 )
    {
	if ( $driftbin <= 20 )
	{ $fw{$layer}{$driftbin} = $fw_after{$layer}{$driftbin}; }
	elsif ( $driftbin == 21 )
	{ $fw{$layer}{$driftbin} = 3; }
	elsif ( $driftbin == 22 )
	{ $fw{$layer}{$driftbin} = 5; }
	else
	{ $fw{$layer}{$driftbin} = 10; }
    }

    if ( $fw{$layer}{1} < $fw{$layer}{2} )
    {
	$fw{$layer}{1} = ( 2 * $fw{$layer}{2} - $fw{$layer}{3} );
    }
}

open( CONST, "> newconst.drweightdrift" );
print CONST "1 0 0 0 0 0 0 0 DEFAULT
1412
1 48 0 0
2 0 30 1.5
";
$n = 3;
foreach my $layer ( 1..47 )
{
    foreach my $driftbin ( 1..30 )
    {
	print CONST "$n $layer $driftbin $fw{$layer}{$driftbin}\n";
	$n++;
    }
}
close( CONST );

open( CONST, "> newconst.drweightlayer" );
print CONST "1 0 0 0 0 0 0 0 DEFAULT
47
";
foreach my $layer ( 1..47 )
{
    print CONST "$layer 1.0\n";
}
close( CONST );

open( KUMAC, "> newconst.kumac" );
print KUMAC "\n";
foreach my $layer ( 1..47 )
{
    print KUMAC "ve/cr layer$layer(30)\n";
    print KUMAC "ve/inp layer$layer ";
    foreach my $driftbin ( 1..30 )
    {
	print KUMAC "$fw{$layer}{$driftbin} ";
    }
    print KUMAC "\n";
}
print KUMAC "zone 1 2\nopt grid\n";
print KUMAC "null 0. 5. 0. 2.\n";
foreach my $layer ( 1..16 )
{
    print KUMAC "ve/draw layer$layer ! 'ls'\n";
}
print KUMAC "null 0. 5. 0. 2.\n";
foreach my $layer ( 17..47 )
{
    print KUMAC "ve/draw layer$layer ! 'ls'\n";
}
close( KUMAC );
