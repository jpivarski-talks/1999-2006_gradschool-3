#!/usr/local/bin/perl

$length = $ARGV[0];

open( STDIN2, "<&STDIN" );

$count = 0;
$which = 0;
while( <STDIN2> )
{
    if ( $count == 0  &&  $which == 0 )
    {
	open( FILE, "> /cdat/tem/mccann/check_flat_bhabha-a.txt" );
	$which = 1;
    }
    elsif ( $count == 0  &&  $which == 1 )
    {
	open( FILE, "> /cdat/tem/mccann/check_flat_bhabha-b.txt" );
	$which = 0;
    }
    print FILE $_;
    $count++;
    if ( $count == $length )
    {
	$count = 0;
    }
}
