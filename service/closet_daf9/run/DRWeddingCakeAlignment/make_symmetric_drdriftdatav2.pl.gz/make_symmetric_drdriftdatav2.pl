#!/usr/local/bin/perl

%d = ();

open( FILE, $ARGV[0] );
$line1 = <FILE>;
$line2 = <FILE>;
while( $line = <FILE> )
{
    chop $line;
    ( $index, $time, $dist, $layeretc ) = split( /\s+/, $line );
    die if $layeretc !~ /^([0-9]{1,2})00([1-3])0([0-9]{3})$/;
    $layer = $1;
    $func = $2;
    $index2 = $3;
    $d{$layer}{$func}{$time} = $dist;
}
close( FILE );

$index = 0;
foreach $func ( 1..3 )
{
    foreach $layer ( 1..47 )
    {
	$uselayer = $layer;
	$uselayer = 29 if ( $layer == 17 );
	$uselayer = 29 if ( $layer == 21 );
	$uselayer = 29 if ( $layer == 25 );
	$uselayer = 37 if ( $layer == 41 );
	$uselayer = 22 if ( $layer == 26 );
	$uselayer = 22 if ( $layer == 30 );
	$uselayer = 42 if ( $layer == 34 );
	$uselayer = 42 if ( $layer == 38 );
	$uselayer = 42 if ( $layer == 46 );
	$uselayer = 27 if ( $layer == 23 );
	$uselayer = 27 if ( $layer == 31 );
	$uselayer = 39 if ( $layer == 35 );
	$uselayer = 28 if ( $layer == 32 );
	$uselayer = 40 if ( $layer == 36 );

	$index2 = 0;

	%d1plot = %{ $d{$uselayer}{2} };
	%d2plot = %{ $d{$uselayer}{3} };
	@xvals = ();
	foreach $d1x ( sort numly keys %d1plot )
	{ push( @xvals, $d1x ) if ( defined( $d2plot{$d1x} ) ); }
	@yvals = ();
	foreach $x ( @xvals )
	{ push( @yvals, ( ( $d1plot{$x} + $d2plot{$x} ) / 2. ) ); }
	$len = ( $#xvals + 1 );
	
	foreach $x ( @xvals )
	{
	    printf( "%d %g %g %d00%d0%03d\n",
		    ++$index,
		    $x,
		    ( ( $d1plot{$x} + $d2plot{$x} ) / 2. ),
		    $layer,
		    $func,
		    ++$index2 );
	}
    } # end foreach layer
} # end foreach function (symmetric, left, right)


sub numly { $a <=> $b; }
