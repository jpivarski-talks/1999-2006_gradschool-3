#!/usr/local/bin/perl

%d = ();

open( FILE, $ARGV[0] );
$line1 = <FILE>;
$line2 = <FILE>;
while( $line = <FILE> )
{
    chop $line;
    ( $index, $time, $dist, $layeretc ) = split( /\s+/, $line );
    die if $layeretc !~ /^([0-9]{1,2})00([1-3])0([0-9]{3})$/;
    $layer = $1;
    $func = $2;
    $index2 = $3;
    $d{$layer}{$func}{$time} = $dist;
}
close( FILE );

open( PAW, "| paw > /dev/null" );
print PAW "\n";
print PAW "fortran/file 65 '$ARGV[1]'\n";
print PAW "graphics/metafile 65 -111\n";
print PAW "igset mtype 1\n";
print PAW "ve/cr textx(1)\n";
print PAW "ve/cr texty(1)\n";

$file = $ARGV[0];
$file = $1 if ( $file =~ /\/([^\/]+)\.drdriftdatav2$/ );
$file =~ s/\_//g;
print PAW "h/cr/title 'Drift Distance VS. Drift Time for $file'\n";
print PAW "zone 3 4\n";

foreach $layer ( 1..47 )
{
    foreach $func ( 2, 1, 3 )
    {
	$whichfunc = "left" if ( $func == 2 );
	$whichfunc = "symmetric" if ( $func == 1 );
	$whichfunc = "right" if ( $func == 3 );

	%oneplot = %{ $d{$layer}{$func} };
	@xvals = sort numly keys %oneplot;
	@yvals = ();
	foreach $x ( @xvals )
	{ push( @yvals, $oneplot{$x} ); }
	$len = ( $#xvals + 1 );

	if ( $len != 0 )
	{
	    print PAW "ve/cr xvals($len)\n";
	    print PAW "ve/cr yvals($len)\n";
	    $i = 0;
	    do {
		@tmpx = @xvals;
		@tmpy = @yvals;
		@xchunk = splice( @tmpx, $i, 50 );
		@ychunk = splice( @tmpy, $i, 50 );

		if ( $#xchunk != -1 )
		{
		    $lower = ( $i + 1 );
		    $upper = ( $i + 50 );
		    $upper = $len if ( $len < $upper );
		    print PAW "ve/inp xvals($lower:$upper) ".join(" ", @xchunk)."\n";
		    print PAW "ve/inp yvals($lower:$upper) ".join(" ", @ychunk)."\n";
		}
		$i += 50;
	    } while ( $#xchunk != -1 );
#	    print PAW "graph $len xvals yvals\n";
	    print PAW "null 0 300 0 0.008\n";
	    print PAW "graph $len xvals yvals 'P'\n";
	}
	else
	{
	    print PAW "null 0 140 0 0.008\n";
	}
	print PAW "sigma textx = ( \$GRAFINFO('WNXMAX') + \$GRAFINFO('WNXMIN') ) / 2\n";
	print PAW "sigma texty = -0.4 * ( \$GRAFINFO('WNYMAX') - \$GRAFINFO('WNYMIN') )\n";
	print PAW "text \$SIGMA(textx(1)) \$SIGMA(texty(1)) 'layer $layer $whichfunc' ! ! C\n";

    } # end foreach function
} # end foreach layer

print PAW "close 65\n";
print PAW "exit\n";

sub numly { $a <=> $b; }
