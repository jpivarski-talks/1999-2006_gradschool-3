#!/usr/local/bin/perl

%d = ();

open( FILE, $ARGV[0] );
$line1 = <FILE>;
$line2 = <FILE>;
while( $line = <FILE> )
{
    chop $line;
    ( $index, $time, $dist, $layeretc ) = split( /\s+/, $line );
    die if $layeretc !~ /^([0-9]{1,2})00([1-3])0([0-9]{3})$/;
    $layer = $1;
    $func = $2;
    $index2 = $3;
    $d{$layer}{$func}{$time} = $dist;
}
close( FILE );

$index = 0;
foreach $func ( 1..3 )
{
    foreach $layer ( 1..47 )
    {
	$index2 = 0;

	%oneplot = %{ $d{$layer}{1} };
	@xvals = sort numly keys %oneplot;
	$len = ( $#xvals + 1 );
	
	foreach $x ( @xvals )
	{
	    printf( "%d %g %g %d00%d0%03d\n",
		    ++$index,
		    $x,
		    $oneplot{$x},
		    $layer,
		    $func,
		    ++$index2 );
	}
    } # end foreach layer
} # end foreach function (symmetric, left, right)

sub numly { $a <=> $b; }
