#!/usr/local/bin/perl

$name = $ARGV[0];
$length = 10000;

open( STDIN2, "<&STDIN" );

$count = 0;
$which = 0;
$firsttime = 1;

open( STARTFILE, "> $ENV{USER_TMP}/$name\-start.log" );
open( NOTICES, "> $ENV{USER_TMP}/$name\-notices.log" );

while( $line = <STDIN2> )
{
    if ( $count == 0  &&  $which == 0 )
    {
	open( FILE, "> $ENV{USER_TMP}/$name\-a.log" );
	$which = 1;
    }
    elsif ( $count == 0  &&  $which == 1 )
    {
	$firsttime = 0;
	close( STARTFILE );

	open( FILE, "> $ENV{USER_TMP}/$name\-b.log" );
	$which = 0;
    }
    print FILE $line;
    print STARTFILE $line if ( $firsttime == 1 );
    print NOTICES $line if ( substr( $line, 4, 6 ) eq "NOTICE" );
    $count++;
    if ( $count == $length )
    {
	$count = 0;
    }
}
close NOTICES;
close FILE;
