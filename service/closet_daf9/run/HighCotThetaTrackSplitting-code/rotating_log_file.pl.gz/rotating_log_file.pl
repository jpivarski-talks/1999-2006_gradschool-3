#!/usr/local/bin/perl

$length = $ARGV[0];
$name = $ARGV[1];

open( STDIN2, "<&STDIN" );

$count = 0;
$which = 0;
$firsttime = 1;

open( START, "> /cdat/tem/mccann/$name-start.txt" );
open( NTUPLE, "> hold/$name.ntuple" );

while( <STDIN2> )
{
    if ( $count == 0  &&  $which == 0 )
    {
	open( FILE, "> /cdat/tem/mccann/$name-a.txt" );
	$which = 1;
    }
    elsif ( $count == 0  &&  $which == 1 )
    {
	open( FILE, "> /cdat/tem/mccann/$name-b.txt" );
	$which = 0;
	$firsttime = 0;
    }
    print FILE $_;
    print START $_ if ( $firsttime == 1 );
    print NTUPLE substr( $_, 5 ) if ( substr( $_, 0, 5 ) eq "QQQ: " );
    $count++;
    if ( $count == $length )
    {
	$count = 0;
    }
}
