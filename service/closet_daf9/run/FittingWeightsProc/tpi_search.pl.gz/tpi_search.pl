#!/usr/local/bin/perl

$n = $ARGV[0];
$events = 50 * $n * 2;

print "run_file setup_MC_processor.tcl

param FittingWeightsProc tracks_per_iteration $n
param FittingWeightsProc lambdas_from_file false
param FittingWeightsProc lambdas_to_file true
param FittingWeightsProc lambda_outfilename bls_tpi_$n_track_error_cuts.dat
param FittingWeightsProc draw_functions false
param FittingWeightsProc histogram_chi true
param FittingWeightsProc show_on_iteration false
param FittingWeightsProc show_all_on_iteration false

report level DEBUG
go $events
exit
";
