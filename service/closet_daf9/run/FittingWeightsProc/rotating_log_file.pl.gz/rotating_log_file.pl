#!/usr/local/bin/perl

$filename1 = $ARGV[0];
$filename2 = $ARGV[1];
$length = $ARGV[2];

open( STDIN2, "<&STDIN" );

$count = 0;
$which = 0;
while( <STDIN2> )
{
    if ( $_ =~ /Run:\s+[0-9]+\s+Event:\s+([0-9]+)/ )
    {
	$| = 1;
	print "$1\n";
	$| = 0;
    }
    if ( $count == 0  &&  $which == 0 )
    {
	open( FILE, "> /cdat/tem/mccann/$filename1" );
	$which = 1;
    }
    elsif ( $count == 0  &&  $which == 1 )
    {
	open( FILE, "> /cdat/tem/mccann/$filename2" );
	$which = 0;
    }
    print FILE $_;
    $count++;
    if ( $count == $length )
    {
	$count = 0;
    }
}
