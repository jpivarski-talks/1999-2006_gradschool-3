#!/usr/local/bin/perl

open( ITER, "iterated_successfully.txt" );
while( $bin = <ITER> )
{
    chop( $bin );
    open( BIN, "> iterated_rms/bin_$bin.dat" );

    foreach $tpi ( 20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 250, 300 )
    {
	open( PAW, "| paw > tmp.txt" );
	print PAW "0\n";
	print PAW "h/file 1 hist_tpi_$tpi.rzn\n";
	print PAW "cd fittingweightsproc\n";
	print PAW "h/plot " . ( 1000000 + $bin ) . "\n";
	print PAW "message rms for bin is \$HINFO( " . ( 1000000 + $bin ) . ", 'RMS' )\n";
	print PAW "exit";
	close( PAW );

	open( RMS, "tmp.txt" );
	while( <RMS> )
	{
	    chop $_;
	    $_ =~ /rms for bin is ([0-9\.\-\+eE]+)/;
	    $rms = $1;
	}
	print BIN "$tpi\t$rms\n";
    }
}
