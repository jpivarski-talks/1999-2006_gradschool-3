#!/usr/local/bin/perl

foreach $thing ( "xup100um", "xdown100um",
		 "yup100um", "ydown100um",
		 "zup100um", "zdown100um",
		 "phixup1mrad", "phixdown1mrad",
		 "phiyup1mrad", "phiydown1mrad",
		 "phizup1mrad", "phizdown1mrad" )
{
    open( FILE, "CHANGETHIS.run" );
    open( OUT, "> global1_$thing.run" );
    while( <FILE> )
    {
	$_ =~ s/CHANGETHIS/$thing/;
	print OUT $_;
    }
    close OUT;
    close FILE;
}
