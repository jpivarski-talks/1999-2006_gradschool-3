#!/usr/local/bin/perl

$file = $ARGV[0]; @indexes = @ARGV[1..$#ARGV];
@suffix_bits = split( /\./, $file );
$suffix = $suffix_bits[ $#suffix_bits ];

foreach $n ( @indexes )
{
    open( FILE, $file );
    open( XUP,      "> xup100um.$n.$suffix" );
    open( XDOWN,    "> xdown100um.$n.$suffix" );
    open( YUP,      "> yup100um.$n.$suffix" );
    open( YDOWN,    "> ydown100um.$n.$suffix" );
    open( ZUP,      "> zup100um.$n.$suffix" );
    open( ZDOWN,    "> zdown100um.$n.$suffix" );
    open( PHIXUP,   "> phixup1mrad.$n.$suffix" );
    open( PHIXDOWN, "> phixdown1mrad.$n.$suffix" );
    open( PHIYUP,   "> phiyup1mrad.$n.$suffix" );
    open( PHIYDOWN, "> phiydown1mrad.$n.$suffix" );
    open( PHIZUP,   "> phizup1mrad.$n.$suffix" );
    open( PHIZDOWN, "> phizdown1mrad.$n.$suffix" );

    $header = <FILE>;
    $header .= <FILE>;
    while( $line = <FILE> )
    {
	($index, $x, $y, $z, $phix, $phiy, $phiz) = split( /\s+/, $line );
	if ( $index != $n )
	{
	    print XUP $line;
	    print XDOWN $line;
	    print YUP $line;
	    print YDOWN $line;
	    print ZUP $line;
	    print ZDOWN $line;
	    print PHIXUP $line;
	    print PHIXDOWN $line;
	    print PHIYUP $line;
	    print PHIYDOWN $line;
	    print PHIZUP $line;
	    print PHIZDOWN $line;
	}
	else
	{
	    printf XUP      "%d %g %g %g %g %g %g\n", $index, $x+0.0001, $y, $z, $phix, $phiy, $phiz;
	    printf XDOWN    "%d %g %g %g %g %g %g\n", $index, $x-0.0001, $y, $z, $phix, $phiy, $phiz;
	    printf YUP      "%d %g %g %g %g %g %g\n", $index, $x, $y+0.0001, $z, $phix, $phiy, $phiz;
	    printf YDOWN    "%d %g %g %g %g %g %g\n", $index, $x, $y-0.0001, $z, $phix, $phiy, $phiz;
	    printf ZUP      "%d %g %g %g %g %g %g\n", $index, $x, $y, $z+0.0001, $phix, $phiy, $phiz;
	    printf ZDOWN    "%d %g %g %g %g %g %g\n", $index, $x, $y, $z-0.0001, $phix, $phiy, $phiz;
	    printf PHIXUP   "%d %g %g %g %g %g %g\n", $index, $x, $y, $z, $phix+0.001, $phiy, $phiz;
	    printf PHIXDOWN "%d %g %g %g %g %g %g\n", $index, $x, $y, $z, $phix-0.001, $phiy, $phiz;
	    printf PHIYUP   "%d %g %g %g %g %g %g\n", $index, $x, $y, $z, $phix, $phiy+0.001, $phiz;
	    printf PHIYDOWN "%d %g %g %g %g %g %g\n", $index, $x, $y, $z, $phix, $phiy-0.001, $phiz;
	    printf PHIZUP   "%d %g %g %g %g %g %g\n", $index, $x, $y, $z, $phix, $phiy, $phiz+0.001;
	    printf PHIZDOWN "%d %g %g %g %g %g %g\n", $index, $x, $y, $z, $phix, $phiy, $phiz-0.001;
	}
    }

    close( FILE );
    close( XUP );
    close( XDOWN );
    close( YUP );
    close( YDOWN );
    close( ZUP );
    close( ZDOWN );
    close( PHIXUP );
    close( PHIXDOWN );
    close( PHIYUP );
    close( PHIYDOWN );
    close( PHIZUP );
    close( PHIZDOWN );
}
