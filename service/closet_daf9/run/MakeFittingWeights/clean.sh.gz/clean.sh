#! /usr/local/bin/tcsh -f

rm -i $USER_TMP/* ~/fitweights* {generate,process}*.rzn hist.rzn core *~ dafdir/{generate,d0miss,z0miss,resid}*.txt
