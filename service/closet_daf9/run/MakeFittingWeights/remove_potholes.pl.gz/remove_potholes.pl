#!/usr/local/bin/perl

while(<>)
{
    # the first four lines
    if ( $_ =~ /DEFAULT/ )
    { print $_; }
    
    elsif ( $_ !~ / / )
    { print $_; }

    elsif ( $_ =~ /^([0-9]+)/  &&  ( $1 == 1  ||  $1 == 2 ) )
    { print $_; }

    elsif ( $_ =~ /^([0-9]+)\s+([0-9]+)\s+([0-9]+)\s+([0-9\.]+)$/ )
    {
	my ( $index, $layer, $drift, $fw ) = ( $1, $2, $3, $4 );

	if ( $drift == 1 )
	{
	    @line1 = ( $index, $layer, $drift, $fw );
	}

	elsif ( $drift == 2 )
	{
	    @line2 = ( $index, $layer, $drift, $fw );
	}

	elsif ( $drift == 3 )
	{
	    @line3 = ( $index, $layer, $drift, $fw );

	    if ( $line1[ 3 ] < $line2[ 3 ] )
	    {
		# linear extrapolation
		$line1[ 3 ] = ( 2 * $line2[ 3 ] - $line3[ 3 ] );
	    }
	    print ( join( " ", @line1 ) . "\n" );
	    print ( join( " ", @line2 ) . "\n" );
	    print ( join( " ", @line3 ) . "\n" );
	}

	elsif ( $drift == 20 )
	{
	    @line20 = ( $index, $layer, $drift, $fw );
	    print $_;
	}
	
	elsif ( $drift == 21 )
	{
	    @line21 = ( $index, $layer, $drift, $fw );
	}

	elsif ( $drift == 22 )
	{
	    if ( $line20[ 3 ] > $line21[ 3 ] )
	    {
		$line21[ 3 ] = ( ( $line20[ 3 ] + $fw ) / 2 );
		print ( join( " ", @line21 ) . "\n" );
		print $_;
	    }
	    else
	    {
		print ( join( " ", @line21 ) . "\n" );
		print $_;
	    }
	}

	else
	{ print $_; }

    }

    else
    { die "What's this? $_"; }
}
