#!/usr/local/bin/perl

$filebase = $ARGV[0];
$driftbins = $ARGV[1];
$plottitle = $ARGV[2];
%fw = ();

open( CONSTFILE, "$filebase.drweightdrift" );
while( <CONSTFILE> )
{
    chop;
    my ( $n, $layer, $driftbin, $fw ) = split( /\s+/ );

    if ( $n >= 3  &&  $fw ne "" )
    {
	$fw{$layer}{$driftbin} = $fw;
    }
}
close( CONSTFILE );

$n = 0;
open( CONSTFILE, "$filebase.drweightlayer" );
while( <CONSTFILE> )
{
    chop;
    my ( $layer, $fw ) = split( /\s+/ );

    if ( $n > 1 )
    {
	foreach my $drifbin ( 1..$driftbins )
	{
	    $fw{$layer}{$driftbin} *= $fw;
	}
    }
    $n++;
}
close( CONSTFILE );

# open( KUMAC, "> showconst.kumac" );
open( KUMAC, "| paw > /dev/null" );
print KUMAC "\nh/cr/title '$plottitle'\n";
foreach my $layer ( 1..47 )
{
    print KUMAC "ve/cr layer$layer($driftbins)\n";
    print KUMAC "ve/inp layer$layer ";
    foreach my $driftbin ( 1..$driftbins )
    {
	print KUMAC "$fw{$layer}{$driftbin} ";
    }
    print KUMAC "\n";
    my $axstereo;
    if ( $layer < 17 )
    { $axstereo = "(AXIAL)"; }
    else
    { $axstereo = "(STEREO)"; }
    my $id = ( 100 + $layer );
    print KUMAC "h/cr/1d $id 'Fittingweight vs absolute, normalized drift $axstero' $driftbins 0. 1.5
h/put_vect/contents $id layer$layer
max $id 12.
min $id 0.
";
}
print KUMAC "zone 1 2\nopt grid\n";

print KUMAC "h/plot 101 l\n";
foreach my $layer ( 2..16 )
{
    my $id = ( 100 + $layer );
    print KUMAC "h/plot $id sl\n";
}
print KUMAC "h/plot 117 l\n";
foreach my $layer ( 18..47 )
{
    my $id = ( 100 + $layer );
    print KUMAC "h/plot $id sl\n";
}
print KUMAC "pict/print 'showconst.ps'
exit
";
close( KUMAC );
