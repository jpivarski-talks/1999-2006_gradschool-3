#!/usr/bin/perl

if ( 0 )
{
    # This is the cosTheta distribution I was looking at the weights with:
    $COSTH{1} = 0; $COSTH{2} = 93; $COSTH{3} = 3890; $COSTH{4} = 4743;
    $COSTH{5} = 2950; $COSTH{6} = 4679; $COSTH{7} = 3654;
    $COSTH{8} = 2999; $COSTH{9} = 2521; $COSTH{10} = 2322;
    $COSTH{11} = 2377; $COSTH{12} = 2552; $COSTH{13} = 2988;
    $COSTH{14} = 3609; $COSTH{15} = 4688; $COSTH{16} = 2939;
    $COSTH{17} = 4773; $COSTH{18} = 3893; $COSTH{19} = 93;
    $COSTH{20} = 0;
}
else
{
    # This is an un-prescaled distribution, it is the one which I used
    # to create the fittingweights with:
    $COSTH{1} = 31; $COSTH{2} = 6221; $COSTH{3} = 33877;
    $COSTH{4} = 14790; $COSTH{5} = 9615; $COSTH{6} = 9048;
    $COSTH{7} = 6017; $COSTH{8} = 5925; $COSTH{9} = 5410;
    $COSTH{10} = 4281; $COSTH{11} = 4918; $COSTH{12} = 5213;
    $COSTH{13} = 5808; $COSTH{14} = 7186; $COSTH{15} = 8499;
    $COSTH{16} = 9739; $COSTH{17} = 17301; $COSTH{18} = 29968;
    $COSTH{19} = 6130; $COSTH{20} = 23;
}

$COSTHNORM = ( $COSTH{1} + $COSTH{2} + $COSTH{3} + $COSTH{4} +
               $COSTH{5} + $COSTH{6} + $COSTH{7} + $COSTH{8} +
               $COSTH{9} + $COSTH{10} + $COSTH{11} + $COSTH{12} +
               $COSTH{13} + $COSTH{14} + $COSTH{15} + $COSTH{16} +
               $COSTH{17} + $COSTH{18} + $COSTH{19} + $COSTH{20} );

sub get_costh
{
    my $trial = 0;
    my $take = 0.;
    while ( $take <= rand() )
    {
	$trial = ( int( rand() * 20 ) + 1 );
	$take = ( $COSTH{$trial} / $COSTHNORM );
    }
    return $trial;
}

# nt/cr 1 'hitlevel' 8 ! ! 'lam' 'layer' 'costheta' 'absdrift' 'drift' 'dca' 'edrift' 'edca'
# nt/read 1 'hitdata5.txt' ! ! 190000

# This is the drift distribution. For the old weights, you'll need to
# compress this (drift = int(drift/2-0.5)+1)
$ABSDRIFT{1} = 8324;
$ABSDRIFT{2} = 9472;
$ABSDRIFT{3} = 9413;
$ABSDRIFT{4} = 9318;
$ABSDRIFT{5} = 9276;
$ABSDRIFT{6} = 9361;
$ABSDRIFT{7} = 9188;
$ABSDRIFT{8} = 9382;
$ABSDRIFT{9} = 9233;
$ABSDRIFT{10} = 9240;
$ABSDRIFT{11} = 8981;
$ABSDRIFT{12} = 9146;
$ABSDRIFT{13} = 9627;
$ABSDRIFT{14} = 9421;
$ABSDRIFT{15} = 9230;
$ABSDRIFT{16} = 9008;
$ABSDRIFT{17} = 8644;
$ABSDRIFT{18} = 8137;
$ABSDRIFT{19} = 9111;
$ABSDRIFT{20} = 9096;
$ABSDRIFT{21} = 5297;
$ABSDRIFT{22} = 903;
$ABSDRIFT{23} = 496;
$ABSDRIFT{24} = 266;
$ABSDRIFT{25} = 164;
$ABSDRIFT{26} = 79;
$ABSDRIFT{27} = 76;
$ABSDRIFT{28} = 36;
$ABSDRIFT{29} = 15;
$ABSDRIFT{30} = 19;

$ABSDRIFTNORM = ( $ABSDRIFT{1} + $ABSDRIFT{2} + $ABSDRIFT{3} +
                  $ABSDRIFT{4} + $ABSDRIFT{5} + $ABSDRIFT{6} +
                  $ABSDRIFT{7} + $ABSDRIFT{8} + $ABSDRIFT{9} +
                  $ABSDRIFT{10} + $ABSDRIFT{11} + $ABSDRIFT{12} +
                  $ABSDRIFT{13} + $ABSDRIFT{14} + $ABSDRIFT{15} +
                  $ABSDRIFT{16} + $ABSDRIFT{17} + $ABSDRIFT{18} +
                  $ABSDRIFT{19} + $ABSDRIFT{20} + $ABSDRIFT{21} +
                  $ABSDRIFT{22} + $ABSDRIFT{23} + $ABSDRIFT{24} +
                  $ABSDRIFT{25} + $ABSDRIFT{26} + $ABSDRIFT{27} +
                  $ABSDRIFT{28} + $ABSDRIFT{29} + $ABSDRIFT{30} );

sub get_absdrift
{
    my $trial = 0;
    my $take = 0.;
    while ( $take <= rand() )
    {
	$trial = ( int( rand() * 30 ) + 1 );
	$take = ( $ABSDRIFT{$trial} / $ABSDRIFTNORM );
    }
    return $trial;
}

sub get_smallabsdrift
{
    return ( int( &get_absdrift() / 2 - 0.5 ) + 1 );
}

if ( 0 )
{

    # same for layer;
    $LAYER{1} = 3889; $LAYER{2} = 3581; $LAYER{3} = 3712;
    $LAYER{4} = 3665; $LAYER{5} = 3865; $LAYER{6} = 3902;
    $LAYER{7} = 3770; $LAYER{8} = 3943; $LAYER{9} = 3873;
    $LAYER{10} = 3888; $LAYER{11} = 4047; $LAYER{12} = 3800;
    $LAYER{13} = 3912; $LAYER{14} = 3949; $LAYER{15} = 3638;
    $LAYER{16} = 3825; $LAYER{17} = 4328; $LAYER{18} = 4181;
    $LAYER{19} = 4194; $LAYER{20} = 4109; $LAYER{21} = 4174;
    $LAYER{22} = 4203; $LAYER{23} = 4137; $LAYER{24} = 4103;
    $LAYER{25} = 4212; $LAYER{26} = 4213; $LAYER{27} = 4150;
    $LAYER{28} = 4161; $LAYER{29} = 4152; $LAYER{30} = 4175;
    $LAYER{31} = 4173; $LAYER{32} = 4149; $LAYER{33} = 4168;
    $LAYER{34} = 4169; $LAYER{35} = 4143; $LAYER{36} = 4128;
    $LAYER{37} = 4177; $LAYER{38} = 4013; $LAYER{39} = 4170;
    $LAYER{40} = 4126; $LAYER{41} = 4181; $LAYER{42} = 4153;
    $LAYER{43} = 4152; $LAYER{44} = 4116; $LAYER{45} = 4167;
    $LAYER{46} = 4151; $LAYER{47} = 3913;

}
else
{
    # this is the old scaling of layer

    $LAYER{1} = 3590; $LAYER{2} = 3595; $LAYER{3} = 3623;
    $LAYER{4} = 3656; $LAYER{5} = 3666; $LAYER{6} = 3693;
    $LAYER{7} = 3637; $LAYER{8} = 3697; $LAYER{9} = 3684;
    $LAYER{10} = 681; $LAYER{11} = 708; $LAYER{12} = 669;
    $LAYER{13} = 684; $LAYER{14} = 696; $LAYER{15} = 684;
    $LAYER{16} = 698; $LAYER{17} = 745; $LAYER{18} = 728;
    $LAYER{19} = 726; $LAYER{20} = 718; $LAYER{21} = 729;
    $LAYER{22} = 733; $LAYER{23} = 722; $LAYER{24} = 714;
    $LAYER{25} = 706; $LAYER{26} = 694; $LAYER{27} = 670;
    $LAYER{28} = 662; $LAYER{29} = 652; $LAYER{30} = 620;
    $LAYER{31} = 627; $LAYER{32} = 612; $LAYER{33} = 617;
    $LAYER{34} = 599; $LAYER{35} = 597; $LAYER{36} = 584;
    $LAYER{37} = 586; $LAYER{38} = 574; $LAYER{39} = 566;
    $LAYER{40} = 568; $LAYER{41} = 573; $LAYER{42} = 561;
    $LAYER{43} = 536; $LAYER{44} = 517; $LAYER{45} = 523;
    $LAYER{46} = 499; $LAYER{47} = 382;

}

$LAYERNORM = ( $LAYER{1} + $LAYER{2} + $LAYER{3} + $LAYER{4} +
               $LAYER{5} + $LAYER{6} + $LAYER{7} + $LAYER{8} +
               $LAYER{9} + $LAYER{10} + $LAYER{11} + $LAYER{12} +
               $LAYER{13} + $LAYER{14} + $LAYER{15} + $LAYER{16} +
               $LAYER{17} + $LAYER{18} + $LAYER{19} + $LAYER{20} +
               $LAYER{21} + $LAYER{22} + $LAYER{23} + $LAYER{24} +
               $LAYER{25} + $LAYER{26} + $LAYER{27} + $LAYER{28} +
               $LAYER{29} + $LAYER{30} + $LAYER{31} + $LAYER{32} +
               $LAYER{33} + $LAYER{34} + $LAYER{35} + $LAYER{36} +
               $LAYER{37} + $LAYER{38} + $LAYER{39} + $LAYER{40} +
               $LAYER{41} + $LAYER{42} + $LAYER{43} + $LAYER{44} +
               $LAYER{45} + $LAYER{46} + $LAYER{47} );

sub get_layer
{
    my $trial = 0;
    my $take = 0.;
    while ( $take <= rand() )
    {
	$trial = ( int( rand() * 47 ) + 1 );
	$take = ( $LAYER{$trial} / $LAYERNORM );
    }
    return $trial;
}

# Testing code
#  my %test = ();
#  foreach $n ( 1..5000 )
#  {
#      $test{&get_layer()}++;
#  }
#  sub numly { $a <=> $b; }
#  foreach $key ( sort numly keys %test )
#  {
#      print "$key = $test{$key}\n";
#  }

#  # old weights, be sure to fold drift
#  $drweightlayer = "/home/mccann/public/fitweight_01-02-01/lambdas.drweightlayer";
#  $drweighttheta = "/home/mccann/public/fitweight_01-02-01/lambdas.drweighttheta";
#  $drweightdrift = "/home/mccann/public/fitweight_01-02-01/lambdas.drweightdrift";

# bad weights
$drweightlayer = "/home/mccann/run/MakeFittingWeights/data13_bhabhas/newconst.drweightlayer";
$drweighttheta = "/home/mccann/run/MakeFittingWeights/data13_bhabhas/iter6.drweighttheta";
$drweightdrift = "/home/mccann/run/MakeFittingWeights/data13_bhabhas/newconst.drweightdrift";

#  # new weights
#  $drweightlayer = "/home/mccann/public/fitweight_06-06-01/data13_34.drweightlayer";
#  $drweighttheta = "/home/mccann/public/fitweight_06-06-01/data13_34.drweighttheta";
#  $drweightdrift = "/home/mccann/public/fitweight_06-06-01/data13_34.drweightdrift";

%fwlayer = ();
$n = 0;
open( CONSTFILE, $drweightlayer );
while( <CONSTFILE> )
{
    chop;
    my ( $layer, $fw ) = split( /\s+/ );

    if ( $n > 1 )
    {
	$fwlayer{$layer} = $fw;
#	print "\$fwlayer{$layer} = $fw\n";
    }
    $n++;
}
close( CONSTFILE );
# print "\n";

%fwtheta = ();
open( CONSTFILE, $drweighttheta );
while( <CONSTFILE> )
{
    chop;
    my ( $n, $layer, $thetabin, $fw ) = split( /\s+/ );

    if ( $n >= 3  &&  $fw ne "" )
    {
        $fwtheta{$layer}{$thetabin} = $fw;
#	print "\$fwtheta{$layer}{$thetabin} = $fw\n";
    }
}
close( CONSTFILE );
# print "\n";

%fwdrift = ();
open( CONSTFILE, $drweightdrift );
while( <CONSTFILE> )
{
    chop;
    my ( $n, $layer, $driftbin, $fw ) = split( /\s+/ );

    if ( $n >= 3  &&  $fw ne "" )
    {
        $fwdrift{$layer}{$driftbin} = $fw;
#	print "\$fwdrift{$layer}{$driftbin} = $fw\n";
    }
}
close( CONSTFILE );
# print "\n";

# Monte Carlo-style averaging
open( FWDIST, ">fwdist.txt" );
my $sum = 0.;
for ( my $n = 1;  1;  $n++ )
{
    my $layer = &get_layer();
    my $theta = &get_costh();
    my $drift = &get_absdrift();  # or &get_smallabsdrift() for old weights

    my $fw = ( $fwlayer{$layer} * $fwtheta{$layer}{$theta} * $fwdrift{$layer}{$drift} );
    $sum += $fw;

    printf( "%10d  |  %10.7f  |  %02d  |  %02d  |  %02d  |  %10.7f\n",
	    $n, ( $sum / $n ), $layer, $theta, $drift, $fw )
	if ( $n % 100 == 0 );
    print FWDIST "$fw\n";
}
close( FWDIST );
exit(1);

# Average by weighted mean, the same way that I did it last time
$sum_layer = 0.;
$n_layer = 0;
foreach $layer ( 1..47 )
{
    printf( "%10.7f  |  %10d\n", $fwlayer{$layer}, $LAYER{$layer} );
    $sum_layer += ( $fwlayer{$layer} * $LAYER{$layer} );
    $n_layer += $LAYER{$layer};
}
$lambda_layer = ( $sum_layer / $n_layer );
print "lambda_layer = $lambda_layer\n\n";

$sum_theta = 0.;
$n_theta = 0;
foreach $theta ( 1..20 )
{
    printf( "%10.7f  |  %10d\n", $fwtheta{1}{$theta}, $COSTH{$theta} );
    foreach $layer ( 1..47 )
    {
	$sum_theta += ( $fwtheta{$layer}{$theta} * $COSTH{$theta} );
	$n_theta += $COSTH{$theta};
    }
}
$lambda_theta = ( $sum_theta / $n_theta );
print "lambda_theta = $lambda_theta\n\n";

$sum_drift = 0.;
$n_drift = 0;
# foreach $drift ( 1..15 )
foreach $drift ( 1..30 )
{
#     my $weight = ( $ABSDRIFT{(2*$drift-1)} + $ABSDRIFT{(2*$drift)} );
    my $weight = $ABSDRIFT{$drift};
    printf( "%10.7f  | %10.7f  | %10.7f  | %10.7f  |  %10d\n",
	    $fwdrift{1}{$drift}, $fwdrift{19}{$drift}, $fwdrift{30}{$drift}, $fwdrift{47}{$drift},
	    $weight );
    foreach $layer ( 1..47 )
    {
	$sum_drift += ( $fwdrift{$layer}{$drift} * $weight );
	$n_drift += $weight;
    }
}
$lambda_drift = ( $sum_drift / $n_drift );
print "lambda_drift = $lambda_drift\n\n";

$lambda = ( $lambda_layer * $lambda_theta * $lambda_drift );
print "overall_lambda = $lambda\n";
