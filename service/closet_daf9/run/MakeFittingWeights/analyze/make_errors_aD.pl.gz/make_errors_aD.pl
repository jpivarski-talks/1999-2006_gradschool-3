#!/usr/bin/perl

open( TMP, "> tmp.kumac" );
print TMP "
h/file 1 process3.rzn
cd makefittingweights
h/cr/sliy 1100 47
h/project 1100
ve/cr datavsabsdrift(15)                      
ve/cr lambdavsabsdrift(15)
";
foreach $layer ( 1..47 )
{
    $olayer = sprintf( "%02d", $layer );
    print TMP "
message 'open file for layer $layer'

h/get_vect/contents 1100.sliy.$layer datavsabsdrift
ve/print datavsabsdrift 0

h/get_vect/contents 13$olayer lambdavsabsdrift
ve/print lambdavsabsdrift 0

message 'write file for layer $layer'
";
}
print TMP "exit\n";
close( TMP );

open( PAW, "paw < tmp.kumac |" );
@datavsabsdrift = @lambdavsabsdrift = ();
while( <PAW> )
{
#     print $_;
    chop;

    @line = split( /\s+/ );
    $last = $line[$#line];

    if ( $_ =~ /open file for layer/  &&  $last !~ /[^0-9]/ )
    {
	@datavsabsdrift = @lambdavsabsdrift = ();
	$olayer = sprintf( "%02d", $last );
	open( ABSDRIFTERR, "> absdrifterr_layer-$olayer.txt" );
# 	print "\n   * * * Opening file for layer $olayer * * *\n";
    }

    if ( $_ =~ /DATAVSABSDRIFT/  &&  $last !~ /[^0-9]/ )
    { push( @datavsabsdrift, $last ); }
    if ( $_ =~ /LAMBDAVSABSDRIFT/  &&  $last !~ /[^0-9\.]/ )
    { push( @lambdavsabsdrift, $last ); }

    if ( $_ =~ /write file for layer/  &&  $last !~ /[^0-9]/ )
    {
# 	print "\n   * * * Writing file for layer $olayer * * *\n";
	if ( $#datavsabsdrift == 14  &&  $#lambdavsabsdrift == 14 )
	{
	    foreach $n ( 0..14 )
	    {
# 	        print ABSDRIFTERR "$datavsabsdrift[$n]\t$lambdavsabsdrift[$n]\n";
		if ( $datavsabsdrift[$n] < 100 )
		{ print ABSDRIFTERR "20.\n"; }
		else
		{
		    print ABSDRIFTERR ( $lambdavsabsdrift[$n]
				       / sqrt( 2 * $datavsabsdrift[$n] ) );
		    print ABSDRIFTERR "\n";
		}
	    }
	    close( ABSDRIFTERR );
	    @datavsabsdrift = @lambdavsabsdrift = ();
	}
	else
	{
	    print "\nWrong number of elements!\n    datavsabsdrift = ";
	    foreach $d ( @datavsabsdrift )
	    { print "$d "; }
	    print "\n    lambdavsabsdrift = ";
	    foreach $l ( @lambdavsabsdrift )
	    { print "$l "; }
	    print "\n";
	    die;
	}
    }
}

open( TMP, "> useerrs.kumac" );
print TMP "
h/file 1 process3.rzn
cd makefittingweights
ve/cr absdrifterr(15)                      
";
foreach $layer ( 1..47 )
{
    $olayer = sprintf( "%02d", $layer );
    print TMP "
ve/read absdrifterr 'absdrifterr_layer-$olayer.txt'
h/put_vect/errors 13$olayer absdrifterr
";
}
