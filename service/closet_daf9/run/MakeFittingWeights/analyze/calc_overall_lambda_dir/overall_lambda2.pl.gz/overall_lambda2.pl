#!/usr/bin/perl

if ( $#ARGV == -1 )
{
    print "./overall_lambda2.pl process lambda_file_base_name\n";
    exit(0);
}

# generate doesn't make file nl (number of entries per layer)
# try this:
# perl -e '$c=0;%layer=();while(<>){ ($lam,$lay,@rest)=split(/\t/,$_); $layer{$lay}++; $c++; break if ( $c > 42455 ); } open( NL, ">nl.txt" ); foreach $lay ( sort numly keys %layer ){ print "$lay\t$layer{$lay}\n"; print NL "$layer{$lay}\n"; } sub numly{ $a <=> $b; }' < $USER_DAF/MakeFittingWeights/tenthTry/hitdata1.txt
# change the number

# keep the generated files around so you don't need to do this again!
# perl -e 'foreach $looklayer( 1..20 ){ $olayer = sprintf( "%02d", $looklayer ); open( OUT, ">drift_layer$olayer.txt" ); open( IN, "hitdata1.txt" ); while($_=<IN>){ chop; ($lam,$layer,$theta,$absDrift,@rest)=split( /\t/, $_ ); if ( $layer == $looklayer ){ print OUT "$absDrift\n"; } } close IN; close OUT; }' &

if ( $ARGV[0] =~ /generate/i )
{
    open( PAW, "| paw" );
    print PAW "\n";
    foreach $layer ( 1..47 )
    {
	$olayer = sprintf( "%02s", $layer );
	$id = ( 100 + $layer );
	
	print PAW "
ve/read d$olayer 'drift_layer$olayer.txt'
h/cr/1d $id 'drift npoints on layer $layer' 15 0. 1.5
ve/hfill d$olayer $id
ve/cr nd$olayer\(15)
h/get_vect/contents $id nd$olayer
ve/write nd$olayer 'nd_layer$olayer.txt' f20.
";
    }
    print PAW "
ve/read t 'theta.txt'
h/cr/1d 150 'theta npoints' 20 -1. 1.
ve/hfill t 150
ve/cr nt(20)
h/get_vect/contents 150 nt
ve/write nt 'nt.txt' f20.
exit
";
}

if ( $ARGV[0] =~ /process/i )
{
    $lambdad = 0; $nd = 0;

    foreach $layer ( 1..47 )
    {
	$olayer = sprintf( "%02s", $layer );
	
	open( NDRIFT, "nd_layer$olayer.txt" );
	@ndrift = ();
	while( <NDRIFT> )
	{
	    chop;
	    push( @ndrift, sprintf( "%d", $_ ) );
	}
	close NDRIFT;
	
	# get the drift lambdas
	open( DRIFT, "$ARGV[1].drweightdrift" );
	print "                          L  A  Y  E  R     $layer\n";
	printf( "%20s %20s %20s\n", "absDriftBin", "lambda", "number of points" );
	print "--------------------------------------------------------------------\n";
	while( <DRIFT> )
	{
	    chop;
	    @a = split( ' ' );
	    if ( $a[1] == $layer )
	    {
		printf( "%20s %20s %20s\n", $a[2], $a[3], $ndrift[( $a[2]-1 )] );
		$lambdad += ( $a[3] * $ndrift[( $a[2]-1 )] );
		$nd += $ndrift[( $a[2]-1 )];
	    }
	}
	print "\n";
	printf( "%20s %20s %20s\n", "lam_d = $lambdad", "n_d = $nd",
		( "<lam_d> = " . sprintf( "%5.3f",  ( $lambdad / $nd ) ) ) );
	print "\n";
    }
    
    $lambdad /= $nd;
    print "Lambda_drift is $lambdad.\n\n";



    @lambdat = 0; @nt = 0;

    open( NTHETA, "nt.txt" );
    @ntheta = ();
    while( <NTHETA> )
    {
	chop;
	push( @ntheta, sprintf( "%d", $_ ) );
    }
    close NTHETA;
    
    # get the theta lambdas
    open( THETA, "$ARGV[1].drweighttheta" );
    print "                             T   H   E   T   A\n";
    printf( "%20s %20s %20s\n", "cosThetaBin", "lambda", "number of points" );
    print "--------------------------------------------------------------------\n";
    while( <THETA> )
    {
	chop;
	@a = split( ' ' );
	if ( $a[1] == 1 )
	{
	    printf( "%20s %20s %20s\n", $a[2], $a[3], $ntheta[( $a[2]-1 )] );
	    $lambdat += ( $a[3] * $ntheta[( $a[2]-1 )] );
	    $nt += $ntheta[( $a[2]-1 )];
	}
    }
    print "\n";
    printf( "%20s %20s %20s\n", "lam_t = $lambdat", "n_t = $nt",
	   ( "<lam_t> = " . sprintf( "%5.3f",  ( $lambdat / $nt ) ) ) );
    print "\n";
    
    $lambdat /= $nt;
    print "Lambda_theta is $lambdat.\n\n";
    

    
    @lambdal = 0; @nl = 0;

    open( NLAYER, "nl.txt" );
    @nlayer = ();
    while( <NLAYER> )
    {
	chop;
	push( @nlayer, $_ );
    }
    close NLAYER;
    
    # get the layer lambdas
    open( LAYER, "$ARGV[1].drweightlayer" );
    print "                             L   A   Y   E   R\n";
    printf( "%20s %20s %20s\n", "layer", "lambda", "number of points" );
    print "--------------------------------------------------------------------\n";
    while( <LAYER> )
    {
	chop;
	@a = split( ' ' );
	if ( $#a == 1 )
	{
	    printf( "%20s %20s %20s\n", $a[0], $a[1], $nlayer[( $a[0]-1 )] );
	    $lambdal += ( $a[1] * $nlayer[( $a[0]-1 )] );
	    $nl += $nlayer[( $a[0]-1 )];
	}
    }
    print "\n";
    printf( "%20s %20s %20s\n", "lam_l = $lambdal", "n_l = $nl",
	   ( "<lam_l> = " . sprintf( "%5.3f",  ( $lambdal / $nl ) ) ) );
    print "\n";
    
    $lambdal /= $nl;
    print "Lambda_layer is $lambdal.\n\n";



    print "Overall lambda is lambda_drift * lambda_theta * lambda_layer
    = $lambdad * $lambdat * $lambdal = ";
    print ( $lambdad * $lambdat * $lambdal );
    print "\n";
}
