#!/usr/bin/perl

open( TMP, "> tmp.kumac" );
print TMP "
h/file 1 process3.rzn
cd makefittingweights
h/cr/sliy 1110 47
h/project 1110
ve/cr datavscostheta(20)                      
h/get_vect/contents 1110.sliy.1 datavscostheta
ve/print datavscostheta 0

ve/cr lambdavscostheta(20)
h/get_vect/contents 1351 lambdavscostheta
ve/print lambdavscostheta 0

exit
";
close( TMP );

open( PAW, "paw < tmp.kumac |" );
@datavscostheta = @lambdavscostheta = ();
while( <PAW> )
{
    chop;
    @line = split( /\s+/ );
    $last = $line[$#line];
    if ( $_ =~ /DATAVSCOSTHETA/  &&  $last !~ /[^0-9]/ )
    { push( @datavscostheta, $last ); }
    if ( $_ =~ /LAMBDAVSCOSTHETA/  &&  $last !~ /[^0-9\.]/ )
    { push( @lambdavscostheta, $last ); }
}

if ( $#datavscostheta == 19  &&  $#lambdavscostheta == 19 )
{
    open( COSTHETAERR, "> costhetaerr.txt" );
    foreach $n ( 0..19 )
    {
#	print "$datavscostheta[$n]\t$lambdavscostheta[$n]\n";
	print COSTHETAERR ( $lambdavscostheta[$n]
			   / sqrt( 2 * $datavscostheta[$n] ) );
	print COSTHETAERR "\n";
    }
    close( COSTHETAERR );
}
else
{
    print "\nWrong number of elements!\n    datavscostheta = ";
    foreach $d ( @datavscostheta )
    { print "$d "; }
    print "\n    lambdavscostheta = ";
    foreach $l ( @lambdavscostheta )
    { print "$l "; }
    print "\n";
}

open( TMP, ">> useerrs.kumac" );
print TMP "
ve/cr costhetaerr(20)                      
";
$olayer = sprintf( "%02d", $layer );
print TMP "
ve/read costhetaerr 'costhetaerr.txt'
h/put_vect/errors 1351 costhetaerr
";
