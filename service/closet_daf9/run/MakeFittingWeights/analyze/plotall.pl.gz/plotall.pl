#!/usr/bin/perl

print "
exec tmp.kumac
zone 2 3
fortran/file 76 /home/mccann/absdrift.ps
graphics/metafile 76 -111
igset mtype 1
opt logy
";

foreach $layer ( 1..47 )
{
    $olayer = sprintf( "%02d", $layer );
    print "h/plot 13$olayer
";
}

print "
exit
";
