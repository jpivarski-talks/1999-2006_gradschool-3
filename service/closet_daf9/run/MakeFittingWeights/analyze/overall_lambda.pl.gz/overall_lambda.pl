#!/usr/bin/perl

#####################################################
$driftlambda = 0.;
$driftn = 0;

open( TMP, "> tmp.kumac" );
print TMP "






ve/cr datavsabsdrift(15)                      
ve/cr lambdavsabsdrift(15)
";
foreach $layer ( 1..47 )
{
    $olayer = sprintf( "%02d", $layer );
    print TMP "
message 'open file for layer $layer'

h/get_vect/contents 1100.sliy.$layer datavsabsdrift
ve/print datavsabsdrift 0

h/get_vect/contents 13$olayer lambdavsabsdrift
ve/print lambdavsabsdrift 0

message 'write file for layer $layer'
";
}
print TMP "exit\n";
close( TMP );

open( PAW, "paw < tmp.kumac |" );
@datavsabsdrift = @lambdavsabsdrift = ();
while( <PAW> )
{
#     print $_;
    chop;

    @line = split( /\s+/ );
    $last = $line[$#line];

    if ( $_ =~ /open file for layer/  &&  $last !~ /[^0-9]/ )
    {
	@datavsabsdrift = @lambdavsabsdrift = ();
	$olayer = sprintf( "%02d", $last );
    }

    if ( $_ =~ /DATAVSABSDRIFT/  &&  $last !~ /[^0-9]/ )
    { push( @datavsabsdrift, $last ); }
    if ( $_ =~ /LAMBDAVSABSDRIFT/  &&  $last !~ /[^0-9\.]/ )
    { push( @lambdavsabsdrift, $last ); }

    if ( $_ =~ /write file for layer/  &&  $last !~ /[^0-9]/ )
    {
	if ( $#datavsabsdrift == 14  &&  $#lambdavsabsdrift == 14 )
	{
	    printf( "%8s %20s %20s %20s\n", "Layer $olayer", "absDriftBin",
		   "lambda", "data in bin" );
	    print "========================================================================\n";

	    foreach $n ( 0..14 )
	    {
		if ( $datavsabsdrift[$n] < 100 )
		{
		    printf( "%8s %20s %20s %20s\n", "", $n,
			   "n/a", "$datavsabsdrift[$n]" );
		}
		else
		{
		    printf( "%8s %20s %20s %20s\n", "", $n,
			   $lambdavsabsdrift[$n], $datavsabsdrift[$n] );
		    $driftlambda += ( $lambdavsabsdrift[$n] * $datavsabsdrift[$n] );
		    $driftn += $datavsabsdrift[$n];
		}
	    }
	    print "\n";
	    @datavsabsdrift = @lambdavsabsdrift = ();
	}
	else
	{
	    print "\nWrong number of elements!\n    datavsabsdrift = ";
	    foreach $d ( @datavsabsdrift )
	    { print "$d "; }
	    print "\n    lambdavsabsdrift = ";
	    foreach $l ( @lambdavsabsdrift )
	    { print "$l "; }
	    print "\n";
	    die;
	}
    }
}

$driftlambda /= $driftn;

print "************************************************************************
Average drift lambda is $driftlambda!
************************************************************************\n\n";

#####################################################
$thetalambda = 0.;
$thetan = 0;

open( TMP, "> tmp.kumac" );
print TMP "
h/file 1 process1.rzn
cd makefittingweights
h/cr/sliy 1110 47
h/project 1110
ve/cr datavscostheta(20)                      
h/get_vect/contents 1110.sliy.1 datavscostheta
ve/print datavscostheta 0

ve/cr lambdavscostheta(20)
h/get_vect/contents 1351 lambdavscostheta
ve/print lambdavscostheta 0

exit
";
close( TMP );

open( PAW, "paw < tmp.kumac |" );
@datavscostheta = @lambdavscostheta = ();
while( <PAW> )
{
    chop;
    @line = split( /\s+/ );
    $last = $line[$#line];
    if ( $_ =~ /DATAVSCOSTHETA/  &&  $last !~ /[^0-9]/ )
    { push( @datavscostheta, $last ); }
    if ( $_ =~ /LAMBDAVSCOSTHETA/  &&  $last !~ /[^0-9\.]/ )
    { push( @lambdavscostheta, $last ); }
}

if ( $#datavscostheta == 19  &&  $#lambdavscostheta == 19 )
{
    printf( "%8s %20s %20s %20s\n", "Layer $olayer", "cosThetaBin",
	   "lambda", "data in bin" );
    print "========================================================================\n";
    
    foreach $n ( 0..14 )
    {
	if ( $datavscostheta[$n] < 100 )
	{
	    printf( "%8s %20s %20s %20s\n", "", $n,
		   "n/a", "$datavscostheta[$n]" );
	}
	else
	{
	    printf( "%8s %20s %20s %20s\n", "", $n,
		   $lambdavscostheta[$n], $datavscostheta[$n] );
	    $thetalambda += ( $lambdavscostheta[$n] * $datavscostheta[$n] );
	    $thetan += $datavscostheta[$n];
	}
    }
    print "\n";
}
else
{
    print "\nWrong number of elements!\n    datavscostheta = ";
    foreach $d ( @datavscostheta )
    { print "$d "; }
    print "\n    lambdavscostheta = ";
    foreach $l ( @lambdavscostheta )
    { print "$l "; }
    print "\n";
}

$thetalambda /= $thetan;

print "************************************************************************
Average theta lambda is $thetalambda!
************************************************************************\n\n";

#####################################################
$layerlambda = 0.;
$layern = 0;

open( TMP, "> tmp.kumac" );
print TMP "
h/file 1 process1.rzn
cd makefittingweights
ve/cr datavslayer(47)                      
h/get_vect/contents 1120 datavslayer
ve/print datavslayer 0
ve/cr lambdavslayer(47)
h/get_vect/contents 1399 lambdavslayer
ve/print lambdavslayer 0

exit
";
close( TMP );

open( PAW, "paw < tmp.kumac |" );
@datavslayer = @lambdavslayer = ();
while( <PAW> )
{
    chop;
    @line = split( /\s+/ );
    $last = $line[$#line];
    if ( $_ =~ /DATAVSLAYER/  &&  $last !~ /[^0-9]/ )
    { push( @datavslayer, $last ); }
    if ( $_ =~ /LAMBDAVSLAYER/  &&  $last !~ /[^0-9\.]/ )
    { push( @lambdavslayer, $last ); }
}

if ( $#datavslayer == 46  &&  $#lambdavslayer == 46 )
{
    printf( "%8s %20s %20s %20s\n", "Layer $olayer", "layerBin",
	   "lambda", "data in bin" );
    print "========================================================================\n";
    
    foreach $n ( 0..46 )
    {
	$datavslayer[$n] = 10000;  # fix this!!!!!

	if ( $datavslayer[$n] < 100 )
	{
	    printf( "%8s %20s %20s %20s\n", "", $n,
		   "n/a", "$datavslayer[$n]" );
	}
	else
	{
	    printf( "%8s %20s %20s %20s\n", "", $n,
		   $lambdavslayer[$n], $datavslayer[$n] );
	    $layerlambda += ( $lambdavslayer[$n] * $datavslayer[$n] );
	    $layern += $datavslayer[$n];
	}
    }
    print "\n";
}
else
{
    print "\nWrong number of elements!\n    datavslayer = ";
    foreach $d ( @datavslayer )
    { print "$d "; }
    print "\n    lambdavslayer = ";
    foreach $l ( @lambdavslayer )
    { print "$l "; }
    print "\n";
}

$layerlambda /= $layern;

print "************************************************************************
Average layer lambda is $layerlambda!
************************************************************************\n\n";

$overalllambda = ( $layerlambda * $thetalambda * $driftlambda );

print "


So, lambda_drift = $driftlambda lambda_theta = $thetalambda and lambda_layer = $layerlambda.
The overall averaged lambda is............

                       $overalllambda


";

