perl -e 'while(<>){ chop; @a=split(" "); if ( $a[1] != 0 ) { $id = 1300+$a[0]; $id2 = 1600+$a[0]; print "h/op/mult $id 9999 $id2 $a[1] 1.\n"; } }' < iter3.drweightlayer
