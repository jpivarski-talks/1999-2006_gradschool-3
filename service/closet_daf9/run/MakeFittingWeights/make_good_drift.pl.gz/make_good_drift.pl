#!/usr/local/bin/perl

%fw = ();

open( ITER3, "iter3.drweightdrift" );
while( <ITER3> )
{
    chop;
    my ( $n, $layer, $driftbin, $fw ) = split( /\s+/ );

    if ( $n >= 3  &&  $fw ne "" )
    {
	$fw{$layer}{$driftbin} = $fw;
    }
}
close( ITER3 );

$n = 0;
open( ITER3, "iter3.drweightlayer" );
while( <ITER3> )
{
    chop;
    my ( $layer, $fw ) = split( /\s+/ );

    if ( $n > 1 )
    {
	foreach my $drifbin ( 1..30 )
	{
	    $fw{$layer}{$driftbin} *= $fw;
	}
    }
    $n++;
}
close( ITER3 );

foreach my $layer ( 1..47 )
{
    if ( $fw{$layer}{1} < $fw{$layer}{2} )
    {
#         $fw{$layer}{1} = ( 2 * $fw{$layer}{2} - $fw{$layer}{3} );
        $fw{$layer}{1} = $fw{$layer}{2};
    }

#      if ( $fw{$layer}{21} < $fw{$layer}{20} )
#      {
#  	$fw{$layer}{21} = ( ( $fw{$layer}{22} + $fw{$layer}{20} ) / 2. );
#      }
}

open( CONST, "> newconst.drweightdrift" );
print CONST "1 0 0 0 0 0 0 0 DEFAULT
1412
1 48 0 0
2 0 30 1.5
";
$n = 3;
foreach my $layer ( 1..47 )
{
    foreach my $driftbin ( 1..30 )
    {
	print CONST "$n $layer $driftbin $fw{$layer}{$driftbin}\n";
	$n++;
    }
}
close( CONST );

open( CONST, "> newconst.drweightlayer" );
print CONST "1 0 0 0 0 0 0 0 DEFAULT
47
";
foreach my $layer ( 1..47 )
{
    print CONST "$layer 1.0\n";
}
close( CONST );

open( KUMAC, "> newconst.kumac" );
print KUMAC "\n";
foreach my $layer ( 1..47 )
{
    print KUMAC "ve/cr layer$layer(30)\n";
    print KUMAC "ve/inp layer$layer ";
    foreach my $driftbin ( 1..30 )
    {
	print KUMAC "$fw{$layer}{$driftbin} ";
    }
    print KUMAC "\n";
}
print KUMAC "zone 1 2\nopt grid\n";
print KUMAC "null 0. 23. 0. 3.\n";
foreach my $layer ( 1..16 )
{
    print KUMAC "ve/draw layer$layer ! 'ls'\n";
}
print KUMAC "null 0. 23. 0. 3.\n";
foreach my $layer ( 17..47 )
{
    print KUMAC "ve/draw layer$layer ! 'ls'\n";
}
close( KUMAC );
