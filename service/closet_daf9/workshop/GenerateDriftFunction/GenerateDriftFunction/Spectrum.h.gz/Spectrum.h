#if !defined(GENERATEDRIFTFUNCTION_SPECTRUM_H)
#define GENERATEDRIFTFUNCTION_SPECTRUM_H

#include "HistogramInterface/HistogramPackage.h"
#include <fstream.h>

class Spectrum
{
   public:
      // ------------ constants, enums and typedefs --------------
      enum {kDriftTimeWindow = 400};
      enum {kNoOfnsPerBin = 2};
      enum {kNoOfTimeBins = 200}; // kNoOfTimeBins*kNoOfnsPerBin = kDriftTimeWindow!!!!!
      enum {kNoOfDriftDistanceBins = 100}; // no of bins in the drift distance spectrum 
      enum {kMaxDriftDistance = 8}; // distance the kNoOfDriftDistanceBins corresponds to
      enum {kTransitionPoint=70}; // bin number which is used as lower bound of the transition point 
      enum {kNoTransitionBins=1}; // should add to about 20 ns if multipled with kNoOfnsPerBin
      enum {kTotalDCARange = 15}; // range of DCA spectrum in mm
      enum {kNoOfDCABins = 300};// no of bin in the my_DCASpectrum
      enum {kMinimumEntriesPerTimeBin = 500}; // no of entries needed in time bin to calculate time to drift conversion

public:
  Spectrum();
  Spectrum(string spectrumId,UInt32 histNumber,HIHistDir *histDir, string outputVersion); // name and number of the drift histograms and param for output
//      virtual ~DriftTimeSpectrum();

      // public member function

  void SetValues(double driftTime, double signedDriftDistance, double combinedDCA, double residual, float cotTheta);
  float getDriftDistance(UInt32 bin){return my_driftDistances[bin];};
  float getPosDriftDistance(UInt32 bin){return my_driftDistancesPos[bin];};
  float getNegDriftDistance(UInt32 bin){return my_driftDistancesNeg[bin];};
  void findConstants();
  void getConstants(UInt32 DCASpectrum[kNoOfTimeBins][kNoOfDCABins], float *driftDistances, UInt32 setHists);
  int rmsTruncated(UInt32 *dcaSpectrum, float truncationMean, float truncationWidth);
  int rms(UInt32 *dcaSpectrum, UInt32 beginCount, UInt32 endCount, float &mean, float &rms);
  void writeDCASpectrum(FILE *out);
  void readDCASpectrum(FILE *in);
  void SetTimeToDriftFunctionValues(UInt32 driftSignIndex, UInt32 driftTimeBin, float driftDistance);

//      virtual void hist_book( TBHistoManager& );                  

  HIHist1D *histDriftTime;
  HIHist1D *histDriftDistance;
  HIHist1D *histResidual;
  HIHist1D *histTimeResidual;
  HIHist1D *histIntegratedTimes;
  HIHist1D *histDCA;
  HIHist2D *histDriftDistanceVsDCA;
  HIHist2D *histDriftTimeVsDCA;
  HIHist2D *histTimeToDriftFunction;
  HIHist2D *histResidualVsDCA;
  HIHistProf *histProfResidualVsDriftDistance;
  HIHistProf *histProfResidualVsDriftDistanceTruncated;
  HIHist1D *histScaleDistribution;
  HIHist1D *histResidualRMSvsDriftTime;
  HIHist1D *histResidualRMSvsDriftDistance;
  HIHist1D *histResidualBins[41];
  HIHist1D *histDCADistTime[kNoOfTimeBins+1];
  HIHist1D *histMeanVar[kNoOfTimeBins+1];
  HIHist1D *histNoOfEntriesPerTimeBin;
  HIHist1D *histResidualCotThetaPos;
  HIHist1D *histResidualCotThetaNeg;

  
private:
      // private member function
  UInt32 my_driftTimes[kDriftTimeWindow];
  UInt32 my_integratedDriftTimes[kDriftTimeWindow];
  UInt32 my_DCASpectrum[kNoOfTimeBins][kNoOfDCABins];
  UInt32 my_DCASpectrumPos[kNoOfTimeBins][kNoOfDCABins];
  UInt32 my_DCASpectrumNeg[kNoOfTimeBins][kNoOfDCABins];
  //  UInt32 my_DCASpectrumDistances[kNoOfDriftDistanceBins*2+1][kNoOfDCABins];
  float my_driftDistances[kNoOfTimeBins]; // final driftdistances containing integrated info below transition
  float my_driftDistancesPos[kNoOfTimeBins]; // final driftdistances containing integrated info below transition
  float my_driftDistancesNeg[kNoOfTimeBins]; // final driftdistances containing integrated info below transition
  float my_meanDistance;   // driftdistances from truncated mean calculation
  float my_rms;            // rms's from truncated mean calculation
  float my_TimeToDriftFunction[2][kNoOfTimeBins];

  string my_spectrumId;
  string my_outputVersion;
};


#endif /* GENERATEDRIFTFUNCTION_SPECTRUM_H */
