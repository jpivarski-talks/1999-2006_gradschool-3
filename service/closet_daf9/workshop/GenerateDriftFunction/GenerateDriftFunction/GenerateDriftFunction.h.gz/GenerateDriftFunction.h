#if !defined(GENERATEDRIFTFUNCTION_GENERATEDRIFTFUNCTION_H)
#define GENERATEDRIFTFUNCTION_GENERATEDRIFTFUNCTION_H
// -*- C++ -*-
//
// Package:     <GenerateDriftFunction>
// Module:      GenerateDriftFunction
// 
// Description: <one line class summary>
//
// Usage:
//    <usage>
//
// Author:      David Urner
// Created:     Fri Aug 13 12:17:13 EDT 1999
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "FrameAccess/FAItem.h"
#include "Processor/Processor.h"
#include "ToolBox/HistogramPackage.h"
#include <ADRGeom/ADRSenseWireStore.h>
#include "CommandPattern/Parameter.h"
#include "CLHEP/Random/JamesRandom.h"
#include "CLHEP/Random/RandFlat.h"
#include "Spectrum.h"
#include "DRTQTChannelMap.hxx"

// forward declarations
/// This Class generates the histograms needed to produce drift functions
/** For each layer it generates a hitogram of the drift times
  and a histogram of the calculated distances to the wire (closest approach of track to wire).
  */
class GenerateDriftFunction : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------
      enum {kNoOfCotanThetaBins = 200};
      enum {kNoOfTimeBins = Spectrum::kNoOfTimeBins};
      enum {kNoOfnsPerBin = Spectrum::kNoOfnsPerBin};
      enum {kNoOfTQTCrates = 12};
      enum {kNoOfChargeBins = 25};
      // ------------ Constructors and destructor ----------------
      GenerateDriftFunction( void );                      // anal1 
      virtual ~GenerateDriftFunction();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( TBHistoManager& );                  


      HIHist1D *histCotanTheta;
      HIHist1D *histCotanThetaSum;
      HIHist1D *histD0Sum;
      HIHist1D *histImpactZ;
      HIHist2D *histXvsY;
      HIHist2D *histXvsYPhi[4];
      HIHist2D *histD0vsPhi;
      HIHist1D *histMomentumResolution;
      HIHist1D *histChargeDistribution;
      HIHist1D *histNoOfHitsPerTrack;
      HIHist1D *histNoOfHitsPerTrackFinder;
      HIHist1D *histMomentumResolutionMuon;
      HIHistProf *histMomVsPhiPosProf;
      HIHistProf *histMomVsPhiNegProf;
      HIHistProf *histZMissVsCotThetaProf;
      HINtuple *ntupStudyBhaBhas;
      

      HIHistDir *my_histDir;
      

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      GenerateDriftFunction( const GenerateDriftFunction& );

      // ------------ assignment operator(s) ---------------------
      const GenerateDriftFunction& operator=( const GenerateDriftFunction& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (GenerateDriftFunction::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      void writeDriftData();
      // ------------ private const member functions -------------

      // ------------ data members -------------------------------
      Spectrum *my_spectrumLayer[ADRSenseWireStore::kNumberOfLayers+1];
      Spectrum *my_spectrumAll;
      Spectrum *my_spectrumAllMuon;
      Spectrum *my_spectrumTQTCrate[kNoOfTQTCrates+1];
      Spectrum *my_spectrumCharge[kNoOfChargeBins];

      UInt32 m_NumberOfEvents;

      FAItem<DRTQTChannelMap> my_TQTMap;

      Parameter<string> fitMethodParam;
      Parameter<string> inputDataParam;
      Parameter<string> versionDCAOutputParam;
      Parameter<DABoolean> noMuonParam;
      // ------------ static data members ------------------------
      UInt32 my_noTracks;
};

// inline function definitions

#endif /* GENERATEDRIFTFUNCTION_GENERATEDRIFTFUNCTION_H */
