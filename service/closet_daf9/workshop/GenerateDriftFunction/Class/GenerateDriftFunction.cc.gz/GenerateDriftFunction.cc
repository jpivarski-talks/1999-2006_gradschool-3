// -*- C++ -*-
//
// Package:     GenerateDriftFunction
// Module:      GenerateDriftFunction
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      David Urner
// Created:     Fri Aug 13 12:17:13 EDT 1999
// $Id$
//
// Revision history
//
// $Id$
//

#include "Experiment/Experiment.h"


// system include files
#if defined(STL_TEMPLATE_DEFAULT_PARAMS_FIRST_BUG)
// You may have to uncomment some of these or other stl headers
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
#include <vector>
//#include <set>
//#include <map>
#include <algorithm>
//#include <utility>
#endif /* STL_TEMPLATE_DEFAULT_PARAMS_FIRST_BUG */

// user include files
#include "GenerateDriftFunction/GenerateDriftFunction.h"
#include "GenerateDriftFunction/Spectrum.h"
#include "Experiment/report.h"
#include "TrackRoot/TRSeedTrack.h"
#include "RawData/RawDRHits.h"
#include "TrackDelivery/TDKinematicPionFit.h"
#include "TrackDelivery/TDKinematicElectronFit.h"
#include "TrackDelivery/TDKinematicFit.h"
#include "CDOffCal/DriftFunction.h"
#include "assert.h"
#include "KinematicTrajectory/KTMoveControl.h"
#include "math.h"
#include "fstream.h"
#include "Navigation/NavTrack.h"
#include "CalibratedData/CalibratedDRHit.h"
#include "DAException/DANoDataException.h"

#include "Lattice/Lattice.h"
#include "TrackFinder/SeedDRHitLink.h"
#include "TrackFitter/TrackFitDRHitLink.h"
#include "TrackDelivery/TDTrack.h"

#include "DataHandler/Record.h"
#include "DataHandler/Frame.h"
#include "FrameAccess/extract.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"
#include "FrameAccess/FAConstants.h"
#include "HistogramInterface/HIHistProf.h"
#include "CLEOConstants.hxx"
#include "DBDRDriftData.hh"
#include "DBDRDriftDatav2.hh"
#include "C3dr/DrStream.h"
#include "HistogramInterface/HINtupleVarNames.h"
#include "EventPropertiesProd/EventProperties.h"


// STL classes
// You may have to uncomment some of these or other stl headers 
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
enum {kcharge,kmom,kmomPerp,klayer,kentranceAngle,kchisq,knoSeedLayersHit,knoHitsDropped,knoLayersExpected,
      kdistanceOfClosestApproach,kmeasuredDistance,ktime,kresidual,kambiguity,kcotanTheta,kphi,kd0,kz0,kx,ky,
      kfindd0,kfindz0,kfindCurvature,kfindphi0,kfindcotanTheta,kfindchisq,kparticleCharge,kNumVars};

static const char* const kFacilityString = "Processor.GenerateDriftFunction" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: processor.cc,v 1.8 1999/02/12 00:17:52 mkl Exp $";
static const char* const kTagString = "$Name: v02_04_00 $";

//
// static data member definitions
//
  static HepJamesRandom ranJames(103489872);
  static RandFlat randomGenerator(ranJames);

//
// constructors and destructor
//
GenerateDriftFunction::GenerateDriftFunction( void )               // anal1
   : Processor( "GenerateDriftFunction" ),fitMethodParam("fitMethod",this)
  ,inputDataParam("inputData",this),versionDCAOutputParam("versionDCAOutput",this)
  ,noMuonParam("noMuon",this)
{
   report( INFO, kFacilityString ) << "here in ctor()" << endl;
     

   // ---- bind a method to a stream -----
   // These lines ARE VERY IMPORTANT! If you don't bind the 
   // code you've just written (the "action") to a stream, 
   // your code won't get executed!
  
   bind( &GenerateDriftFunction::event,    Stream::kEvent );
   bind( &GenerateDriftFunction::beginRun, Stream::kBeginRun );
   //   bind( &GenerateDriftFunction::endRun,   Stream::kEndRun );

   // do anything here that needs to be done at creation time
   // (e.g. allocate resources etc.)
   fitMethodParam.setDefault("chisquare");
   fitMethodParam.setHelpString
     ("fit method: chisqare: use only inward fit to determin DCA.    kalman: use average of DCA for inward and outward fits ");
   inputDataParam.setDefault("event");
   inputDataParam.setHelpString
     ("tells processor which input data to use:   'event': use tracking information event by event only.  'file': first read data from files listed in the file dcaSpectrumList located in the run directory. If a run is provided data will be further accumulated.");
   versionDCAOutputParam.setDefault("double");
   versionDCAOutputParam.setHelpString("tells if single sided (single) or double sided DCA output/input should be used");
   noMuonParam.setDefault(false);
   noMuonParam.setHelpString("if noMuon==true the muon histograms are not filled");
   my_noTracks=0;
}

// GenerateDriftFunction::GenerateDriftFunction( const GenerateDriftFunction& iGenerateDriftFunction )
// {
//    *this = iGenerateDriftFunction;
// }

GenerateDriftFunction::~GenerateDriftFunction()                    // anal5
{
   report( DEBUG, kFacilityString ) << "here in dtor()" << endl;
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}

//
// assignment operators
//
// const GenerateDriftFunction& GenerateDriftFunction::operator=( const GenerateDriftFunction& iGenerateDriftFunction )
// {
//   if( this != &iGenerateDriftFunction ) {
//      // do actual copying here, plus:
//      // "SuperClass"::operator=( iGenerateDriftFunction );
//   }
//
//   return *this;
// }

//
// member functions
//

// ------------ methods for beginning/end "Interactive" ------------
// --------------------------- init method -------------------------
void
GenerateDriftFunction::init( void )          // anal1 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in init()" << endl;

   m_NumberOfEvents=0;
   // do any initialization here based on Parameter Input by User
   // (e.g. run expensive algorithms that are based on parameters
   //  specified by user at run-time)
   for(UInt32 layer=1;layer<ADRSenseWireStore::kNumberOfLayers+1;++layer)
     {
       my_spectrumLayer[layer] = new Spectrum("layer",layer,my_histDir,versionDCAOutputParam.value());
     }
   for(UInt32 crateTQT=1;crateTQT<kNoOfTQTCrates+1;++crateTQT)
     {
       //       my_spectrumTQTCrate[crateTQT] = new Spectrum("tqt crate",48+crateTQT,my_histDir,versionDCAOutputParam.value());
     }
   
   my_spectrumAll = new Spectrum("allWires",48,my_histDir,versionDCAOutputParam.value());

   for(UInt32 chargeBin=0;chargeBin<kNoOfChargeBins;++chargeBin)
     {
       my_spectrumCharge[chargeBin] = new Spectrum("charge bin",48+kNoOfTQTCrates+chargeBin+1,my_histDir,versionDCAOutputParam.value());
     }
   if(!noMuonParam.value())
     {
       my_spectrumAllMuon = new Spectrum("allWiresMuonConstants",86,my_histDir,versionDCAOutputParam.value());
     }

   if(fitMethodParam.value() == "kalman")
     {
       report(INFO,kFacilityString) << " you should use the kalman filter!!! " << fitMethodParam.value() << endl;
     }
   else
     {
       report(INFO,kFacilityString) << " you should NOT use the kalman filter!!! " << fitMethodParam.value() << endl;
     }
}


// -------------------- terminate method ----------------------------
void
GenerateDriftFunction::terminate( void )     // anal5 "Interactive"
{
  FILE *out;
  out = fopen("dcaSpectrum","w");
  if(!out)
    {
      report(ERROR,kFacilityString)<<"cannot open output file dcaSpectrum" << endl;
      return;
    }
  
  report( INFO, kFacilityString ) << "here in terminate()" << endl;
  for(UInt32 layer=1;layer<ADRSenseWireStore::kNumberOfLayers+1;layer++)
    {
      //      report(INFO,kFacilityString) << "help1: " << layer << endl;
      if(inputDataParam.value() == "file")
	{
	  my_spectrumLayer[layer]->findConstants();
	}
      //      report(INFO,kFacilityString) << "help2: " << layer << endl;
      my_spectrumLayer[layer]->writeDCASpectrum(out);
      //      report(INFO,kFacilityString) << "layer: " << layer << endl;
    }
  if(inputDataParam.value() == "file")
    {
      my_spectrumAll->findConstants();
    }
  my_spectrumAll->writeDCASpectrum(out);
  fclose(out);
  if(inputDataParam.value() == "file")
    {
      writeDriftData();
    }

   // do anything here BEFORE New Parameter Change
   // (e.g. write out result based on parameters from user-input)
 
}

// ---------------- standard place to book histograms ---------------
void
GenerateDriftFunction::hist_book( TBHistoManager& driftSpectraManager)
{
  report(DEBUG,kFacilityString) << " here in hist_book" << endl;
   my_histDir = driftSpectraManager.defaultDir();
  // RS = Spacelike RMS-residual  = DC-DM
  // RT = Timelike RMS-residual   = |DC|-|DM| 
  // DC = Mean Fitted Distance of closest approach
  // DM = actual drift 
  // T  = drift time 
  // D  = (DM+DC)/2
  // N  = counts in bin...
  // <> = profile histogram (we would also make a histogram showing
  //     the RMS from the original profile histogram). 

  // For each layer:
  //   signed <D> vs T 
  //   <RS>  vs signed D
  //   <RS>  vs T 
  //   <RT>  vs T
  //   <RS>  vs Z
  //   <RT>  vs Z 
  //    DM   vs DC scatterplot  
  //    R    vs Z 
  //    N    vs <RS>  for |D|<0.2,0.2-0.7,>0.7 (inner/midcell/outer)
  //    N    vs <RT>  for |D|<0.2,0.2-0.7,>0.7 (inner/midcell/outer)
  //    N    vs D 
  //    N    vs T 
  //    N    vs Z 

  report( DEBUG, kFacilityString ) << "here in hist_book()" << endl;
  histCotanTheta = driftSpectraManager.histogram(1,"cotan theta",240,-2.4,2.4);
  histD0Sum = driftSpectraManager.histogram(2,"sum of d0's for 2 track events",100,-0.005,0.005);
  histImpactZ    = driftSpectraManager.histogram(3,"impact z track1-track2",100,-0.1,0.1);
  histXvsY       = driftSpectraManager.histogram(4,"impact x vs y",100,-0.01,0.01,100,-0.01,0.01);
  histXvsYPhi[0] = driftSpectraManager.histogram(5,"impact x vs y phi lt 1.57" ,100,-0.01,0.01,100,-0.01,0.01);
  histXvsYPhi[1] = driftSpectraManager.histogram(6,"impact x vs y phi lt 3.14" ,100,-0.01,0.01,100,-0.01,0.01);
  histXvsYPhi[2] = driftSpectraManager.histogram(7,"impact x vs y phi lt 4.71" ,100,-0.01,0.01,100,-0.01,0.01);
  histXvsYPhi[3] = driftSpectraManager.histogram(8,"impact x vs y phi lt 2pi" ,100,-0.01,0.01,100,-0.01,0.01);
  histD0vsPhi    = driftSpectraManager.histogram(9,"dca to origin vs phi", 100,-0.01,0.01,100,-0.8,7.);
  histMomentumResolution = driftSpectraManager.histogram(10,"momentum distribution", 200, 4.,6.);
  histChargeDistribution = driftSpectraManager.histogram(11,"charge distribution",1000,0,10000);
  histNoOfHitsPerTrack = driftSpectraManager.histogram(12,"no of hits per track",50,0,50);
  histNoOfHitsPerTrackFinder = driftSpectraManager.histogram(13,"no of hits per track found by finder",50,0,50);
  histMomentumResolutionMuon = driftSpectraManager.histogram(14,"momentum distribution using muon fit", 200, 4.,6.);
  histMomVsPhiPosProf = driftSpectraManager.profile(15,"momentum vs phi", 16, 0., 6.28319, 5.15, 5.4,HIHistProf::kErrorOnMean);
  histMomVsPhiNegProf = driftSpectraManager.profile(16,"momentum vs phi", 16, 0., 6.28319, 5.15, 5.4,HIHistProf::kErrorOnMean);
  histZMissVsCotThetaProf = driftSpectraManager.profile(17,"Z miss vs cot theta",20,-2.0,2.0,-0.03,0.03,HIHistProf::kErrorOnMean);
  histCotanThetaSum = driftSpectraManager.histogram(18,"sum of cotan theta for 2 track events",200,-0.1,0.1);

  HINtupleVarNames varNames(kNumVars);
  varNames.addVar(kcharge,"charge");
  varNames.addVar(kmom,"mom");
  varNames.addVar(kmomPerp,"momperp");
  varNames.addVar(klayer,"layer");
  varNames.addVar(kentranceAngle,"entangle");
  varNames.addVar(kchisq,"chisq");
  varNames.addVar(knoSeedLayersHit,"nselayhi");
  varNames.addVar(knoHitsDropped,"nhitdrop");
  varNames.addVar(knoLayersExpected,"noexphit");
  varNames.addVar(kdistanceOfClosestApproach,"dca");
  varNames.addVar(kmeasuredDistance,"drift");
  varNames.addVar(ktime,"time");
  varNames.addVar(kresidual,"resid");
  varNames.addVar(kparticleCharge,"pcharge");
  varNames.addVar(kcotanTheta,"cotanThe");
  varNames.addVar(kphi,"phi");
  varNames.addVar(kd0,"d0");
  varNames.addVar(kz0,"z0");
  varNames.addVar(kx,"x");
  varNames.addVar(ky,"y");
  varNames.addVar(kfindd0,"fdd0");
  varNames.addVar(kfindz0,"fdz0");
  varNames.addVar(kfindCurvature,"fdcurv");
  varNames.addVar(kfindphi0,"fdphi0");
  varNames.addVar(kfindcotanTheta,"fdcotThe");
  varNames.addVar(kfindchisq,"fdchisq");
  varNames.addVar(kambiguity,"ambig");
  ntupStudyBhaBhas = driftSpectraManager.ntuple(99,"study bhabhas", kNumVars,100000,varNames.names());

}

// --------------------- methods bound to streams -------------------
ActionBase::ActionResult
GenerateDriftFunction::event( Frame& iFrame)          // anal3 equiv.
{
   report( DEBUG, kFacilityString ) << "here in event()" << endl;
   ++m_NumberOfEvents;
   if(m_NumberOfEvents%1000 == 1)
     {
       report(INFO,kFacilityString) << "processing event number: " << m_NumberOfEvents << endl;
     }
   FAItem<EventProperties> eventProperty;
   extract(iFrame.record(Stream::kEvent),eventProperty);

   if(!eventProperty->electronPairEvent())
     {
       // do in here things with hadrons 
       return ActionBase::kPassed;
     }

   //
   // now insure good quality bhabhas!
   //


   //
   // Extract navTracks 
   //
   FATable< NavTrack > navTracks;
   extract(iFrame.record(Stream::kEvent),navTracks);
   
   typedef FATable<NavTrack>::const_iterator TrackNavItr;

   if(navTracks.size()!=2)
     {
       return ActionBase::kPassed;
     }
   double sumCotanTheta = 0.;
   double sumD0 = 0.;
   UInt32 trackNo = 0;
   float impactZ[3];
   for ( TrackNavItr trackLoop1 = navTracks.begin(); trackLoop1 != navTracks.end(); ++trackLoop1)
     {
       if((!trackLoop1->electronQuality().valid())||(!trackLoop1->electronHelix().valid())
	  ||(!trackLoop1->exitElectronQuality().valid())||(!trackLoop1->exitElectronHelix().valid())
	  ||(!trackLoop1->electronFit().valid())||(!trackLoop1->exitElectronFit().valid()))
	 {
	   report(DEBUG,kFacilityString) << " something on the track is not valid: electronQuality: " 
					 << trackLoop1->electronQuality().valid() << " electronHelix: " 
					 << trackLoop1->electronHelix().valid() << " electronFit: " 
					 << trackLoop1->electronFit().valid()<< endl;
	   report(DEBUG,kFacilityString) << " exitElectronQuality: " << trackLoop1->exitElectronQuality().valid() 
					 << " exitElectronHelix: " << trackLoop1->exitElectronHelix().valid() 
					 << " exitElectronFit: " << trackLoop1->exitElectronFit().valid()<< endl;
	   return ActionBase::kPassed;
	 }
       const TRTrackFitQuality &electronQuality = (*(*trackLoop1).electronQuality());
       const TRTrackFitQuality &exitElectronQuality = (*(*trackLoop1).exitElectronQuality());
       if((electronQuality.fitAbort())
	  ||(electronQuality.degreesOfFreedom() < 30) || (exitElectronQuality.degreesOfFreedom()<30) 
	  || (electronQuality.chiSquare()/electronQuality.degreesOfFreedom()>2.5)
	  || (exitElectronQuality.chiSquare()/exitElectronQuality.degreesOfFreedom()>2.5))
	 {
	   report(DEBUG,kFacilityString) << "does not use track no: " << (*trackLoop1).identifier()
				       << " electron chisq: " << electronQuality.chiSquare() 
				       << " dof: " << electronQuality.degreesOfFreedom()
				       << " exitElectron chisq: " << exitElectronQuality.chiSquare() 
				       << " dof: " << exitElectronQuality.degreesOfFreedom() << endl;
	   return ActionBase::kPassed;
	 }
       if(fabs(trackLoop1->electronHelix()->cotTheta())>2.4) // largest physical cotTheta value
	 {
	   return ActionBase::kPassed;
	 }
       if(trackLoop1->electronFit()->pmag()<5. || trackLoop1->electronFit()->pmag()>5.5)
	 {
	   return ActionBase::kPassed;
	 }
       ++trackNo;
       sumCotanTheta += trackLoop1->electronHelix()->cotTheta();
       sumD0 += trackLoop1->electronHelix()->d0();
       impactZ[trackNo]=trackLoop1->electronHelix()->z0();
     }
   histCotanThetaSum->fill(sumCotanTheta);
   histD0Sum->fill(sumD0);
   histImpactZ->fill(impactZ[1]-impactZ[2]);
   if(fabs(sumCotanTheta)>0.04) // usually 0.04
     {
       // > ~ 3 sigma width of cotanTheta[0]+cotanTheta[1] probably not a bhabah event
       return ActionBase::kPassed;
     }
   if(fabs(sumD0)>0.00075)
     {
       return ActionBase::kPassed;
     }

   if(fabs(impactZ[1]-impactZ[2])>0.02)
     {
       return ActionBase::kPassed;
     }
   float ntuplearray[kNumVars] = {0};
   //
   // to look up the hit id's for a given track I use the lattice
   //
   FAItem <SeedTrackDRHitLattice> seedHits;
   extract (iFrame.record(Stream::kEvent),seedHits);
   if(!seedHits.valid())
     {
       report( ERROR, kFacilityString ) << "Lattice unvalid" << seedHits.valid() << endl;
       return ActionBase::kPassed;
     }
   //
   // extract drift chamber geometry in order to be able to determine the radius of a particular wire (hitId)
   //
   FAItem <ADRSenseWireStore> wireStore;
   extract(iFrame.record(Stream::kDRAlignment),wireStore); 
   if(!wireStore.valid())
     {
       report(ERROR,kFacilityString) << "bad Geometry" << endl;
       assert(wireStore.valid());
     }   





   typedef NavTrack::DRHitLinkTable::const_iterator LinkItr;
   typedef FATable< TRSeedTrack > TrackTable;
   typedef NavTrack::SeedDRHitLinkTable::const_iterator SeedLinkItr;

   //
   // extract exitElectronLinks
   //

   FAItem<ExitElectronFitDRHitLattice> exitElectronLinks;
   extract (iFrame.record(Stream::kEvent),exitElectronLinks);
   if(!exitElectronLinks.valid())
     {
       report( ERROR,kFacilityString) << "exitElectronLinks unvalid" << exitElectronLinks.valid() << endl;
       return ActionBase::kPassed;
     }

   //
   // extract Calibrated Drift hits to get times
   //
   FATable<CalibratedDRHit> calHits;
   extract(iFrame.record(Stream::kEvent),calHits);
   if(!calHits.valid())
     {
       report( ERROR, kFacilityString ) << "calHits unvalid" << calHits.valid() << endl;
       return ActionBase::kPassed;
     }

   //
   // extract Calibrated Drift hits to get times
   //
   FATable<CollatedRawDRHit> colHits;
   extract(iFrame.record(Stream::kEvent),colHits);
   if(!calHits.valid())
     {
       report( ERROR, kFacilityString ) << "calHits unvalid" << colHits.valid() << endl;
       return ActionBase::kPassed;
     }

   trackNo = 0;
   //
   // This is the main loop over all Nav tracks
   //
   float impactRPhi[3];
   float zMissPos = 0.;
   float zMissNeg = 0.;
   float zMissCotTheta = 0.;
   for ( TrackNavItr track = navTracks.begin(); track != navTracks.end(); ++track)
     { 
       const TRTrackFitQuality &electronQuality = (*(*track).electronQuality());
       ntuplearray[kchisq] = electronQuality.chiSquare()/electronQuality.degreesOfFreedom();
       if(!electronQuality.fitAbort())
	 {
	   ++my_noTracks;
	   ++trackNo;
	   int trackId = (*track).identifier();
	   
	   // 
	   // get the seed link FATable from the lattice as presented by NavTrack
	   //
	   const NavTrack::SeedDRHitLinkTable& seedLinks = (*(*track).seedDRHitLinks());
	   if(seedLinks.size()==0)
	     {
	       report(ERROR, kFacilityString) << "seedDRHitLinks unvalid: " << endl;
	       return ActionBase::kPassed;
	     }
	   /*
	     const NavTrack::TRSeedTrackQuality& seedQuality = (*(*track).seedQuality());
	     if(seedQuality.size()==0)
	     {
	     report(ERROR,kFacilityString) << "seedQuality unvalid: " << endl;
	     return ActionBase::kPassed;
	     }
	   */
	   
	   //
	   // get the hits for the electron fit as presented by NavTrack
	   //
	   const NavTrack::DRHitLinkTable& electronHitLinks = (*(*track).electronDRHitLinks());
	   if(electronHitLinks.size()==0)
	     {
	       report(ERROR, kFacilityString) << "electronDRHitLinks unvalid: " << endl;
	       return ActionBase::kPassed;
	     }
	   float cotTheta = track->electronHelix()->cotTheta();
	   histCotanTheta->fill(cotTheta);
	   if(!noMuonParam.value())
	     {
	       if(track->muonFit()->charge() == 1)
		 {
		   zMissPos=track->muonHelix()->z0();
		   zMissCotTheta = track->muonHelix()->cotTheta();
		 }
	       else
		 {
		   zMissNeg=track->muonHelix()->z0();
		 }
	     }
	   histXvsY->fill(track->electronFit()->x(),track->electronFit()->y());
	   histD0vsPhi->fill(track->electronHelix()->d0(),track->electronHelix()->phi0());
	   histMomentumResolution->fill(track->electronFit()->pmag());
	   if(!noMuonParam.value())
	     {
	       histMomentumResolutionMuon->fill(track->muonFit()->pmag());
	     }
	   if(track->electronFit()->charge()>0)
	     {
	       histMomVsPhiPosProf->fill(track->electronHelix()->phi0(),track->electronFit()->pmag());
	     }
	   else
	     {
	       histMomVsPhiNegProf->fill(track->electronHelix()->phi0(),track->electronFit()->pmag());
	     }
	   if(track->electronHelix()->phi0() < 1.57)
	     {
	       histXvsYPhi[0]->fill(track->electronFit()->x(),track->electronFit()->y());
	     }
	   else if(track->electronHelix()->phi0() < 3.14)
	     {
	       histXvsYPhi[1]->fill(track->electronFit()->x(),track->electronFit()->y());
	     }
	   else if(track->electronHelix()->phi0() < 4.71)
	     {
	       histXvsYPhi[2]->fill(track->electronFit()->x(),track->electronFit()->y());
	     }
	   else
	     {
	       histXvsYPhi[3]->fill(track->electronFit()->x(),track->electronFit()->y());
	     }
	   
	   
	   const TRSeedTrackQuality &seedQuality = (*(*track).seedQuality());
	   
	   ntuplearray[kmom] = track->electronFit()->pmag();	  
	   ntuplearray[kmomPerp] = track->electronFit()->pperp();
	   ntuplearray[kchisq] = electronQuality.chiSquare()/electronQuality.degreesOfFreedom();
	   ntuplearray[knoSeedLayersHit] = seedQuality.numberHits();
	   ntuplearray[knoHitsDropped] = electronQuality.numberHitsDropped();
	   ntuplearray[knoLayersExpected] = electronQuality.numberHitsExpected();
	   ntuplearray[kparticleCharge] = track->electronFit()->charge();
	   ntuplearray[kcotanTheta] = track->electronHelix()->cotTheta();
	   ntuplearray[kphi] = track->electronHelix()->phi0();
	   ntuplearray[kd0] = track->electronHelix()->d0();
	   ntuplearray[kz0] = track->electronHelix()->z0();
	   ntuplearray[kx] = track->electronFit()->x();
	   ntuplearray[ky] = track->electronFit()->y();
	   ntuplearray[kfindd0] = track->seedTrack()->d0();
	   ntuplearray[kfindz0] = track->seedTrack()->z0();
	   ntuplearray[kfindCurvature] = track->seedTrack()->curvature();
	   ntuplearray[kfindphi0] = track->seedTrack()->phi0();
	   ntuplearray[kfindcotanTheta] = track->seedTrack()->cotTheta();
	   ntuplearray[kfindchisq] = seedQuality.chiSquare()/seedQuality.degreesOfFreedom();
	   // 
	   // loop over hits (hit links) of the electron nav track fit
	   // 
	   LinkItr lFinished( electronHitLinks.end() );
	   for ( LinkItr link( electronHitLinks.begin() ) ; link != lFinished ; ++link )
	     { 
	       int hitId=(*(*link)->rightID()); 	   // get the hit id
	       
	       SeedTrackDRHitLattice::Links seedLinks; // link to the seedtrack-hit lattice
	       //
	       // FATable of seedTrackDRHitLattice -> connectLinks(navtrackid,hitId,seedTrackDRHitLatticeLink)
	       //
	       seedHits->connectLinks((*track).identifier(),hitId,seedLinks);
	       
	       //
	       // extract hit data from seedTrackDRHitLatticeLink: all we need is the signed drift distance
	       // this drift distance has the sign assigned from pattern recognition
	       //
	       
	       //	   double signedDriftDistance = seedLinks[0]->linkData().signedDriftDistance();
	       double signedDriftDistance = (*link)->linkData().signedDriftDistance()  ;
	       //
	       // extract the rest of the data from CalibratedDRHIT
	       //
	       FATable<CalibratedDRHit>::const_reference calHit = calHits[hitId];
	       FATable<CollatedRawDRHit>::const_reference colHit = colHits[hitId];
	       int daqid = colHit.daqId();
	       float driftTime = calHit.time(); // time in pico seconds!
	       double measuredSigma2 = 1./calHit.weight();
	       int layer = calHit.layer();
	       float charge = calHit.charge();	   
	       int chargeBin;
	       int noHitsOnWire = calHit.nTDC();
	       if(noHitsOnWire == 1) 
		 {
		   histChargeDistribution->fill(charge);
		   chargeBin = int(charge/100);
		 }
	       else
		 {
		   chargeBin = 999;
		 }
	       if((layer<1) || layer>ADRSenseWireStore::kNumberOfLayers)
		 {
		   report(ERROR,kFacilityString) << " layer number not allowed " << layer << endl;
		   break;
		 }
	       double driftDistance = calHit.distance();
	       
	       UInt32 crateTQT = my_TQTMap->crate(daqid);
	       if(crateTQT < 0 || crateTQT > kNoOfTQTCrates)
		 {
		   report(ERROR,kFacilityString) << " impossible tqt crate number: " << crateTQT << endl;
		   break;
		 }
	       //	   hist_hitid->fill(hitId);
	       //
	       // The residual resides in the NavTrack link to the hit 
	       // These are the residuals for the inward fit (Kalman).
	       // The Fit starts at layer 47 and goes to the layer to which the
	       // current hit belongs. There it stops not fitting the current hit.
	       // The residual therefore is not taking into account any information 
	       // from layers inside the one the current hit belongs to.
	       //
	       double residual = (*link)->linkData().residual();
	       double residualSigma2 = pow((*link)->linkData().residualError(),2);
	       //
	       // We are interested in the residual for the track taking all but the current 
	       // hit into account for the time beeing we average the residuals of incoming and
	       // outgoing fit (weighted average). 
	       //
	       report(DEBUG,kFacilityString) << "(*link)->linkData().used(): " << ((*link)->linkData().used() ? 1 : 0) << endl;
	       const ExitElectronFitDRHitLattice::Link* exitElectronTrackLink 
		 = (*exitElectronLinks).connectLink(trackId,hitId); 
	       // trackId has NavTrackId which is SeedTrackID, exitTrackId has track id from fitter.
	       if(exitElectronTrackLink==0) // if true this hit was not used on the exitlink!
		 {
		   report(DEBUG, kFacilityString) << "(*exitElectronLinks).connectLink(trackId,hitId) does not exist. Layer no: " 
						  << layer << " Track ID: " << trackId << " exitTrackId: " << trackId << endl;
		 }
	       else
		 {
		   double combinedDCA;
		   if(fitMethodParam.value() == "kalman")
		     {
		       
		       combinedDCA = ((*exitElectronTrackLink).linkData().signedDcaToWire()    
				      * pow((*link)->linkData().signedDcaError(),2)
				      + (*link)->linkData().signedDcaToWire()  
				      *  pow((*exitElectronTrackLink).linkData().signedDcaError(),2))
			 / (pow((*link)->linkData().signedDcaError(),2) 
			    + pow((*exitElectronTrackLink).linkData().signedDcaError(),2));
		     }
		   else
		     {
		       combinedDCA =  (*link)->linkData().signedDcaToWire();
		     }
		   my_spectrumLayer[layer]->SetValues(driftTime/1000.,signedDriftDistance,combinedDCA,residual,cotTheta);
		   //	       my_spectrumTQTCrate[crateTQT]->SetValues(driftTime/1000.,signedDriftDistance,combinedDCA,residual,cotTheta);
		   my_spectrumAll->SetValues(driftTime/1000.,signedDriftDistance,combinedDCA,residual,cotTheta);
		   if(chargeBin>=0 && chargeBin < kNoOfChargeBins)
		     {
		       my_spectrumCharge[chargeBin]->SetValues(driftTime/1000.,signedDriftDistance,combinedDCA,residual,cotTheta);
		     }
		   ntuplearray[kcharge] = charge;
		   ntuplearray[klayer] = layer;
		   float entranceAngle = asin((*link)->linkData().sinTrackToRadial());
		   ntuplearray[kentranceAngle] = entranceAngle;
		   ntuplearray[kdistanceOfClosestApproach] = combinedDCA;
		   ntuplearray[kmeasuredDistance] = signedDriftDistance;
		   ntuplearray[ktime] = driftTime/1000;
		   ntuplearray[kresidual] = residual;
		   if(combinedDCA>0)
		     {
		       ntuplearray[kambiguity]=1.;
		     }
		   else
		     {
		       ntuplearray[kambiguity]=-1.;
		     }
		   if(my_noTracks<5000)
		     {
		       ntupStudyBhaBhas->fill(ntuplearray);
		     }
		 }
	     }
	   if(!noMuonParam.value())
	     {
	       const NavTrack::DRHitLinkTable& muonHitLinks = (*(*track).muonDRHitLinks());
	       if(muonHitLinks.size()==0)
		 {
		   report(ERROR, kFacilityString) << "muonDRHitLinks unvalid: " << endl;
		   return ActionBase::kPassed;
		 }
	       LinkItr lMuonFinished( muonHitLinks.end() );
	       for ( LinkItr muonlink( muonHitLinks.begin() ) ; muonlink != lMuonFinished ; ++muonlink )
		 { 
		   int hitId=(*(*muonlink)->rightID()); 	   // get the hit id
		   double muonresidual = (*muonlink)->linkData().residual();
		   double muonCombinedDCA =  (*muonlink)->linkData().signedDcaToWire();
		   double muonSignedDriftDistance = (*muonlink)->linkData().signedDriftDistance()  ;
		   FATable<CalibratedDRHit>::const_reference muonCalHit = calHits[hitId];
		   float muonDriftTime = muonCalHit.time(); // time in pico seconds!
		   
		   my_spectrumAllMuon->SetValues(muonDriftTime/1000.,muonSignedDriftDistance,muonCombinedDCA,muonresidual,cotTheta);
		   
		 }
	     }
	 }
     }
   if(zMissPos!=0. && zMissNeg != 0.)
     {
       //	   report(INFO,kFacilityString) << "zMissPos: " << zMissPos << " zMissNeg: " << zMissNeg << " zMissCotTheta: " << zMissCotTheta << endl;
       histZMissVsCotThetaProf->fill(zMissCotTheta,zMissPos-zMissNeg);
     }

   report(DEBUG,kFacilityString) << "end "<< endl;
   return ActionBase::kPassed;
}
ActionBase::ActionResult
GenerateDriftFunction::beginRun( Frame& iFrame)       // anal2 equiv.
{
  report( DEBUG, kFacilityString ) << "here in beginRun()" << endl;
  extract(iFrame.record(DrStream::kElecMap),my_TQTMap);
  if(inputDataParam.value() == "file")
    {
      FILE *asciiIn;
      asciiIn = fopen("dcaSpectrumList","r");
      if(!asciiIn)
	{
	  report(ERROR,kFacilityString)<<"cannot open input file dcaSpectrumList" << endl;
	  return ActionBase::kPassed;
	}
      int noFiles;
      UInt32 nextBin;
      char fileName[256];
      char longFileName[256];
      char name[256];
      fscanf(asciiIn,"%i",&noFiles);
      report(INFO,kFacilityString)<<"opened file dcaSpectrumList, no of files to read: " << noFiles << endl;
      FILE *in;
      ADRSenseWireStore::LayerWire myLayerWire;  
      for(unsigned int inputFileNo = 0; inputFileNo < noFiles; ++inputFileNo)
	{
	  UInt32 runNo;
	  UInt32 noEvents;
	  UInt32 noTracks;
	  fscanf(asciiIn,"%s",&fileName);
	  report(INFO,kFacilityString) << "inputFileNo: " << inputFileNo << " load file: " << fileName << endl;
	  in = fopen(fileName,"r");
	   if(!in )
	     {
	       report(ERROR,kFacilityString)<<"cannot open input file " << fileName << endl;
	       return ActionBase::kPassed;
	     }
	   for(UInt32 layer=1;layer<ADRSenseWireStore::kNumberOfLayers+1;layer++)
	     {
	       my_spectrumLayer[layer]->readDCASpectrum(in);
	       //	       report(INFO,kFacilityString) << "layer: " << layer << endl;
	     }
	   my_spectrumAll->readDCASpectrum(in);
	   fclose(in);
	}
    }
  FAConstants<DBDRDriftDatav2> holdDRDriftData;  
  FAConstants<DBDRDriftData> holdDRDriftDataOld;
  try
    {
      extract(iFrame.record(DrStream::kDriftDatav2),holdDRDriftData);
    }
  catch( DAExceptionBase&  aException )
    {
      extract(iFrame.record(DrStream::kDriftData),holdDRDriftDataOld);
      report(WARNING,kFacilityString) << aException.what() << endl;
    }

  if(holdDRDriftData.valid())
    {
      typedef FAConstants<DBDRDriftDatav2>::const_iterator DRDriftDataItr;
      for(DRDriftDataItr driftConstant = holdDRDriftData.begin(); driftConstant != holdDRDriftData.end();++driftConstant)
	{
	  float driftTime = (*driftConstant).get_Time();
	  float driftDistance = (*driftConstant).get_Dist();
	  float index = (*driftConstant).get_Indx();
	  UInt32 driftSignIndex = int((index+5000)/10000) - int((index+50000)/100000)*10;
	  UInt32 layer = int((index+5000000)/10000000);
	  if(layer<1 || layer>47)
	    {
	      report(ERROR,kFacilityString)  << " layer in driftfunction out of range: " << layer << endl;
	      break;
	    }
	  UInt32 driftTimeBin = int(driftTime/float(kNoOfnsPerBin)+0.5);
	  if((driftSignIndex < 2) || (driftSignIndex > 3) || (driftTimeBin < 0) || (driftTimeBin > kNoOfTimeBins) )
	    {
	      if(driftSignIndex != 1)
		{
		  report(ERROR,kFacilityString) << " something funny with drift functions: driftSignIndex: " << driftSignIndex 
						<< " driftTimeBin: " << driftTimeBin << endl;
		}
	    }
	  else
	    {
	      my_spectrumLayer[layer]->SetTimeToDriftFunctionValues(driftSignIndex,driftTimeBin,driftDistance);
	    }
	}     
    }
  else
    {
      typedef FAConstants<DBDRDriftData>::const_iterator DRDriftDataItr;
      for(DRDriftDataItr driftConstant = holdDRDriftDataOld.begin(); driftConstant != holdDRDriftDataOld.end();++driftConstant)
	{
	  float driftTime = (*driftConstant).get_Time();
	  float driftDistance = (*driftConstant).get_Dist();
	  float index = (*driftConstant).get_Indx();
	  UInt32 driftSignIndex = int((index+5000)/10000) - int((index+50000)/100000)*10;
	  UInt32 layer = int((index+5000000)/10000000);
	  if(layer<1 || layer>47)
	    {
	      report(ERROR,kFacilityString)  << " layer in driftfunction out of range: " << layer << endl;
	      break;
	    }
	  UInt32 driftTimeBin = int(driftTime/float(kNoOfnsPerBin)+0.5);
	  if((driftSignIndex < 2) || (driftSignIndex > 3) || (driftTimeBin < 0) || (driftTimeBin > kNoOfTimeBins) )
	    {
	      if(driftSignIndex != 1)
		{
		  report(ERROR,kFacilityString) << " something funny with drift functions: driftSignIndex: " << driftSignIndex 
						<< " driftTimeBin: " << driftTimeBin << endl;
		}
	    }
	  else
	    {
	      my_spectrumLayer[layer]->SetTimeToDriftFunctionValues(driftSignIndex,driftTimeBin,driftDistance);
	    }
	}     
    }


  return ActionBase::kPassed; 
}
 

ActionBase::ActionResult
GenerateDriftFunction::endRun( Frame& iFrame)         // anal4 equiv.
{
   report( DEBUG, kFacilityString ) << "here in endRun()" << endl;
   return ActionBase::kPassed;
}

void GenerateDriftFunction::writeDriftData()
{
  DBDRDriftDatav2* driftDataArray;
  driftDataArray = new DBDRDriftDatav2[3*kNoOfTimeBins*ADRSenseWireStore::kNumberOfLayers];
  UInt32 id=0;
  UInt32 bin;
  UInt32 layer;
  for (layer=1;layer<ADRSenseWireStore::kNumberOfLayers+1;++layer)
    {
      for (bin=0; bin<kNoOfTimeBins; ++bin)
	{
	  if((id == 0) || (driftDataArray[id-1].get_Dist() != my_spectrumLayer[layer]->getDriftDistance(bin)))
	    {
	      driftDataArray[id].set_Identifier(id+1);
	      driftDataArray[id].set_Time(float(bin*kNoOfnsPerBin));
	      driftDataArray[id].set_Dist(float(my_spectrumLayer[layer]->getDriftDistance(bin)));
	      driftDataArray[id].set_Indx(int(bin+10000+layer*10000000));
	      ++id;
	    }
	  else
	    {
	      report(DEBUG,kFacilityString) << " bin: " << bin << " dist: " << my_spectrumLayer[layer]->getDriftDistance(bin) << endl;
	    }
	}
    }
  for (layer=1;layer<ADRSenseWireStore::kNumberOfLayers+1;++layer)
    {
      for (bin=0; bin<kNoOfTimeBins; ++bin)
	{	  
	  if(driftDataArray[id-1].get_Dist() != my_spectrumLayer[layer]->getPosDriftDistance(bin))
	    {
	      driftDataArray[id].set_Identifier(id+1);
	      driftDataArray[id].set_Time(float(bin*kNoOfnsPerBin));
	      driftDataArray[id].set_Dist(float(my_spectrumLayer[layer]->getPosDriftDistance(bin)));
	      driftDataArray[id].set_Indx(int(bin+20000+layer*10000000));
	      ++id;
	    }
	}
    }
  for (layer=1;layer<ADRSenseWireStore::kNumberOfLayers+1;++layer)
    {
      for (bin=0; bin<kNoOfTimeBins; ++bin)
	{
	  if(driftDataArray[id-1].get_Dist() != my_spectrumLayer[layer]->getNegDriftDistance(bin))
	    {	      
	      driftDataArray[id].set_Identifier(id+1);
	      driftDataArray[id].set_Time(float(bin*kNoOfnsPerBin));
	      driftDataArray[id].set_Dist(float(my_spectrumLayer[layer]->getNegDriftDistance(bin)));
	      driftDataArray[id].set_Indx(int(bin+30000+layer*10000000));
	      ++id;
	    }
	}
    }

  //  CLEOConstants<DBDRDriftData> const1(driftDataArray,3*kNoOfTimeBins*ADRSenseWireStore::kNumberOfLayers);
  CLEOConstants<DBDRDriftDatav2> const1(driftDataArray,id);
  const1.writeToFile("DRDriftDatav2.drdriftdatav2");
}


