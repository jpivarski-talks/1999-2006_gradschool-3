// compiler bug flags
#include "Experiment/Experiment.h"

// system include files
#include <fstream.h>
#include <iostream.h>

// compiler bug fixes 
#if defined(AMBIGUOUS_STRING_FUNCTIONS_BUG)
#include <string>
#endif  
#if defined(STL_TEMPLATE_DEFAULT_PARAMS_FIRST_BUG)
#include <vector>
#include <map>
#include <set>
#endif /* STL_TEMPLATE_DEFAULT_PARAMS_FIRST_BUG */

// user include files
#include "Experiment/report.h"
#include "GenerateDriftFunction/Spectrum.h"
#include "math.h"

#include "BinaryDelivery/ByteSwapping.h"

static const char* const kFacilityString = "Processor.GenerateDriftFunction.Spectrum" ;

Spectrum::Spectrum()
{
    report(DEBUG,kFacilityString) << " here in default constructor" << endl;
    memset(my_DCASpectrumPos,0,sizeof(my_DCASpectrumPos));
    memset(my_DCASpectrumNeg,0,sizeof(my_DCASpectrumNeg));
    memset(my_DCASpectrum,0,sizeof(my_DCASpectrum));
    //    memset(my_DCASpectrumDistances,0,sizeof(my_DCASpectrumDistances));
    memset(my_integratedDriftTimes,0,sizeof(my_integratedDriftTimes));
    memset(my_driftTimes,0,sizeof(my_driftTimes));
}

Spectrum::Spectrum(string spectrumId,UInt32 histNumber,HIHistDir *histDir,string outputVersion)
{
  report(DEBUG,kFacilityString) << " here in constructor declaring histograms. spectrumId: " << spectrumId 
				<< " histNumber: " << histNumber << " HIHistDir: " << histDir << endl;
  my_outputVersion=outputVersion;
  my_spectrumId = spectrumId;
  UInt32 histid = 100*histNumber;
  char name[256];
  memset(my_DCASpectrumPos,0,sizeof(my_DCASpectrumPos));
  memset(my_DCASpectrumNeg,0,sizeof(my_DCASpectrumNeg));
  memset(my_DCASpectrum,0,sizeof(my_DCASpectrum));
  //  memset(my_DCASpectrumDistances,0,sizeof(my_DCASpectrumDistances));
  memset(my_integratedDriftTimes,0,sizeof(my_integratedDriftTimes));
  memset(my_driftTimes,0,sizeof(my_driftTimes));
  sprintf(name,"drift Time for %s: %i",spectrumId.c_str(),histNumber);
  histDriftTime = histDir->histogram(histid+1,name,kDriftTimeWindow,0,kDriftTimeWindow);
  sprintf(name,"drift distance for %s: %i",spectrumId.c_str(),histNumber);
  histDriftDistance = histDir->histogram(histid+2,name,300,-0.01,0.01);
  sprintf(name,"residual for %s: %i",spectrumId.c_str(),histNumber);
  histResidual = histDir->histogram(histid+3,name,300,-0.005,0.005);
  sprintf(name,"time like residual for %s: %i",spectrumId.c_str(),histNumber);
  histTimeResidual = histDir->histogram(histid+4,name,300,-0.005,0.005);
  sprintf(name,"integrated drift times for %s: %i",spectrumId.c_str(),histNumber);
  histIntegratedTimes = histDir->histogram(histid+5,name,kDriftTimeWindow,0,kDriftTimeWindow);
  sprintf(name,"Distance of closesed approach for %s: %i",spectrumId.c_str(),histNumber);
  histDCA = histDir->histogram(histid+6,name,200,-0.01,0.01);
  sprintf(name,"drift distance vs distance of closesed approach for %s: %i",spectrumId.c_str(),histNumber);
  histDriftDistanceVsDCA = histDir->histogram(histid+7,name,100,-0.012,0.012,100,-0.012,0.012);
  sprintf(name,"drift time vs distance of closesed approach for %s: %i",spectrumId.c_str(),histNumber);
  histDriftTimeVsDCA = histDir->histogram(histid+8,name,100,-100,900,100,-0.012,0.012);
  sprintf(name,"time to drift function for %s: %i",spectrumId.c_str(),histNumber);
  histTimeToDriftFunction = histDir->histogram(histid+14,name,kNoOfTimeBins,0,kNoOfTimeBins,400,-0.012,0.012);
  sprintf(name,"Residual vs distance of closesed approach for %s: %i",spectrumId.c_str(),histNumber);
  histResidualVsDCA = histDir->histogram(histid+9,name,100,-0.005,0.005,100,-0.012,0.012);
  sprintf(name,"Mean of Residual vs DCA for %s: %i",spectrumId.c_str(),histNumber);
  histProfResidualVsDriftDistance = histDir->profile(histid+10,name,100,-0.012,0.012,-0.012,0.012,HIHistProf::kErrorOnMean);
  sprintf(name,"Mean of Residuals truncated to 1mm vs DCA for %s: %i",spectrumId.c_str(),histNumber);
  histProfResidualVsDriftDistanceTruncated = histDir->profile(histid+15,name,100,-0.012,0.012,-0.012,0.012,HIHistProf::kErrorOnMean);
  sprintf(name,"scale between integrated and truncated drift time calculation for %s: %i",spectrumId.c_str(),histNumber);
  histScaleDistribution = histDir->histogram(histid+11,name,kNoOfTimeBins,0,kNoOfTimeBins);
  sprintf(name,"RMS of residuals vs drift time %s: %i",spectrumId.c_str(),histNumber);
  histResidualRMSvsDriftTime = histDir->histogram(histid+12,name,kNoOfTimeBins,0.0,kDriftTimeWindow);
  sprintf(name,"no of entries per time bin for %s: %i",spectrumId.c_str(),histNumber);
  histNoOfEntriesPerTimeBin = histDir->histogram(histid+13,name,kNoOfTimeBins,0.,kNoOfTimeBins);
  sprintf(name,"residual if cotTheta gt 0.8 and lt 1.2for %s: %i",spectrumId.c_str(),histNumber);
  histResidualCotThetaPos = histDir->histogram(histid+16,name,300,-0.005,0.005);
  sprintf(name,"residual if cotTheta lt -0.8 and gt -1.2 for %s: %i",spectrumId.c_str(),histNumber);
  histResidualCotThetaNeg = histDir->histogram(histid+17,name,300,-0.005,0.005);

  //  sprintf(name,"RMS of residuals vs drift distance %s: %i",spectrumId.c_str(),histNumber);
  //  histResidualRMSvsDriftDistance = histDir->histogram(histid+13,name,kNoOfDriftDistanceBins*2+1,-kMaxDriftDistance,kMaxDriftDistance);
  for(UInt32 loopCounter=59; loopCounter<100; ++loopCounter)
    {
      sprintf(name,"residuals of dca bin %i for %s: %i",loopCounter-79,spectrumId.c_str(),histNumber);
      histResidualBins[loopCounter-59] = histDir->histogram(histid+loopCounter,name,100,-0.003,0.003);
    }
  UInt32 histDCAId = 100000+1000*histNumber;
  UInt32 histDCAId2 = 100000+1000*histNumber+kNoOfTimeBins;
  UInt32 noOfDCABinsInHist=kNoOfDCABins-60;
  for(UInt32 timeBinNo=0;timeBinNo<kNoOfTimeBins;++timeBinNo)
    {
      sprintf(name,"dca spectrum for time bin %i of layer %i",timeBinNo,histNumber);
      histDCADistTime[timeBinNo] = histDir->histogram(histDCAId+timeBinNo,name,noOfDCABinsInHist,0,noOfDCABinsInHist);
      sprintf(name,"mean and truncation for time bin %i of layer %i",timeBinNo,histNumber);
      histMeanVar[timeBinNo]=histDir->histogram(histDCAId+timeBinNo+kNoOfTimeBins,name,noOfDCABinsInHist,0,noOfDCABinsInHist);
    }
}

void Spectrum::SetValues(double driftTime, double signedDriftDistance, double combinedDCA, double residual, float cotTheta)
{
  //  report(DEBUG,kFacilityString) << " here in SetValues. driftTime" << driftTime 
  //				<< " signedDriftDistance: " << signedDriftDistance << " residual: " << residual 
  //				<< " combinedDCA: " << combinedDCA << endl;
  //  float residual = float(signedDriftDistance-combinedDCA);
  histDriftTime->fill(float(driftTime));
  histDriftDistance->fill(float(signedDriftDistance));
  histResidual->fill(float(residual));
  histTimeResidual->fill(float(fabs(combinedDCA)-fabs(signedDriftDistance)));
  histDCA->fill(float(combinedDCA));
  histDriftDistanceVsDCA->fill(float(signedDriftDistance),float(combinedDCA));
  histDriftTimeVsDCA->fill(float(driftTime),float(combinedDCA));
  histResidualVsDCA->fill(float(residual),float(combinedDCA));
  histProfResidualVsDriftDistance->fill(float(combinedDCA),float(residual));
  if((cotTheta > 0.8) && (cotTheta < 1.4))
    {
      histResidualCotThetaPos->fill(float(residual));
    }
  if((cotTheta < -0.8) && (cotTheta > -1.4))
    {
      histResidualCotThetaNeg->fill(float(residual));
    }
  if(fabs(residual)<0.001)
    {
      histProfResidualVsDriftDistanceTruncated->fill(float(combinedDCA),float(residual));
    }
  int residualBin = int(combinedDCA*1000./float(kMaxDriftDistance)*20.+20.5);
  if(residualBin>=0 && residualBin <=40)
    {
      histResidualBins[residualBin]->fill(float(residual));
    }

  //
  // integrate time spectrum
  //
  int driftTimeBin = int(driftTime);
  int DCABin = int(fabs(combinedDCA/(float(kTotalDCARange)/1000.)*float(kNoOfDCABins)));
  if((driftTimeBin>=0)&&(driftTimeBin<kDriftTimeWindow))
    {
      my_driftTimes[driftTimeBin]++;
      if(DCABin<kNoOfDCABins)
	{
	  if(signedDriftDistance<0)
	    {
	      my_DCASpectrumNeg[int(driftTimeBin/kNoOfnsPerBin)][DCABin]++;
	    }
	  else
	    {
	      my_DCASpectrumPos[int(driftTimeBin/kNoOfnsPerBin)][DCABin]++;
	    }
	  my_DCASpectrum[int(driftTimeBin/kNoOfnsPerBin)][DCABin]++;

	}
      for(int countIntegration = driftTimeBin;countIntegration<kDriftTimeWindow;countIntegration++)
	{
	  my_integratedDriftTimes[countIntegration]++;
	  histIntegratedTimes->fill(countIntegration+0.5);
	}
    }
  //  int driftDistanceBin = int(signedDriftDistance/(kMaxDriftDistance/1000.)*float(kNoOfDriftDistanceBins)+0.5)
  //                            +float(kNoOfDriftDistanceBins);
  //  if((driftDistanceBin>=0)&&(driftDistanceBin<kNoOfDriftDistanceBins*2+1))
  //    {
  //      my_DCASpectrumDistances[driftDistanceBin][DCABin]++;
  //    }
}

void Spectrum::findConstants()
{
  UInt32 setHists=1;
  getConstants(my_DCASpectrum, my_driftDistances, setHists);
  if(my_outputVersion != "single")
    {
      setHists=2;
      getConstants(my_DCASpectrumPos,my_driftDistancesPos,setHists);
      setHists=3;
      getConstants(my_DCASpectrumNeg,my_driftDistancesNeg,setHists);
      report(DEBUG,kFacilityString) << "got constants neg " << endl;
    }
}
void Spectrum::getConstants(UInt32 DCASpectrum[kNoOfTimeBins][kNoOfDCABins],float *driftDistances, UInt32 setHists)
{
  // calculate truncated mean
  UInt32 dcaSpectrum[kNoOfDCABins];
  UInt32 dcaBinsNo;
  UInt32 counter;
  int newBinNo;
  UInt32 oldBinNo=0;
  UInt32 noOfEntriesPerTimeBin;
  UInt32 binloop;
  my_rms = 0;
  int binno=0;
  while(binno < kNoOfTimeBins)
    {
      noOfEntriesPerTimeBin = 0;
      for(counter = 0; counter < kNoOfDCABins; ++counter)
	{
	  dcaSpectrum[counter] = DCASpectrum[binno][counter];
	  noOfEntriesPerTimeBin += dcaSpectrum[counter];
	  if(setHists == 1)
	    {
	      histDCADistTime[binno]->fill((float(counter)+0.5),DCASpectrum[binno][counter]);
	    }
	}
      newBinNo = binno;
      while((noOfEntriesPerTimeBin < kMinimumEntriesPerTimeBin) && (newBinNo < kNoOfTimeBins-1 ))
	{
	  ++newBinNo;
	  for(int counter2 = 0; counter2 < kNoOfDCABins; ++counter2)
	    {
	      dcaSpectrum[counter2] += DCASpectrum[newBinNo][counter2];
	      noOfEntriesPerTimeBin += dcaSpectrum[counter2];
	      //	      if(setHists == 1)
	      //		{
	      //		  histDCADistTime[newBinNo]->
	      //		    fill((dcaBinsNo+0.5),DCASpectrum[newBinNo][counter2]);
	      //		}
	    }
	}
      if(setHists == 1)
	{
	  histNoOfEntriesPerTimeBin->fill(float(binno)+0.5,noOfEntriesPerTimeBin);
	}
      if((noOfEntriesPerTimeBin < kMinimumEntriesPerTimeBin) && (binno > 0))
        {
	  report(DEBUG,kFacilityString) << " last bin with enough data: " << oldBinNo << " setHists: " << setHists << endl;
	  for(binloop=binno; binloop<= newBinNo; ++binloop)
	    {
	      driftDistances[binloop] = driftDistances[binno-1];
	      if(setHists == 1)
		{
		  histResidualRMSvsDriftTime->fill((float(binloop)+0.5)*float(kNoOfnsPerBin),my_rms);
		  //
		  // make histogram to show mean and truncation
		  //
		  histMeanVar[binloop]->fill(driftDistances[binloop]*1000.*float(kNoOfDCABins)/float(kTotalDCARange),10000.);
		  histMeanVar[binloop]->fill((driftDistances[binloop]*float(kNoOfDCABins)*1000./float(kTotalDCARange))
					   +(my_rms*3.*float(kNoOfDCABins)*1000./float(kTotalDCARange)),8000.);
		  histMeanVar[binloop]->fill((driftDistances[binloop]*float(kNoOfDCABins)*1000./float(kTotalDCARange))
					   -(my_rms*3.*float(kNoOfDCABins)*1000./float(kTotalDCARange)),8000.);
		}
	    }	  
	}
      else
	{
	  int ok;
	  //
	  // get truncation for combined driftfunction
	  //
	  
	  ok = rmsTruncated(dcaSpectrum, int(kNoOfDCABins/2),int(kNoOfDCABins/2));
	  if(ok)
	    {
	      ok = rmsTruncated(dcaSpectrum,
				my_meanDistance * float(kNoOfDCABins) * 1000. / float(kTotalDCARange),
				my_rms * 5. * float(kNoOfDCABins) * 1000. / float(kTotalDCARange));
	      if(ok)
		{
		  ok = rmsTruncated(dcaSpectrum,
				    my_meanDistance * float(kNoOfDCABins) * 1000. / float(kTotalDCARange),
				    my_rms * 3. * float(kNoOfDCABins) * 1000. / float(kTotalDCARange));
		  if(ok)
		    {
		      ok = rmsTruncated(dcaSpectrum,
					my_meanDistance * float(kNoOfDCABins) * 1000. / float(kTotalDCARange),
					my_rms * 2.5 * float(kNoOfDCABins)*1000. / float(kTotalDCARange));
		      if(ok)
			{
			  ok = rmsTruncated(dcaSpectrum,
					    my_meanDistance * float(kNoOfDCABins) * 1000. / float(kTotalDCARange),
					    my_rms *2.4 * float(kNoOfDCABins) * 1000. / float(kTotalDCARange));
			  if(ok)
			    {
			      for(binloop=binno; binloop<= newBinNo; ++binloop)
				{
				  driftDistances[binloop] = my_meanDistance;
				  if(setHists == 1)
				    {
				      histResidualRMSvsDriftTime->fill((float(binloop)+0.5)*float(kNoOfnsPerBin),my_rms);
				      //
				      // make histogram to show mean and truncation
				      //
				      histMeanVar[binloop]->fill(my_meanDistance*1000.*float(kNoOfDCABins)/float(kTotalDCARange),10000.);
				      histMeanVar[binloop]->fill((my_meanDistance*float(kNoOfDCABins)*1000./float(kTotalDCARange))
							       +(my_rms*2.4*float(kNoOfDCABins)*1000./float(kTotalDCARange)),8000.);
				      histMeanVar[binloop]->fill((my_meanDistance*float(kNoOfDCABins)*1000./float(kTotalDCARange))
							       -(my_rms*2.4*float(kNoOfDCABins)*1000./float(kTotalDCARange)),8000.);
				    }
				}
			    }
			}
		    }
		}
	    }
	}
      oldBinNo=binno+1;
      binno = newBinNo+1;
    }

  //
  //calculate scale factor of integration method to truncated mean at the transition point.
  //
  
  float scaleFactor=0.;
  int noOfTransitionBinsUsed=0.;
  for(UInt32 transitionLoop=0;transitionLoop < kNoOfTimeBins;++transitionLoop)
    {
      int transitionPointBin = float(transitionLoop)*float(kNoOfnsPerBin);
      float scale=0.;
      if(transitionPointBin>=kDriftTimeWindow)
	{
	  report(ERROR,kFacilityString) << "transitionPointBin > than kDriftTimeWindow limit: " << transitionPointBin << endl;
	  break;
	}
      if(my_integratedDriftTimes[transitionPointBin]>0)
	{
	  if(driftDistances[transitionLoop]!=0)
	    {
	      scale = 2* driftDistances[transitionLoop] /(float(my_integratedDriftTimes[transitionPointBin]) + 
							  float(my_integratedDriftTimes[transitionPointBin+1]));
	    }
	  else
	    {
	      report(ERROR,kFacilityString) << " my_driftDistances[" << transitionLoop << "] = 0!!!" << endl;
	    }
	}
	
      if((transitionLoop>=kTransitionPoint)&&(transitionLoop<kTransitionPoint+kNoTransitionBins))
	{
	  if(scale>0.)
	    {
	      scaleFactor += scale;
	      ++noOfTransitionBinsUsed;
	    }
	  else
	    {
	      report(ERROR,kFacilityString) << " scale factor for transition point: " << transitionLoop 
					    << " is 0 for layer no.: " << my_spectrumId << endl;
	    }
	}
      if(setHists == 1)
	{
	  histScaleDistribution->fill(float(transitionLoop)+0.5,scale);
	}
    }
  report(DEBUG,kFacilityString)<< "scaleFactor: " << scaleFactor  << " scaleFactor/noTransitionBins" 
			       << scaleFactor/float(kNoTransitionBins) << endl;

  scaleFactor = scaleFactor/float(noOfTransitionBinsUsed);
  
  // copy drift distances calculated by integration into the final drift distance container my_driftDistances.

  //    for(binno = 0; binno < kNoOfTimeBins; binno++) 
  for(binno = 0; binno < kTransitionPoint; binno++) 
    {
      driftDistances[binno] = float(my_integratedDriftTimes[binno*kNoOfnsPerBin] + my_integratedDriftTimes[binno*kNoOfnsPerBin+1])/2.*scaleFactor;
    }
}

int Spectrum::rmsTruncated(UInt32 *dcaSpectrum, float truncationMean, float truncationWidth)
{

  int beginCount = ((truncationMean-truncationWidth) > 0) ? int(truncationMean-truncationWidth) : 0;
  int endCount = ((truncationMean+truncationWidth) < kNoOfDCABins) ? int(truncationMean+truncationWidth) : kNoOfDCABins-1;
  UInt32 counter;
  float mean;
  float rmsValue;
  int ok;

  //
  // find rms for drift function
  //
  mean = 0;
  rmsValue = 0;
  ok = rms(dcaSpectrum,beginCount,endCount,mean,rmsValue);
  if(ok>0)
    {
      my_meanDistance = mean * (float(kTotalDCARange)/float(kNoOfDCABins)/1000.);
      my_rms = rmsValue * (float(kTotalDCARange)/float(kNoOfDCABins)/1000.);
    }
  else
    {
      my_meanDistance = truncationMean * (float(kTotalDCARange)/float(kNoOfDCABins)/1000.);
      my_rms = truncationWidth * (float(kTotalDCARange)/float(kNoOfDCABins)/1000.);
    }
  
  report(DEBUG,kFacilityString) << "spectrum id: " << my_spectrumId 
				<< " mean: " << my_meanDistance	<< " rms:"  << my_rms << endl;
  return 1;
}


int Spectrum::rms(UInt32 *dcaSpectrum, UInt32 beginCount, UInt32 endCount, float &mean, float &rmsValue)
{
  if((beginCount<0) || (endCount>=kNoOfDCABins))
    {
      report(ERROR,kFacilityString) << " Values of beingCount,endCount given to rms are illegal: beginCount: " 
				    << beginCount << " endCount: " << endCount << endl;
      return -1;
    }
  int counter;
  float NormProb = 0.;
  float var = 0.;
  
  for(counter = beginCount; counter <= endCount; ++counter)
    {
      NormProb += float(dcaSpectrum[counter]);
      var += float(dcaSpectrum[counter])*float(counter+0.5);
    }

  if(NormProb>0.)
    {
      mean = (var/NormProb);
    }
  else
    {
      return -1;
    }
  var = 0;
  for(counter=beginCount; counter <=endCount; ++counter)
    {
      var +=pow((float(counter+0.5)-mean),2)*float(dcaSpectrum[counter]);
    }
  rmsValue = sqrt(fabs(var/NormProb));
  return 1;
}

void Spectrum::writeDCASpectrum(FILE *out)
{
  UInt32 nextBin;
  for(UInt32 loop1=0;loop1<kDriftTimeWindow;++loop1)
    {
#if(AC_BIGENDIAN==0)	  
      nextBin = swapBytesInUInt32(my_integratedDriftTimes[loop1]);
      fwrite(&nextBin,sizeof(UInt32),1,out);
#else
      fwrite(&my_integratedDriftTimes[loop1],sizeof(UInt32),1,out);
#endif
    }
  for(UInt32 loop2=0;loop2<kNoOfDCABins;++loop2)
    {
      if(my_outputVersion == "single")
	{
	  for(UInt32 loop3=0;loop3<kNoOfTimeBins;++loop3)
	    {
#if(AC_BIGENDIAN==0)	  
	      nextBin = swapBytesInUInt32(my_DCASpectrumPos[loop3][loop2]+my_DCASpectrumNeg[loop3][loop2]);

#else
	      nextBin = my_DCASpectrumPos[loop3][loop2]+my_DCASpectrumNeg[loop3][loop2];
#endif
	      fwrite(&nextBin,sizeof(UInt32),1,out);
	    }

	  for(UInt32 loop4=0;loop4<kNoOfDriftDistanceBins*2+1;++loop4)
	    {
#if(AC_BIGENDIAN==0)	  
	      nextBin = swapBytesInUInt32(256);
#else
	      nextBin = 256;
#endif
	      fwrite(&nextBin,sizeof(UInt32),1,out);
      
	    }
	}
      else
	{
	  if(my_outputVersion == "double")
	    {
	      for(UInt32 loop3=0;loop3<kNoOfTimeBins;++loop3)
		{
#if(AC_BIGENDIAN==0)	  
		  nextBin = swapBytesInUInt32(my_DCASpectrumPos[loop3][loop2]);
		  
#else
		  nextBin = my_DCASpectrumPos[loop3][loop2];
#endif
		  fwrite(&nextBin,sizeof(UInt32),1,out);
		}
	      
	      for(UInt32 loop4=0;loop4<kNoOfTimeBins;++loop4)
		{
#if(AC_BIGENDIAN==0)	  
		  nextBin = swapBytesInUInt32(my_DCASpectrumNeg[loop4][loop2]);
		  fwrite(&nextBin,sizeof(UInt32),1,out);
#else
		  fwrite(&my_DCASpectrumNeg[loop4][loop2],sizeof(UInt32),1,out);
#endif
		}	  
	    }
	}
    }  
}


void Spectrum::readDCASpectrum(FILE *in)
{
  UInt32 nextBin;
  for(UInt32 loop1=0;loop1<kDriftTimeWindow;++loop1)
    {
      fread(&nextBin,sizeof(UInt32),1,in);
      float integratedDriftTime;
#if(AC_BIGENDIAN==0)	  
      my_integratedDriftTimes[loop1]+=swapBytesInUInt32(nextBin);
      integratedDriftTime = swapBytesInUInt32(nextBin);

#else
      my_integratedDriftTimes[loop1]+=nextBin;
      integratedDriftTime = nextBin;
#endif
      histIntegratedTimes->fill(float(loop1)+0.5,integratedDriftTime);
    }
  for(UInt32 loop2=0;loop2<kNoOfDCABins;++loop2)
    {
      for(UInt32 loop3=0;loop3<kNoOfTimeBins;++loop3)
	{
	  fread(&nextBin,sizeof(UInt32),1,in);
#if(AC_BIGENDIAN==0)	  
	  my_DCASpectrumPos[loop3][loop2]+=swapBytesInUInt32(nextBin);
	  my_DCASpectrum[loop3][loop2]+=swapBytesInUInt32(nextBin);
#else
	  my_DCASpectrumPos[loop3][loop2]+=nextBin;
	  my_DCASpectrum[loop3][loop2]+=nextBin;
#endif

	}
      
      if(my_outputVersion == "single")
	{
	  for(UInt32 loop4=0;loop4<kNoOfDriftDistanceBins*2+1;++loop4)
	    {
	      fread(&nextBin,sizeof(UInt32),1,in);
	      // do nothing since my_DCASpectrumDistances is not used anymore
	    }
	}
      else
	{
	  if(my_outputVersion == "double")
	    {
	      for(UInt32 loop4=0;loop4<kNoOfTimeBins;++loop4)
		{
		  fread(&nextBin,sizeof(UInt32),1,in);
#if(AC_BIGENDIAN==0)	  
		  my_DCASpectrumNeg[loop4][loop2]+=swapBytesInUInt32(nextBin);
		  my_DCASpectrum[loop4][loop2]+=swapBytesInUInt32(nextBin);
#else
		  my_DCASpectrumNeg[loop4][loop2]+=nextBin;
		  my_DCASpectrum[loop4][loop2]+=nextBin;
#endif
		}
	    }	  
	}
    }  
}

void Spectrum::SetTimeToDriftFunctionValues(UInt32 driftSignIndex, UInt32 driftTimeBin, float driftDistance)
{
  my_TimeToDriftFunction[driftSignIndex-2][driftTimeBin] = driftDistance;
  if(driftSignIndex == 2)
    {
      histTimeToDriftFunction->fill(float(driftTimeBin)+0.5,driftDistance,1.);
    }
  else
    {
      histTimeToDriftFunction->fill(float(driftTimeBin)+0.5,-driftDistance,1.);
    }
}
