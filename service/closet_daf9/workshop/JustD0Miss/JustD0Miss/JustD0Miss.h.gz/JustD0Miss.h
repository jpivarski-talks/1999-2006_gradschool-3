// -*- C++ -*-
#if !defined(JUSTD0MISS_JUSTD0MISS_H)
#define JUSTD0MISS_JUSTD0MISS_H
//
// Package:     <JustD0Miss>
// Module:      JustD0Miss
//
/**\class JustD0Miss JustD0Miss.h JustD0Miss/JustD0Miss.h
 
 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Wed Sep 12 16:04:45 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "Processor/Processor.h"
#include "HistogramInterface/HistogramPackage.h"

// forward declarations

class JustD0Miss : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------

      // ------------ Constructors and destructor ----------------
      JustD0Miss( void );                      // anal1 
      virtual ~JustD0Miss();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( HIHistoManager& );                  

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      //virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      //virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      JustD0Miss( const JustD0Miss& );

      // ------------ assignment operator(s) ---------------------
      const JustD0Miss& operator=( const JustD0Miss& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (JustD0Miss::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      // ------------ private const member functions -------------

      // ------------ data members -------------------------------

      HIHist1D* h_d0miss;

      // ------------ static data members ------------------------

};

// inline function definitions

#endif /* JUSTD0MISS_JUSTD0MISS_H */
