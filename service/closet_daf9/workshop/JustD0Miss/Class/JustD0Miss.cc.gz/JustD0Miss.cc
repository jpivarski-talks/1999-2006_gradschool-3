// -*- C++ -*-
//
// Package:     JustD0Miss
// Module:      JustD0Miss
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Wed Sep 12 16:04:45 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "JustD0Miss/JustD0Miss.h"
#include "Experiment/report.h"
#include "Experiment/units.h"  // for converting to/from standard CLEO units

#include "DataHandler/Record.h"
#include "DataHandler/Frame.h"
#include "FrameAccess/extract.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"

#include "Navigation/NavTrack.h"

//RICH example 
//Dedx example
//Event Shape example


// STL classes
// You may have to uncomment some of these or other stl headers 
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "Processor.JustD0Miss" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: processor.cc,v 1.21 2001/09/01 22:44:37 llh14 Exp $";
static const char* const kTagString = "$Name: v06_00_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
JustD0Miss::JustD0Miss( void )               // anal1
   : Processor( "JustD0Miss" )
{
   report( DEBUG, kFacilityString ) << "here in ctor()" << endl;

   // ---- bind a method to a stream -----
   // These lines ARE VERY IMPORTANT! If you don't bind the 
   // code you've just written (the "action") to a stream, 
   // your code won't get executed!

   bind( &JustD0Miss::event,    Stream::kEvent );
   //bind( &JustD0Miss::beginRun, Stream::kBeginRun );
   //bind( &JustD0Miss::endRun,   Stream::kEndRun );

   // do anything here that needs to be done at creation time
   // (e.g. allocate resources etc.)

}

JustD0Miss::~JustD0Miss()                    // anal5
{
   report( DEBUG, kFacilityString ) << "here in dtor()" << endl;
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}

//
// member functions
//

// ------------ methods for beginning/end "Interactive" ------------
// --------------------------- init method -------------------------
void
JustD0Miss::init( void )          // anal1 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in init()" << endl;

   // do any initialization here based on Parameter Input by User
   // (e.g. run expensive algorithms that are based on parameters
   //  specified by user at run-time)

}

// -------------------- terminate method ----------------------------
void
JustD0Miss::terminate( void )     // anal5 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in terminate()" << endl;

   // do anything here BEFORE New Parameter Change
   // (e.g. write out result based on parameters from user-input)
 
}

// ---------------- standard place to book histograms ---------------
void
JustD0Miss::hist_book( HIHistoManager& iHistoManager )
{
   report( DEBUG, kFacilityString ) << "here in hist_book()" << endl;

   // book your histograms here
   h_d0miss = iHistoManager.histogram( 100, "d0 miss", 200, -10E-3, 10E-3 );

}

// --------------------- methods bound to streams -------------------
ActionBase::ActionResult
JustD0Miss::event( Frame& iFrame )          // anal3 equiv.
{
   report( DEBUG, kFacilityString ) << "here in event()" << endl;

   Meters d0miss = 0.;
   Meters z0miss = 0.;
   double total_charge_product = 1.;

   FATable< NavTrack > navtracks;
   extract( iFrame.record( Stream::kEvent ), navtracks );
   if ( navtracks.size() != 2 ) return ActionBase::kFailed;

   FATable< NavTrack >::const_iterator navtracks_iterator;
   FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
   FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
   for( navtracks_iterator = navtracks_begin;
        navtracks_iterator != navtracks_end;
        navtracks_iterator++ )
   {
      if ( navtracks_iterator->muonQuality()->fitAbort() )
         return ActionBase::kFailed;

      GeV momentum_magnitude = navtracks_iterator->muonFit()->momentum().mag();

      double curvature = navtracks_iterator->muonHelix()->curvature();
      double charge_sign = ( curvature > 0. ? 1. : -1. );
      total_charge_product *= charge_sign;

      double phi0 = navtracks_iterator->muonHelix()->phi0();
      Meters d0 = navtracks_iterator->muonHelix()->d0();
      Meters cotTheta = navtracks_iterator->muonHelix()->cotTheta();
      Meters z0 = navtracks_iterator->muonHelix()->z0();

      d0miss += d0;                  // d0miss is the sum
      z0miss += z0 * charge_sign;    // z0miss is the difference

   } // end track

   // you want to be careful of -1. != -1.0000000000000001
   if ( total_charge_product < 0. )
   {
      h_d0miss->fill( d0miss );
   }

   return ActionBase::kPassed;
}

/*
ActionBase::ActionResult
JustD0Miss::beginRun( Frame& iFrame )       // anal2 equiv.
{
   report( DEBUG, kFacilityString ) << "here in beginRun()" << endl;

   return ActionBase::kPassed;
}
*/

/*
ActionBase::ActionResult
JustD0Miss::endRun( Frame& iFrame )         // anal4 equiv.
{
   report( DEBUG, kFacilityString ) << "here in endRun()" << endl;

   return ActionBase::kPassed;
}
*/

//
// const member functions
//

//
// static member functions
//
