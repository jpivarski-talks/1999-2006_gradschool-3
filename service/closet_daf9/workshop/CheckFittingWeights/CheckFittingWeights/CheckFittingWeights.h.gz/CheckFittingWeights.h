// -*- C++ -*-
#if !defined(CHECKFITTINGWEIGHTS_CHECKFITTINGWEIGHTS_H)
#define CHECKFITTINGWEIGHTS_CHECKFITTINGWEIGHTS_H
//
// Package:     <CheckFittingWeights>
// Module:      CheckFittingWeights
//
/**\class CheckFittingWeights CheckFittingWeights.h CheckFittingWeights/CheckFittingWeights.h
 
 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Wed Jan 31 18:14:07 EST 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "Processor/Processor.h"
#include "HistogramInterface/HistogramPackage.h"
#include "HbookHistogram/HbookNtuple.h"
#include "Navigation/NavTrack.h"
#include "ADRGeom/ADRSenseWireStore.h"
#include "TrackFitter/TrackFitDRHitLink.h"
#include "CLHEP/Vector/ThreeVector.h"
#include "VXFit/VXFitVeeKShort.h"
#include "RandomModule/RandomGenerator.h"
#include "C3cc/CcEventSummary.h"

#define MFW_PI 3.14159265
#define MFW_INT( A, B ) (B - A + 1), (float(A) - 0.5), (float(B) + 0.5)

// forward declarations

class CheckFittingWeights : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------

      // ------------ Constructors and destructor ----------------
      CheckFittingWeights( void );                      // anal1 
      virtual ~CheckFittingWeights();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( HIHistoManager& );                  

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      //virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      //virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      CheckFittingWeights( const CheckFittingWeights& );

      // ------------ assignment operator(s) ---------------------
      const CheckFittingWeights& operator=( const CheckFittingWeights& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (CheckFittingWeights::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      // ------------ private const member functions -------------

      ActionBase::ActionResult do_bhabha( Frame& iFrame );
      ActionBase::ActionResult do_ksEvent( Frame& iFrame,
					   FATable< VXFitVeeKShort > kshorts );

      const TrackFitDRHitLink& getHitLink(
	 FATable< NavTrack >::const_iterator navtracks_iterator,
	 vector< const CalibratedDRHit* >::const_iterator trackDRHits_iterator,
	 FAItem< ElectronFitDRHitLattice > drhitLattice );

      // ------------ data members -------------------------------
      TrackFitDRHitLink m_nullHitLink;

      HIHist1D* h_raw_sum_cot_theta;        // +/- 0.3
      HIHist1D* h_raw_diff_phi_from_pi;     // +/- 0.06
      HIHist1D* h_raw_curvature_product;    // +/- 0.36
      HIHist1D* h_cut_sum_cot_theta;
      HIHist1D* h_cut_diff_phi_from_pi;
      HIHist1D* h_cut_curvature_product;

      HIHist1D* h_raw_number_DR_hits;       // integer 0..50
      HIHist1D* h_raw_momentum;             // 0..8
      HIHist1D* h_raw_efficiency_ratio;     // -0.1..1.1
      HIHist1D* h_raw_chi2_per_dof;         // -1..100
      HIHist1D* h_raw_cotTheta_err;         // 0..1
      HIHist1D* h_raw_z0_err;               // 0..0.5
      HIHist1D* h_raw_cotTheta;             // -1.5..1.5
      HIHist1D* h_raw_d0;                   // 0..0.006
      HIHist1D* h_raw_z0;                   // 0..0.300
      HIHist1D* h_cut_number_DR_hits;  
      HIHist1D* h_cut_momentum;        
      HIHist1D* h_cut_efficiency_ratio;
      HIHist1D* h_cut_chi2_per_dof;    
      HIHist1D* h_cut_cotTheta_err;
      HIHist1D* h_cut_z0_err;
      HIHist1D* h_cut_cotTheta;
      HIHist1D* h_cut_d0;
      HIHist1D* h_cut_z0;

      HIHist1D* h_numtracks;

      HIHist1D* h_simpleChi;
      HIHist1D* h_missD0;
      HIHist1D* h_missZ0;
      HIHist1D* h_curvature;
      HIHist1D* h_curvature_close;
      HIHist1D* h_e_drift;

      int m_event_num;
      DABoolean m_event_finished;
      HINtuple* nt_event_vars; // { "d0tr1", "d0tr2", "errd0tr1", "errd0tr2",
                               //   "z0tr1", "z0tr2", "errz0tr1", "errz0tr2",
                               //   "phi0tr1", "phi0tr2", "cotthtr1",
                               //   "cotthtr2", "momtr1", "momtr2" };
      int m_track_num;
      DABoolean m_track_finished;
      HINtuple* nt_track_vars; // { "cutlevel", "chi2", "dof", "conflevel",
                               //   "momentum", "phi0", "cottheta", "d0", "z0" };
      int m_hit_num;
      DABoolean m_hit_finished;
      HINtuple* nt_hit_vars;   // { "dca", "errdca", "drift", "errdrfw",
                               //   "layer", "costheta", "absDrift", "phi",
                               //   "layerRad", "layerCells" };

      HIHist1D* h_res_chi2;
      HIHist1D* h_res_dof;
      HIHist1D* h_res_chi2dof;
      HIHist1D* h_res_chi2dofExpected;
      HIHist1D* h_res_confLevel;
      HIHist1D* h_res_chi2dof_tq;
      HIHist1D* h_res_chi2dofExpected_tq;
      HIHist1D* h_res_confLevel_tq;
      HIHist1D* h_res_momentum;
      HIHist1D* h_res_momentum_tq;

      int m_ks_num;
      DABoolean m_ks_finished;
      HINtuple* nt_ks_vars; // { "cutlevel", "chi2", "conflevel", "mass",
                            //   "xvertex", "yvertex", "zvertex",
                            //   "xmomentum", "ymomentum", "zmomentum",
                            //   "phi0tr1", "phi0tr2", "cotthtr1",
                            //   "cotthtr2", "momtr1", "momtr2" };

      HIHist1D* h_ks_chi2dof;
      HIHist1D* h_ks_chi2dofExpected;
      HIHist1D* h_ks_confLevel;
      HIHist1D* h_ks_chi2dof_tq;
      HIHist1D* h_ks_chi2dofExpected_tq;
      HIHist1D* h_ks_confLevel_tq;
      HIHist1D* h_ks_chi2dof_all;
      HIHist1D* h_ks_chi2dofExpected_all;
      HIHist1D* h_ks_confLevel_all;
      HIHist1D* h_ks_mass;
      HIHist1D* h_ks_mass_tq;
      HIHist1D* h_ks_mass_all;
      HIHist1D* h_ks_vertexrad;
      HIHist1D* h_ks_vertexrad_tq;
      HIHist1D* h_ks_vertexrad_all;

      HIHist1D* h_ks_confLevel_non_ks;
      HIHist1D* h_ks_confLevel_ks;

      // ------------ static data members ------------------------

};

// inline function definitions

#endif /* CHECKFITTINGWEIGHTS_CHECKFITTINGWEIGHTS_H */
