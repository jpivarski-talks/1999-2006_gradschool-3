// -*- C++ -*-
//
// Package:     CheckFittingWeights
// Module:      CheckFittingWeights
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Wed Jan 31 18:14:07 EST 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "CheckFittingWeights/CheckFittingWeights.h"
#include "Experiment/report.h"
#include "Experiment/units.h"  // for converting to/from standard CLEO units

#include "DataHandler/Record.h"
#include "DataHandler/Frame.h"
#include "FrameAccess/extract.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"


// STL classes
// You may have to uncomment some of these or other stl headers 
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

// external functions
extern "C" float prob_(const float&, const int&);
extern "C" float chisin_(const float&, const int&);

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "Processor.CheckFittingWeights" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: processor.cc,v 1.17 2000/12/04 19:11:11 cdj Exp $";
static const char* const kTagString = "$Name: v03_06_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
CheckFittingWeights::CheckFittingWeights( void )               // anal1
   : Processor( "CheckFittingWeights" )
{
   report( DEBUG, kFacilityString ) << "here in ctor()" << endl;

   // ---- bind a method to a stream -----
   // These lines ARE VERY IMPORTANT! If you don't bind the 
   // code you've just written (the "action") to a stream, 
   // your code won't get executed!

   bind( &CheckFittingWeights::event,    Stream::kEvent );
   //bind( &CheckFittingWeights::beginRun, Stream::kBeginRun );
   //bind( &CheckFittingWeights::endRun,   Stream::kEndRun );

   // do anything here that needs to be done at creation time
   // (e.g. allocate resources etc.)

}

CheckFittingWeights::~CheckFittingWeights()                    // anal5
{
   report( DEBUG, kFacilityString ) << "here in dtor()" << endl;
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}

//
// member functions
//

// ------------ methods for beginning/end "Interactive" ------------
// --------------------------- init method -------------------------
void
CheckFittingWeights::init( void )          // anal1 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in init()" << endl;

   // do any initialization here based on Parameter Input by User
   // (e.g. run expensive algorithms that are based on parameters
   //  specified by user at run-time)

}

// -------------------- terminate method ----------------------------
void
CheckFittingWeights::terminate( void )     // anal5 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in terminate()" << endl;

   // do anything here BEFORE New Parameter Change
   // (e.g. write out result based on parameters from user-input)
 
}

// ---------------- standard place to book histograms ---------------
void
CheckFittingWeights::hist_book( HIHistoManager& iHistoManager )
{
   report( DEBUG, kFacilityString ) << "here in hist_book()" << endl;

   // book your histograms here
   const int bins = 60;

   h_numtracks = iHistoManager.histogram( 100, "Raw Tracks per Event",
					  MFW_INT( 0, 10 ) );

   h_raw_number_DR_hits =
      iHistoManager.histogram( 401, "Number of DR Hits",
                               MFW_INT( 0, 50 ) );
   h_cut_number_DR_hits =
      iHistoManager.histogram( 501, "Cut Number of DR Hits",
                               MFW_INT( 0, 50 ) );
   
   h_raw_momentum =
      iHistoManager.histogram( 402, "Track Momentum",
                               bins, 0., 8. );
   h_cut_momentum =
      iHistoManager.histogram( 502, "Cut Track Momentum",
                               bins, 0., 8. );
   
   h_raw_efficiency_ratio =
      iHistoManager.histogram( 403, "Hits Divided by Expected Hits",
                               bins, -0.1, 1.3 );
   h_cut_efficiency_ratio =
      iHistoManager.histogram( 503, "Cut Hits Divided by Expected Hits",
                               bins, -0.1, 1.3 );

   h_raw_chi2_per_dof =
      iHistoManager.histogram( 404, "Track Chi^2! Divided by Number of DOF",
                               ( 4 * bins ), -1., 100. );
   h_cut_chi2_per_dof =
      iHistoManager.histogram( 504, "Cut Track Chi^2! Divided by Number of DOF",
                               ( 4 * bins ), -1., 100. );

   h_raw_cotTheta_err =
      iHistoManager.histogram( 405, "Uncertainty in track cotTheta",
                               bins, 0., 1. );
   h_cut_cotTheta_err =
      iHistoManager.histogram( 505, "Cut Uncertainty in track cotTheta",
                               bins, 0., 1. );

   h_raw_z0_err =
      iHistoManager.histogram( 406, "Uncertainty in track z0",
                               bins, 0., 0.5 );
   h_cut_z0_err =
      iHistoManager.histogram( 506, "Cut Uncertainty in track z0",
                               bins, 0., 0.5 );

   h_raw_cotTheta =
      iHistoManager.histogram( 407, "CotTheta", bins, -1.5, 1.5 );
   h_cut_cotTheta =
      iHistoManager.histogram( 507, "Cut CotTheta", bins, -1.5, 1.5 );

   h_raw_d0 =
      iHistoManager.histogram( 408, "D0 (DBCD)", bins, 0., 0.006 );
   h_cut_d0 =
      iHistoManager.histogram( 508, "Cut D0 (DBCD)", bins, 0., 0.006 );

   h_raw_z0 =
      iHistoManager.histogram( 409, "Z0", bins, 0., 0.300 );
   h_cut_z0 =
      iHistoManager.histogram( 509, "Cut Z0", bins, 0., 0.300 );

   h_simpleChi = iHistoManager.histogram( 900, "Residual over FittingWeight",
					  bins, -3.5, 3.5 );
   h_missD0 = iHistoManager.histogram(
      910, "D0 miss distance over uncertainty", (2*bins), -5., 5. );
   h_missZ0 = iHistoManager.histogram(
      920, "Z0 miss distance over uncertainty", (4*bins), -5., 5. );
   h_curvature = iHistoManager.histogram( 930, "Curvature in 1/m",
					  bins, -2.5, 2.5 );
   h_curvature_close = iHistoManager.histogram( 935, "Curvature in 1/m",
						bins, -0.6, 0.6 );

   h_e_drift = iHistoManager.histogram( 940, "Error in Drift",
					(2*bins), 0., 0.0005 );

   // resolution-checking histograms

   m_event_num = 0;
   m_event_finished = false;
   const char* nt_event_labels[ 14 ] =
   { "d0tr1", "d0tr2", "errd0tr1", "errd0tr2",
     "z0tr1", "z0tr2", "errz0tr1", "errz0tr2",
     "phi0tr1", "phi0tr2", "cotthtr1", "cotthtr2",
     "momtr1", "momtr2" };
   nt_event_vars = iHistoManager.ntuple( 800, "Event Variables", 14, 262144,
					 nt_event_labels );

   m_track_num = 0;
   m_track_finished = false;
   const char* nt_track_labels[ 9 ] =
   { "cutlevel", "chi2", "dof", "conflevel", "momentum",
     "phi0", "cottheta", "d0", "z0" };
   nt_track_vars = iHistoManager.ntuple( 810, "Track Variables", 9, 262144,
					 nt_track_labels );

   m_hit_num = 0;
   m_hit_finished = false;
   const char* nt_hit_labels[ 10 ] =
   { "dca", "errdca", "drift", "errdrfw",
     "layer", "costheta", "absDrift", "phi",
     "layerRad", "layerCells" };
   nt_hit_vars = iHistoManager.ntuple( 820, "Hit Variables", 10,  262144,
				       nt_hit_labels );

   h_res_chi2 = iHistoManager.histogram(
      1000, "Track Chi^2! with no cuts", bins, 0., 360. );
   h_res_dof = iHistoManager.histogram(
      1010, "Track Degrees of Freedom with no cuts", MFW_INT( 0, 50 ) );

   h_res_chi2dof = iHistoManager.histogram(
      1020, "Track Chi^2! per d.o.f with no cuts", bins, 0., 6. );
   h_res_chi2dofExpected = iHistoManager.histogram( 
      1030, "Track Expected Chi^2! per d.o.f with no cuts", bins, 0., 6. );
   h_res_confLevel = iHistoManager.histogram(
      1040, "Track Confidence Level with no cuts", bins, 0., 1. );
   
   h_res_chi2dof_tq = iHistoManager.histogram(
      1120, "Track Chi^2! per d.o.f with track quality cuts", bins, 0., 6. );
   h_res_chi2dofExpected_tq = iHistoManager.histogram(
      1130, "Track Expected Chi^2! per d.o.f with track quality cuts",
      bins, 0., 6. );
   h_res_confLevel_tq = iHistoManager.histogram(
      1140, "Track Confidence Level with track quality cuts", bins, 0., 1. );

   h_res_momentum = iHistoManager.histogram(
      1050, "Track Momentum with no cuts", bins, 4.5, 6.0 );
   h_res_momentum_tq = iHistoManager.histogram(
      1150, "Track Momentum with track quality cuts", bins, 4.5, 6.0 );

   // K0-short histograms

   m_ks_num = 0;
   m_ks_finished = false;
   const char* nt_ks_labels[ 16 ] =
   { "cutlevel", "chi2", "conflevel", "mass",
     "xvertex", "yvertex", "zvertex", "xmomentum", "ymomentum", "zmomentum",
     "phi0tr1", "phi0tr2", "cotthtr1", "cotthtr2",
     "momtr1", "momtr2" };
   nt_ks_vars = iHistoManager.ntuple( 830, "K0-short Variables", 16, 262144,
				      nt_ks_labels );

   h_ks_chi2dof = iHistoManager.histogram(
      1220, "K0-short Chi^2! per d.o.f with no cuts", bins, 0., 6. );
   h_ks_chi2dofExpected = iHistoManager.histogram(
      1230, "K0-short Expected Chi^2! per d.o.f with no cuts", bins, 0., 6. );
   h_ks_confLevel = iHistoManager.histogram(
      1240, "K0-short Confidence Level with no cuts", bins, 0., 1. );

   h_ks_chi2dof_tq = iHistoManager.histogram(
      1320, "K0-short Chi^2! per d.o.f with track quality cuts", bins, 0., 6. );
   h_ks_chi2dofExpected_tq = iHistoManager.histogram(
      1330, "K0-short Expected Chi^2! per d.o.f with track quality cuts", bins, 0., 6. );
   h_ks_confLevel_tq = iHistoManager.histogram(
      1340, "K0-short Confidence Level with track quality cuts", bins, 0., 1. );

   h_ks_chi2dof_all = iHistoManager.histogram(
      1420, "K0-short Chi^2! per d.o.f with all cuts", bins, 0., 6. );
   h_ks_chi2dofExpected_all = iHistoManager.histogram(
      1430, "K0-short Expected Chi^2! per d.o.f all cuts", bins, 0., 6. );
   h_ks_confLevel_all = iHistoManager.histogram(
      1440, "K0-short Confidence Level with all cuts", bins, 0., 1. );

   h_ks_mass = iHistoManager.histogram(
      1250, "K0-short Mass with no cuts", bins, 0.475, 0.525 );
   h_ks_mass_tq = iHistoManager.histogram(
      1350, "K0-short Mass with track quality cuts", bins, 0.475, 0.525 );
   h_ks_mass_all = iHistoManager.histogram(
      1450, "K0-short Mass with all cuts", bins, 0.475, 0.525 );

   h_ks_vertexrad = iHistoManager.histogram(
      1260, "K0-short distance from origin to vertex", bins, 0., 0.06 );
   h_ks_vertexrad_tq = iHistoManager.histogram(
      1360, "K0-short distance from origin to vertex with track quality cuts",
      bins, 0., 0.06 );
   h_ks_vertexrad_all = iHistoManager.histogram(
      1460, "K0-short distance from origin to vertex with all cuts",
      bins, 0., 0.06 );

   h_ks_confLevel_non_ks = iHistoManager.histogram(
      1500, "K0-short Confidence Level OUTSIDE sharp mass cut", bins, 0., 1. );
   h_ks_confLevel_ks = iHistoManager.histogram(
      1510, "K0-short Confidence Level WITHIN sharp mass cut", bins, 0., 1. );
}

// --------------------- methods bound to streams -------------------
ActionBase::ActionResult
CheckFittingWeights::event( Frame& iFrame )          // anal3 equiv.
{
   report( DEBUG, kFacilityString ) << "here in event()" << endl;

   if ( ( m_event_finished  &&  m_track_finished  &&  m_hit_finished )
	||  m_ks_finished )
   {
      report( INFO, kFacilityString )
	 << "Done with everything. Ignoring event." << endl;
      return ActionBase::kPassed;
   }

   FAItem< CcEventSummary > eventSummary;
   extract( iFrame.record( Stream::kEvent ), eventSummary );
   report( DEBUG, kFacilityString ) << "event: got CcEventSummary" << endl;
   DABoolean isBhabha = eventSummary->qedEvent().bhabhaBarrel();
   DABoolean isKSevent = eventSummary->hadronic();
   if ( isBhabha  &&  isKSevent )
   {
      report( ERROR, kFacilityString )
	 << "The event is both a bhabha and hadronic?!?" << endl;
      return ActionBase::kFailed;
   }

   FATable< VXFitVeeKShort > kshorts;
   if ( isKSevent )
   {
      extract( iFrame.record( Stream::kEvent ), kshorts );
      report( DEBUG, kFacilityString )
	 << "event: got K0-short kinematics" << endl;
      if ( kshorts.size() == 0 )
      {
	 report( DEBUG, kFacilityString ) << "No K0-shorts today." << endl;
	 isKSevent = false;
      }
   }

   if ( isBhabha )
      return do_bhabha( iFrame );
   else if ( isKSevent )
      return do_ksEvent( iFrame, kshorts );
   else
      report( INFO, kFacilityString )
	 << "Not a bhabha or K0-short event. Ignoring." << endl;

   return ActionBase::kPassed;
}

////////////////////////////////////////////////////////////////// do_bhabha()

ActionBase::ActionResult
CheckFittingWeights::do_bhabha( Frame& iFrame )
{
   DBCandidate::Hypo particle = DBCandidate::kElectron;

//   RandomGenerator& ran( RandomGenerator::instance() );

   FATable< NavTrack > navtracks;
   extract( iFrame.record( Stream::kEvent ), navtracks );
   FATable< NavTrack >::const_iterator navtracks_iterator;
   FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
   FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
   report( DEBUG, kFacilityString ) << "event: got NavTracks" << endl;

   FAItem< ElectronFitDRHitLattice > drhitLattice;
   if ( ! m_hit_finished )
   {
      extract( iFrame.record( Stream::kEvent ), drhitLattice );
      report( DEBUG, kFacilityString ) << "gatherData: got DRHitLattice" << endl;
   }

   FAItem< ADRSenseWireStore > adrWireStore;
   extract( iFrame.record( Stream::kBaseGeometry ), adrWireStore );
   if ( ! adrWireStore.valid() )
   {
      report( EMERGENCY, kFacilityString )
	 << "ADRSenseWireStore is not valid!" << endl;
      return ActionBase::kFailed;
   }
   // determine some event-level things
   int numtracks = navtracks.size();
   h_numtracks->fill( numtracks );
   
   double event_d0[2];
   double event_d0_err[2];
   double event_z0[2];
   double event_z0_err[2];
   double event_phi0[2];
   double event_cotTheta[2];
   double event_momentum[2];
   int whichTrack = 0;
   int passedTrackQualityCuts = 0;

   // loop over bhabhas
   for( navtracks_iterator = navtracks_begin;
	navtracks_iterator != navtracks_end;
	navtracks_iterator++ )
   {
      // Get the Kalman-fitted track
      FAItem< TDKinematicFit > trackFit =
	 navtracks_iterator->kinematicFit( particle );
      if ( trackFit == NULL )
      {
	 report( EMERGENCY, kFacilityString )
	    << "kinematicFit is missing from the NavTrack!" << endl;
	 return ActionBase::kFailed;
      }

      // and the Kalman-fitted helix
      FAItem< TRHelixFit > trackHelix =
	 navtracks_iterator->helixFit( particle );
      if ( trackHelix == NULL )
      {
	 report( EMERGENCY, kFacilityString )
	    << "helixFit is missing from the NavTrack!" << endl;
	 return ActionBase::kFailed;
      }
      TRHelixFit loc_trackHelix = (* trackHelix );
   
   // Move the track's reference point to the origin so that d0 and
   // z0 will be right (later, this will be to the beamspot)
      report( INFO, kFacilityString )
	 << "Attempting to move helix." << endl;
      Meters movelength;
      KTHelix::MoveStatus status =
	 loc_trackHelix.moveToReferencePoint( HepPoint3D( 0., 0., 0. ),
					      movelength );
      if ( status != KTMoveControl::kMoveOK )
      {
	 report( EMERGENCY, kFacilityString )
	    << "trackHelix.moveToReferencePoint returned "
	    << status << " (not kMoveOK, as it should)." << endl;
	 return ActionBase::kFailed;
      }
      report( INFO, kFacilityString )
	 << "Moved helix sucessfully." << endl;
      
      // Get its quality object
      FAItem< TRTrackFitQuality > trackQuality =
	 navtracks_iterator->quality( particle );
      if ( trackQuality == NULL )
      {
	 report( EMERGENCY, kFacilityString )
	    << "quality object is missing from the NavTrack!" << endl;
	 return ActionBase::kFailed;
      }

      // Get the DR hits associated with it
      const vector< const CalibratedDRHit* >* p_trackDRHits;
      vector< const CalibratedDRHit* > trackDRHits;
      vector< const CalibratedDRHit* >::const_iterator trackDRHits_iterator;
      vector< const CalibratedDRHit* >::const_iterator trackDRHits_begin;
      vector< const CalibratedDRHit* >::const_iterator trackDRHits_end;

      if ( ! m_hit_finished )
      {
	 p_trackDRHits = navtracks_iterator->electronDRHits();
	 if ( p_trackDRHits == NULL )
	 {
	    report( EMERGENCY, kFacilityString )
	       << "electronDRHits is missing from the NavTrack!" << endl;
	    return ActionBase::kFailed;
	 }
	 trackDRHits = (* p_trackDRHits );
	 trackDRHits_begin = trackDRHits.begin();
	 trackDRHits_end = trackDRHits.end();
      }

      // Get the variables to cut on
      HepVector3D momentum = trackFit->momentum();
      double cotTheta = loc_trackHelix.cotTheta();
      double cosTheta = cotTheta / sqrt( 1 + cotTheta * cotTheta );
      double chiSquare = trackQuality->chiSquare();
      int degreesOfFreedom = trackQuality->degreesOfFreedom();
      int numberHits = trackQuality->numberHits();
      int numberHitsExpected = trackQuality->numberHitsExpected();
      double d0 = loc_trackHelix.d0();
      double z0 = loc_trackHelix.z0();
      double cotTheta_err =
	 sqrt( abs( loc_trackHelix.errorMatrix()( KTHelix::kCotTheta,
						  KTHelix::kCotTheta ) ) );
      double z0_err =
	 sqrt( abs( loc_trackHelix.errorMatrix()( KTHelix::kZ0,
						  KTHelix::kZ0 ) ) );
      double phi0 = loc_trackHelix.phi0();

      // and some variables to plot
      double chi2dof;
      if ( degreesOfFreedom != 0 )
	 chi2dof = ( chiSquare / double( degreesOfFreedom ) );
      else
	 chi2dof = -1;
      double chi2dofExpected = 0.;
//      double chi2dofExpected = chisin_( ran.flat(), degreesOfFreedom );
      double confLevel = prob_( chiSquare, degreesOfFreedom );
   
      // set up variables for D0 and Z0 miss histograms
      event_d0[ whichTrack ] = d0;
      event_d0_err[ whichTrack ] =
	 loc_trackHelix.errorMatrix()( KTHelix::kD0, KTHelix::kD0 );
      
      event_z0[ whichTrack ] = z0;
      event_z0_err[ whichTrack ] =
	 loc_trackHelix.errorMatrix()( KTHelix::kZ0, KTHelix::kZ0 );

      event_phi0[ whichTrack ] = phi0;
      event_cotTheta[ whichTrack ] = cotTheta;
      event_momentum[ whichTrack ] = momentum.mag();
      
      // fill some histograms
      h_raw_number_DR_hits->fill( double( numberHits ) );
      h_raw_momentum->fill( momentum.mag() );
      if ( numberHitsExpected != 0 )
	 h_raw_efficiency_ratio->fill( double( numberHits ) /
				       double( numberHitsExpected ) );
      if ( degreesOfFreedom != 0 )
	 h_raw_chi2_per_dof->fill( chiSquare / double( degreesOfFreedom ) );
      h_raw_cotTheta_err->fill( cotTheta_err );
      h_raw_z0_err->fill( z0_err );
      h_raw_cotTheta->fill( cotTheta );
      h_raw_d0->fill( d0 );
      h_raw_z0->fill( z0 );

      h_res_chi2->fill( chiSquare );
      h_res_dof->fill( double( degreesOfFreedom ) );
      h_res_chi2dof->fill( chi2dof );
      h_res_chi2dofExpected->fill( chi2dofExpected );
      h_res_confLevel->fill( confLevel );
      h_res_momentum->fill( momentum.mag() );

      int cutlevel;
      // Cut on them (REJECT if any of the below are TRUE).
      if ( trackQuality->fitAbort()                                    ||
	   momentum.mag() < 0.1                                        ||
	   momentum.mag() > 7.0                                        ||
	   abs( cosTheta ) > 0.95                                      ||
	   degreesOfFreedom == 0                                       ||
//	   chi2dof > 6.                                                ||
	   chi2dof <= 0.0                                              ||
	   numberHitsExpected == 0                                     ||
	   double( numberHits ) / double( numberHitsExpected ) < 0.5   ||
// 	   double( numberHits ) / double( numberHitsExpected ) > 1.0   ||
//	   abs( d0 ) > 0.03                                            ||
	   abs( d0 ) > 0.20                                            ||
	   abs( z0 ) > 0.150                                           ||
	   cotTheta_err > 0.500                                        ||
	   z0_err > 0.25                                                   )
      {
	 cutlevel = 0;
	 report( INFO, kFacilityString )
	    << "Track doesn't pass quality cuts!" << endl;
	 report( INFO, kFacilityString )
	    << "(momentum, chiSquare, degreesOfFreedom, numberHits, "
	    << "numberHitsExpected, cotTheta, d0, z0, "
	    << "cotTheta_err, z0_err) =" << endl;
	 report( INFO, kFacilityString )
	    << "(" << momentum.mag() << ", " << chiSquare
	    << ", " << degreesOfFreedom << ", " << numberHits
	    << ", " << numberHitsExpected << ", "
	    << ", " << cotTheta << ", " << d0 << ", " << z0
	    << ", " << cotTheta_err << ", " << z0_err << ")" << endl;
      }
      else // passes cuts
      {
	 cutlevel = 1;
	 passedTrackQualityCuts++;
	 
	 h_cut_number_DR_hits->fill( double( numberHits ) );
	 h_cut_momentum->fill( momentum.mag() );
	 h_cut_efficiency_ratio->fill( double( numberHits ) /
				       double( numberHitsExpected ) );
	 h_cut_chi2_per_dof->fill( chi2dof );
	 h_cut_cotTheta_err->fill( cotTheta_err );
	 h_cut_z0_err->fill( z0_err );
	 h_cut_cotTheta->fill( cotTheta );
	 h_cut_d0->fill( d0 );
	 h_cut_z0->fill( z0 );

	 h_res_chi2dof_tq->fill( chi2dof );
	 h_res_chi2dofExpected_tq->fill( chi2dofExpected );
	 h_res_confLevel_tq->fill( confLevel );
	 h_res_momentum_tq->fill( momentum.mag() );

	 // loop over hits
	 if ( ! m_hit_finished )
	 {
	    for( trackDRHits_iterator = trackDRHits_begin;
		 trackDRHits_iterator != trackDRHits_end;
		 trackDRHits_iterator++ )
	    {
	       // get the link between this track and this hit, and its linkdata
	       report( DEBUG, kFacilityString )
		  << "Trying to get hit link..." << endl;
	       const TrackFitDRHitLink& trackDRHitLink =
		  getHitLink( navtracks_iterator, trackDRHits_iterator,
			      drhitLattice );
	       report( DEBUG, kFacilityString ) << "...got hit link!" << endl;

	       if ( trackDRHitLink.used() )
	       {
		  // variables for calculating chi( lambda )
		  Meters dca = trackDRHitLink.signedDcaToWire();
		  Meters e_dca = trackDRHitLink.signedDcaError();
		  Meters drift = trackDRHitLink.signedDriftDistance();
//	       Meters e_drift = trackDRHitLink.signedDriftError();
		  Meters e_dr_fw = ( 1.0 / sqrt( trackDRHitLink.fittingWeight() ) );

	       // variables for binning lambda
		  int layer = (* trackDRHits_iterator )->layer();
		  double layerRadius = adrWireStore->radius( layer );
		  int layerCells = adrWireStore->numberOfWiresLyr( layer );

		  if ( layerRadius != 0. )
		  {
		     report( DEBUG, kFacilityString )
			<< "    Taking this hit." << endl;
	    
		     // variables for binning lambda
		     double absDrift = ( abs( drift ) * double( layerCells ) /
					 ( MFW_PI * layerRadius ) );

		     double distance_swim;
		     TRHelixFit tmp_trackHelix = (* trackHelix );
		     double z = tmp_trackHelix.moveToRadius( layerRadius,
							     distance_swim );
		     double phi = adrWireStore->wire(
			(* trackDRHits_iterator )->wire() ).zPoint( z ).first.phi();

		     if ( e_dca != 0.  &&  e_dr_fw != 0. )
		     {
			report( INFO, kFacilityString )
			   << "    We have seen " << m_hit_num << " hits." << endl;
			if ( m_hit_num > 50000 )
			   m_hit_finished = true;
			else
			{
			   report( INFO, kFacilityString )
			      << "      This hit is being added to the ntuple."
			      << endl;
			   float hitvars[ 10 ] =
			   { dca, e_dca, drift, e_dr_fw, layer, cosTheta, absDrift,
			     phi, layerRadius, layerCells };
			   nt_hit_vars->fill( hitvars );
			}
			m_hit_num++;

		     } // end if both errors are not 0.
		  } // end if layerRadius != 0.
		  else
		     report( INFO, kFacilityString )
			<< "    Not taking this hit because layerRadius == 0"
			<< endl;
	       } // end if hitlink.used()
	    } // end foreach hit
	 } // end if not finished with hits

      } // end else passes cuts

      report( INFO, kFacilityString )
	 << "  We have seen " << m_track_num << " tracks." << endl;
      if ( m_track_num > 50000 )
	 m_track_finished = true;
      else
      {
	 report( INFO, kFacilityString )
	    << "    This track is being added to the ntuple." << endl;
	 float trackvars[ 9 ] =
	 { float(cutlevel), chiSquare, degreesOfFreedom, confLevel,
	   momentum.mag(), phi0, cotTheta, d0, z0 };
	 nt_track_vars->fill( trackvars );
      }
      if ( cutlevel == 1 )
	 m_track_num++;

      whichTrack++;
   } // end foreach track
   
   // filling D0 and Z0 miss histograms
   if ( passedTrackQualityCuts == 2 )
   {
      if ( event_d0_err[0] == 0.  ||  event_d0_err[1] == 0.  ||
	   event_z0_err[0] == 0.  ||  event_z0_err[1] == 0.      )
      {
	 report( ERROR, kFacilityString )
	    << "Something is wrong with the errors: d0[1] = " << event_d0_err[0]
	    << ", d0[2] = " << event_d0_err[1] << ", z0[1] = " << event_z0_err[0]
	    << " and z0[2] = " << event_z0_err[1] << "." << endl;
	 return ActionBase::kFailed;
      }

      report( INFO, kFacilityString )
	 << "We have seen " << m_event_num << " events." << endl;
      if ( m_event_num > 50000 )
	 m_event_finished = true;
      else
      {
	 report( INFO, kFacilityString )
	    << "  This event is being added to the ntuple." << endl;
	 float eventvars[ 14 ] =
	 { event_d0[0], event_d0[1], event_d0_err[0], event_d0_err[1],
	   event_z0[0], event_z0[1], event_z0_err[0], event_z0_err[1],
	   event_phi0[0], event_phi0[1],
	   event_cotTheta[0], event_cotTheta[1],
	   event_momentum[0], event_momentum[1] };
	 nt_event_vars->fill( eventvars );
      }
      m_event_num++;

      // d0_err and z0_err are sigma^2, not sigma
      double missD0 = ( event_d0[0] + event_d0[1] )
	 / sqrt( event_d0_err[0] + event_d0_err[1] );
      double missZ0 = ( event_z0[0] - event_z0[1] )
	 / sqrt( event_z0_err[0] + event_z0_err[1] );
      
      h_missD0->fill( missD0 );
      h_missZ0->fill( missZ0 );
      report( DEBUG, kFacilityString )
	 << "event: filled miss histograms" << endl;
      report( DEBUG, kFacilityString )
	 << "event: wrote miss histogram information to disk" << endl;
   }

   return ActionBase::kPassed;
}

////////////////////////////////////////////////////////////////// do_ksEvent()

ActionBase::ActionResult
CheckFittingWeights::do_ksEvent( Frame& iFrame,
				 FATable< VXFitVeeKShort > kshorts )
{
   DBCandidate::Hypo particle = DBCandidate::kChargedPion;

//   RandomGenerator& ran( RandomGenerator::instance() );

   FATable< NavTrack > navtracks;
   extract( iFrame.record( Stream::kEvent ), navtracks );
   FATable< NavTrack >::const_iterator navtracks_iterator;
   report( DEBUG, kFacilityString ) << "event: got NavTracks" << endl;

   FATable< VXFitVeeKShort >::const_iterator ks_iter;
   FATable< VXFitVeeKShort >::const_iterator ks_begin = kshorts.begin();
   FATable< VXFitVeeKShort >::const_iterator ks_end = kshorts.end();

   float event_phi0[2];
   float event_cotTheta[2];
   float event_momentum[2];

   for( ks_iter = ks_begin; ks_iter != ks_end; ks_iter++ )
   {
      int passedTrackQualityCuts = 0;
      for( int whichTrack = 0;  whichTrack < 2;  whichTrack++ )
      {
	 if ( whichTrack == 0 )
	    navtracks_iterator = navtracks.find( ks_iter->piPlusId() );
	 else
	    navtracks_iterator = navtracks.find( ks_iter->piMinusId() );

	 // Get the Kalman-fitted track
	 FAItem< TDKinematicFit > trackFit =
	    navtracks_iterator->kinematicFit( particle );
	 if ( trackFit == NULL )
	 {
	    report( EMERGENCY, kFacilityString )
	       << "kinematicFit is missing from the NavTrack!" << endl;
	    return ActionBase::kFailed;
	 }
	 
	 // and the Kalman-fitted helix
	 FAItem< TRHelixFit > trackHelix =
	    navtracks_iterator->helixFit( particle );
	 if ( trackHelix == NULL )
	 {
	    report( EMERGENCY, kFacilityString )
	       << "helixFit is missing from the NavTrack!" << endl;
	    return ActionBase::kFailed;
	 }
	 TRHelixFit loc_trackHelix = (* trackHelix );
	 
	 // Move the track's reference point to the origin so that d0 and
	 // z0 will be right (later, this will be to the beamspot)
	 report( INFO, kFacilityString )
	    << "Attempting to move helix." << endl;
	 Meters movelength;
	 KTHelix::MoveStatus status =
	    loc_trackHelix.moveToReferencePoint( HepPoint3D( 0., 0., 0. ),
						 movelength );
	 if ( status != KTMoveControl::kMoveOK )
	 {
	    report( EMERGENCY, kFacilityString )
	       << "trackHelix.moveToReferencePoint returned "
	       << status << " (not kMoveOK, as it should)." << endl;
	    return ActionBase::kFailed;
	 }
	 report( INFO, kFacilityString )
	    << "Moved helix sucessfully." << endl;
	 
	 // Get its quality object
	 FAItem< TRTrackFitQuality > trackQuality =
	    navtracks_iterator->quality( particle );
	 if ( trackQuality == NULL )
	 {
	    report( EMERGENCY, kFacilityString )
	       << "quality object is missing from the NavTrack!" << endl;
	    return ActionBase::kFailed;
	 }

	 // Get the variables to cut on
	 HepVector3D momentum = trackFit->momentum();
	 double cotTheta = loc_trackHelix.cotTheta();
	 double cosTheta = cotTheta / sqrt( 1 + cotTheta * cotTheta );
	 double chiSquare = trackQuality->chiSquare();
	 int degreesOfFreedom = trackQuality->degreesOfFreedom();
	 int numberHits = trackQuality->numberHits();
	 int numberHitsExpected = trackQuality->numberHitsExpected();
	 double d0 = loc_trackHelix.d0();
	 double z0 = loc_trackHelix.z0();
	 double cotTheta_err =
	    sqrt( abs( loc_trackHelix.errorMatrix()( KTHelix::kCotTheta,
						     KTHelix::kCotTheta ) ) );
	 double z0_err =
	    sqrt( abs( loc_trackHelix.errorMatrix()( KTHelix::kZ0,
						     KTHelix::kZ0 ) ) );

	 double phi0 = loc_trackHelix.phi0();

	 event_phi0[ whichTrack ] = phi0;
	 event_cotTheta[ whichTrack ] = cotTheta;
	 event_momentum[ whichTrack ] = momentum.mag();

	 // Cut on them (REJECT if any of the below are TRUE).
	 if ( trackQuality->fitAbort()                                    ||
	      momentum.mag() < 0.1                                        ||
	      momentum.mag() > 7.0                                        ||
	      abs( cosTheta ) > 0.95                                      ||
	      degreesOfFreedom == 0                                       ||
	      chiSquare / double( degreesOfFreedom ) > 6.                 ||
	      chiSquare / double( degreesOfFreedom ) <= 0.0               ||
	      numberHitsExpected == 0                                     ||
	      double( numberHits ) / double( numberHitsExpected ) < 0.5   ||
// 	      double( numberHits ) / double( numberHitsExpected ) > 1.0   ||
//	      abs( d0 ) > 0.03                                            ||
	      abs( d0 ) > 0.20                                            ||
	      abs( z0 ) > 0.150                                           ||
	      cotTheta_err > 0.500                                        ||
	      z0_err > 0.25                                                   )
	 {
	    report( INFO, kFacilityString )
	       << "Track doesn't pass quality cuts!" << endl;
	    report( INFO, kFacilityString )
	       << "(momentum, chiSquare, degreesOfFreedom, numberHits, "
	       << "numberHitsExpected, cotTheta, d0, z0, "
	       << "cotTheta_err, z0_err) =" << endl;
	    report( INFO, kFacilityString )
	       << "(" << momentum.mag() << ", " << chiSquare
	       << ", " << degreesOfFreedom << ", " << numberHits
	       << ", " << numberHitsExpected
	       << ", " << cotTheta << ", " << d0 << ", " << z0
	       << ", " << cotTheta_err << ", " << z0_err << ")" << endl;
	 }
	 else // passes cuts
	 {
	    passedTrackQualityCuts++;
	    
	    h_cut_number_DR_hits->fill( double( numberHits ) );
	    h_cut_momentum->fill( momentum.mag() );
	    h_cut_efficiency_ratio->fill( double( numberHits ) /
					  double( numberHitsExpected ) );
	    h_cut_chi2_per_dof->fill( chiSquare / double( degreesOfFreedom ) );
	    h_cut_cotTheta_err->fill( cotTheta_err );
	    h_cut_z0_err->fill( z0_err );
	    h_cut_cotTheta->fill( cotTheta );
	    h_cut_d0->fill( d0 );
	    h_cut_z0->fill( z0 );
	    
	 } // end else passes cuts
      } // end do pi+, then pi-

      int cutlevel = 0;
      double chi2 = ks_iter->fitChiSquare();
      double chi2dof = chi2; // only one d.o.f
      double chi2dofExpected = 0.;
//      double chi2dofExpected = chisin_( ran.flat(), 1 );
      double confLevel = prob_( chi2, 1 );
      double mass = ks_iter->mass();
      const HepPoint3D vertex = ks_iter->guessVertex();
      const HepPoint3D ks_momentum = ks_iter->momentum();

      // plot vertex.perp() / momentum.perp() * 4momentum.mag() of the k-short
      // with a fixed mass (world average or fitted) in the 4momentum

      h_ks_chi2dof->fill( chi2dof );
      h_ks_chi2dofExpected->fill( chi2dofExpected );
      h_ks_confLevel->fill( confLevel );
      h_ks_mass->fill( mass );

      if ( passedTrackQualityCuts == 2 )
      {
	 cutlevel = 1;

	 h_ks_chi2dof_tq->fill( chi2dof );
	 h_ks_chi2dofExpected_tq->fill( chi2dofExpected );
	 h_ks_confLevel_tq->fill( confLevel );
	 h_ks_mass_tq->fill( mass );

	 if ( abs( mass - 0.4994 ) < 0.01228 )
	    h_ks_confLevel_ks->fill( confLevel );
	 else
	    h_ks_confLevel_non_ks->fill( confLevel );

	 if ( confLevel > 0.01 )
	 {
	    cutlevel = 2;

	    h_ks_chi2dof_all->fill( chi2dof );
	    h_ks_chi2dofExpected_all->fill( chi2dofExpected );
	    h_ks_confLevel_all->fill( confLevel );
	    h_ks_mass_all->fill( mass );
	 }
      }

      if ( m_ks_num > 50000 )
	 m_ks_finished = true;
      else
      {
	 float ksvars[ 16 ] =
	 { float(cutlevel), chi2, confLevel, mass,
	   vertex.x(), vertex.y(), vertex.z(),
	   ks_momentum.x(), ks_momentum.y(), ks_momentum.z(),
	   event_phi0[0], event_phi0[1],
	   event_cotTheta[0], event_cotTheta[1],
	   event_momentum[0], event_momentum[1] };
	 nt_ks_vars->fill( ksvars );
      }
      if ( cutlevel == 2 )
	 m_ks_num++;

   } // end foreach K0short vertex
   
   return ActionBase::kPassed;
}

/*
ActionBase::ActionResult
CheckFittingWeights::beginRun( Frame& iFrame )       // anal2 equiv.
{
   report( DEBUG, kFacilityString ) << "here in beginRun()" << endl;

   return ActionBase::kPassed;
}
*/

/*
ActionBase::ActionResult
CheckFittingWeights::endRun( Frame& iFrame )         // anal4 equiv.
{
   report( DEBUG, kFacilityString ) << "here in endRun()" << endl;

   return ActionBase::kPassed;
}
*/

//
// const member functions
//

const TrackFitDRHitLink& CheckFittingWeights::getHitLink(
   FATable< NavTrack >::const_iterator navtracks_iterator,
   vector< const CalibratedDRHit* >::const_iterator trackDRHits_iterator,
   FAItem< ElectronFitDRHitLattice > drhitLattice )
{
//    if ( ! avoid_lattice.value() )
//    {
//       const ElectronFitDRHitLattice::Link* p_trackDRHitLink =
// 	 drhitLattice->connectLink( navtracks_iterator->identifier(),
// 				    (* trackDRHits_iterator )->identifier() );
//       if ( p_trackDRHitLink == NULL )
//       {
// 	 report( EMERGENCY, kFacilityString )
// 	    << "Couldn't get the (single) link between this track ("
// 	    << navtracks_iterator->identifier() << ") "
// 	    << "and this hit ( " << (* trackDRHits_iterator )->identifier()
// 	    << "), which should be on the track." << endl;
// 	 return m_nullHitLink;
//       }
//       return p_trackDRHitLink->linkData();
//    }
//    else // avoid lattice
//    {
      report( DEBUG, kFacilityString ) << "getHitLink: avoiding lattice" << endl;
      const NavTrack::DRHitLinkTable* trackDRLinks =
	 navtracks_iterator->electronDRHitLinks();
      if ( trackDRLinks == NULL )
      {
	 report( EMERGENCY, kFacilityString )
	    << "NavTrack is missing the electron hit links!" << endl;
	 return m_nullHitLink;
      }
      NavTrack::DRHitLinkTable::const_iterator trackDRLinks_iterator;
      NavTrack::DRHitLinkTable::const_iterator trackDRLinks_begin =
	 trackDRLinks->begin();
      NavTrack::DRHitLinkTable::const_iterator trackDRLinks_end =
	 trackDRLinks->end();

      for( trackDRLinks_iterator = trackDRLinks_begin;
	   trackDRLinks_iterator != trackDRLinks_end
	      &&  (     (* trackDRLinks_iterator )->rightID() == 0
	            ||  *(* trackDRLinks_iterator )->rightID() !=
		        ( *trackDRHits_iterator )->identifier()
		  );
	   trackDRLinks_iterator++ );

      if ( trackDRLinks_iterator == trackDRLinks_end       ||
	   (* trackDRLinks_iterator )->rightID() == 0 )
      {
	 report( EMERGENCY, kFacilityString )
	    << "Couldn't get the link between this track ("
	    << navtracks_iterator->identifier() << ") "
	    << "and this hit ( " << (* trackDRHits_iterator )->identifier()
	    << "), even avoiding Lattice." << endl;
	 return m_nullHitLink;
      }
      return (* trackDRLinks_iterator )->linkData();
//   } // end avoid lattice
}

//
// static member functions
//

////////////////////////////////////////////////////////////////// The garage

// looping over hits. Maybe I'll want to do that again someday

//    FAItem< ElectronFitDRHitLattice > drhitLattice;
//    extract( iFrame.record( Stream::kEvent ), drhitLattice );
//    report( DEBUG, kFacilityString ) << "event: got DRHitLattice" << endl;

//    FAItem< ADRSenseWireStore > adrWireStore;
//    extract( iFrame.record( Stream::kBaseGeometry ), adrWireStore );
//    if ( ! adrWireStore.valid() )
//    {
//       report( EMERGENCY, kFacilityString )
// 	 << "ADRSenseWireStore is not valid!" << endl;
//       return ActionBase::kFailed;
//    }

//       // Get the DR hits associated with it
//       const vector< const CalibratedDRHit* >* p_trackDRHits =
// 	 navtracks_iterator->electronDRHits();
//       if ( p_trackDRHits == NULL )
//       {
// 	 report( EMERGENCY, kFacilityString )
// 	    << "electronDRHits is missing from the NavTrack!" << endl;
// 	 return ActionBase::kFailed;
//       }
//       vector< const CalibratedDRHit* > trackDRHits = (* p_trackDRHits );

//       vector< const CalibratedDRHit* >::const_iterator trackDRHits_iterator;
//       vector< const CalibratedDRHit* >::const_iterator trackDRHits_begin =
// 	 trackDRHits.begin();
//       vector< const CalibratedDRHit* >::const_iterator trackDRHits_end =
// 	 trackDRHits.end();

// 	 ///////////////////////////////////////////////// Start loop over hits
// 	 for( trackDRHits_iterator = trackDRHits_begin;
// 	      trackDRHits_iterator != trackDRHits_end;
// 	      trackDRHits_iterator++ )
// 	 {
// 	    // get the link between this track and this hit, and its linkdata
// 	    report( DEBUG, kFacilityString )
// 	       << "Trying to get hit link..." << endl;
// 	    const TrackFitDRHitLink& trackDRHitLink =
// 	       getHitLink( navtracks_iterator, trackDRHits_iterator,
// 			   drhitLattice );
// 	    report( DEBUG, kFacilityString ) << "...got hit link!" << endl;

// 	    if ( trackDRHitLink.used() )
// 	    {
// 	       // variables for calculating chi( lambda )
// 	       Meters dca = trackDRHitLink.signedDcaToWire();
// 	       Meters e_dca = trackDRHitLink.signedDcaError();
// 	       Meters drift = trackDRHitLink.signedDriftDistance();
// 	       Meters e_drift = trackDRHitLink.signedDriftError();
// 	       Meters fitweight = trackDRHitLink.fittingWeight();

// 	       h_e_drift->fill( e_drift );

// 	       // variables for binning lambda
// 	       int layer = (* trackDRHits_iterator )->layer();
// 	       double layerRadius = adrWireStore->radius( layer );
// 	       int layerCells = adrWireStore->numberOfWiresLyr( layer );

// 	       if ( layerRadius != 0. )
// 	       {
// 		  report( DEBUG, kFacilityString )
// 		     << "    Taking this hit." << endl;
	    
// 		  // variables for binning lambda
// 		  double absDrift = ( abs( drift ) * double( layerCells ) /
// 				      ( MFW_PI * layerRadius ) );

// 		  double theResidual = trackDRHitLink.residual();
// 		  double theResidualErr = trackDRHitLink.residualError();

// 		  // variables for plotting progress
// 		  if ( e_dca != 0.  &&  e_drift != 0. )
// 		  {
// 		     double simpleChi = ( dca - drift )
// 			/ sqrt( e_dca * e_dca + e_drift * e_drift );
// 		     if ( abs( simpleChi ) < 3.5 )
// 			h_simpleChi->fill( simpleChi );
// 		  }
// 		  else
// 		  {
// 		     report( ERROR, kFacilityString )
// 			<< "Something is wrong with the errors in dca ("
// 			<< e_dca << ") and drift (" << e_drift << ")."
// 			<< endl;
// 		  } // end if both errors are not 0.
// 	       } // end if layerRadius != 0.
// 	       else
// 		  report( INFO, kFacilityString )
// 		     << "    Not taking this hit because layerRadius == 0"
// 		     << endl;
// 	    } // end if hitlink.used()
// 	 } // end foreach hit

