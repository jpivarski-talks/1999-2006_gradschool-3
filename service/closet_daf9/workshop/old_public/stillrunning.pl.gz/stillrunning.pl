#!/usr/local/bin/perl

##############################################################################
# Explaination of output:
# 
#  0  means I couldn't find the run on the queue
#  1  means I found it in the "currently running" section of the queue
# -1  means I found it in the queue but the datestamp is over 12 hours old
#  2  means I found it in the "pending" section of the queue
#
# It is in the queue if I see: "pass2  [space]  ######_pa  [anything else]"
# This can crash if the datestamp looks ok but actually isn't.
#
##############################################################################

# For reverse-engineering the timestamp
use Time::Local;
%months = ( "Jan", 0, "Feb", 1, "Mar", 2, "Apr", 3, "May", 4, "Jun", 5,
	    "Jul", 6, "Aug", 7, "Sep", 8, "Oct", 9, "Nov", 10, "Dec", 11 );

# Set up the directory name
$STATSDIR = "/home/pass2/Pass2Production/pass2/Pass2Scripts/stats";

# Get the runs we will be looking up (this is also the format for the output)
@runs = ();
open( NOTRUNNUM, "$STATSDIR/not_runnumber.txt" );
while( $_ = <NOTRUNNUM> )
{
    $_ =~ /([0-9]{6})/;
    push( @runs, $1 );
}
close NOTRUNNUM;

# Get the current time (in seconds since epoch)
$curtime = time;

# Get the timestamp on each run from the associated file
%date = ();
$i = 0;
open( LASTACT, "$STATSDIR/not_lastactive.txt" );
while( $_ = <LASTACT> )
{
    if ( $_ =~ /([A-Z]{1}[a-z]{2})_([A-Z]{1}[a-z]{2})_([0-9]{1,2})_([0-9]{1,2}):([0-9]{2}):([0-9]{2})_([0-9]{4})/ )
    {
	$wday = $1;  $month = $2;  $day = $3;  $hour = $4;  $minute = $5;  $second = $6;  $year = $7;

#	print "\"$wday\" \"$month\" \"$day\" \"$hour\" \"$minute\" \"$second\" \"$year\"\n";

	# Be careful! An improperly-formatted timestamp can cause "timelocal" to crash the script process
	if ( ( $wday eq "Mon"  ||  $wday eq "Tue"  ||  $wday eq "Wed"  ||  $wday eq "Thu"  ||  
	       $wday eq "Fri"  ||  $wday eq "Sat"  ||  $wday eq "Sun"                                 )  &&
	     ( $month eq "Jan"  ||  $month eq "Feb"  ||  $month eq "Mar"  ||  $month eq "Apr"  ||  
	       $month eq "May"  ||  $month eq "Jun"  ||  $month eq "Jul"  ||  $month eq "Aug"  ||  
	       $month eq "Sep"  ||  $month eq "Oct"  ||  $month eq "Nov"  ||  $month eq "Dec"         )  &&
	     ( $day > 0  &&  $day < 32                                                                )  &&
	     ( $hour >= 0  &&  $hour < 24                                                             )  &&
	     ( $minute >= 0  &&  $minute < 60                                                         )  &&
	     ( $year > 1970 )                                                                                )
	{
	    # Replace the English abbreviation of the month with a number between zero and eleven
	    $month = $months{$month};
	    # Get the seconds since epoch for this timestamp
	    $logtime = timelocal( $second, $minute, $hour, $day, $month, $year );
	    # Compare them
	    $diff = ( $curtime - $logtime );
	    # Store the difference
	    $date{$runs[$i]} = $diff;
	}
    }
    $i++;
}

# Call qstat to see which are still on the queue
%p2run = ();
%p2pend = ();
open( QSTAT, "qstat -cell rcf |" );
$pendyet = 0;
while( $_ = <QSTAT> )
{
    if ( $_ =~ /pending jobs/i )
    {
	$pendyet = 1;
#	print "hit pendyet\n";
    }

    # For each list item, store the run number in hash tables
    elsif ( $_ =~ /^pass2\s+([0-9]{6})_pa/ )
    {
	$p2run{$1} = 1 if ( $pendyet == 0 );
	$p2pend{$1} = 1 if ( $pendyet == 1 );
    }

}
close QSTAT;

# Print out a number that summarizes the status of the run
open( STILLRUNNING, "> $STATSDIR/not_stillrunning.txt" );
#open( STILLRUNNING, ">&STDOUT" );
foreach $run ( @runs )
{
#    print STILLRUNNING "$run \"$date{$run}\" \"$p2run{$run}\" \"$p2pend{$run}\"";

    if ( defined( $p2run{$run} ) )
    {
	if ( defined( $date{$run} )  &&  $date{$run} < (12 * 60 * 60) )
	{
	    print STILLRUNNING " StillRunning : 1\n";
	}
	else
	{
	    print STILLRUNNING " StillRunning : -1\n";
	}
    }

    elsif ( defined( $p2pend{$run} ) )
    {
	print STILLRUNNING " StillRunning : 2\n";
    }

    else
    {
	print STILLRUNNING " StillRunning : 0\n";
    }
}
close STILLRUNNING;

# All done!
