// -*- C++ -*-
#if !defined(DRSTEREOALIGNMENT_DRSTEREOALIGNMENT_H)
#define DRSTEREOALIGNMENT_DRSTEREOALIGNMENT_H
//
// Package:     DRStereoAlignment
// Module:      DRStereoAlignment
//
/**\class DRStereoAlignment DRStereoAlignment.h DRStereoAlignment/DRStereoAlignment.h
 
 Description: Suez Module that allows you to control the "event" loop

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Sat Jul 21 12:40:45 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "CommandPattern/Module.h"
#include "FrameIterate/FrameIteratorModuleBase.h"
#include "FrameIterate/FIHolder.h"
#include "CLEOConstantsModifiable/CLEOConstantsModifiable.h"
#include "BDLDRclient/DBDRGeomAlignment.hh"

#include "MinuitInterface/MIFcn.h"

// forward declarations

class DRStereoAlignment : public FrameIteratorModuleBase
{
      // ---------- friend classes and functions ---------------
      friend class alignmentFcn;

   public:
      // ---------- constants, enums and typedefs --------------

      // ---------- Constructors and destructor ----------------
      DRStereoAlignment();
      virtual ~DRStereoAlignment();

      // ---------- member functions ---------------------------

      // ---------- const member functions ---------------------

      // ---------- static member functions --------------------

   protected:
      // ---------- protected member functions -----------------

      ///override this function to do the actual iterations
      virtual void iterate( const FIFrameIterator& iBegin,
			    const FIFrameIterator& iEnd );

      // ---------- protected const member functions -----------

   private:
      // ---------- Constructors and destructor ----------------
      DRStereoAlignment( const DRStereoAlignment& ); // stop default

      // ---------- assignment operator(s) ---------------------
      const DRStereoAlignment& operator=( const DRStereoAlignment& ); // stop default

      // ---------- private member functions -------------------

      // ---------- private const member functions -------------

      // ---------- data members -------------------------------

      CLEOConstantsModifiable< DBDRGeomAlignment > m_geomalignment;
      FIHolder< CLEOConstants< DBDRGeomAlignment > > m_geomalignmentHolder;

      // ---------- static data members ------------------------

      // ---------- nested classes -----------------------------

   public:
      class alignmentFcn : public MIFcn
      {
	 public:
	    alignmentFcn( HIHistoManager* hm,
			  const FIFrameIterator* begin,
			  const FIFrameIterator* end,
			  CLEOConstantsModifiable< DBDRGeomAlignment >* align );
	    ~alignmentFcn();
	    void make_histograms( int howmany );
	    double iterate( double* values );

	 protected:
	    alignmentFcn();

	 private:
	    HIHistoManager* m_hm;
	    const FIFrameIterator* m_begin;
	    const FIFrameIterator* m_end;
	    CLEOConstantsModifiable< DBDRGeomAlignment >* m_align;

	    vector< HIHistProf* > h_momentumvphi0s;
	    vector< HIHistProf* > h_posmomentumvphi0s;
	    vector< HIHistProf* > h_negmomentumvphi0s;
	    vector< HIHistProf* > h_posmomentumvcotThs;
	    vector< HIHistProf* > h_negmomentumvcotThs;
	    vector< HIHistProf* > h_eventmomentumvphi0s;
	    vector< HIHist2D* > h_eventmomentumxys;
	    vector< HIHistProf* > h_d0missvphi0s;
	    vector< HIHistProf* > h_z0missvphi0s;
      };

};

// inline function definitions

// Uncomment the following lines, if your class is templated 
// and has an implementation file (in the Template directory)
//#if defined(INCLUDE_TEMPLATE_DEFINITIONS)
//# include "DRStereoAlignment/Template/DRStereoAlignment.cc"
//#endif

#endif /* DRSTEREOALIGNMENT_DRSTEREOALIGNMENT_H */
