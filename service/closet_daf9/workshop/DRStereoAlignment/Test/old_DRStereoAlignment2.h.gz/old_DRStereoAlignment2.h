// -*- C++ -*-
#if !defined(DRSTEREOALIGNMENT_DRSTEREOALIGNMENT_H)
#define DRSTEREOALIGNMENT_DRSTEREOALIGNMENT_H
//
// Package:     DRStereoAlignment
// Module:      DRStereoAlignment
//
/**\class DRStereoAlignment DRStereoAlignment.h DRStereoAlignment/DRStereoAlignment.h
 
 Description: Suez Module that allows you to control the "event" loop

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Sat Jul 21 12:40:45 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "CommandPattern/Module.h"
#include "FrameIterate/FrameIteratorModuleBase.h"
#include "FrameIterate/FIHolder.h"

#include "MinuitInterface/MIFcn.h"

// forward declarations

class DRStereoAlignment : public FrameIteratorModuleBase
{
      // ---------- friend classes and functions ---------------

   public:
      // ---------- constants, enums and typedefs --------------

      enum {
	 phi0bins = 4
      };

      // ---------- Constructors and destructor ----------------
      DRStereoAlignment();
      virtual ~DRStereoAlignment();

      // ---------- member functions ---------------------------

      // ---------- const member functions ---------------------

      // ---------- static member functions --------------------

   protected:
      // ---------- protected member functions -----------------

      ///override this function to do the actual iterations
      virtual void iterate( const FIFrameIterator& iBegin,
			    const FIFrameIterator& iEnd );

      // ---------- protected const member functions -----------

   private:
      // ---------- Constructors and destructor ----------------
      DRStereoAlignment( const DRStereoAlignment& ); // stop default

      // ---------- assignment operator(s) ---------------------
      const DRStereoAlignment& operator=( const DRStereoAlignment& ); // stop default

      // ---------- private member functions -------------------

      // ---------- private const member functions -------------

      // ---------- data members -------------------------------

      // ---------- static data members ------------------------

};

// inline function definitions

// Uncomment the following lines, if your class is templated 
// and has an implementation file (in the Template directory)
//#if defined(INCLUDE_TEMPLATE_DEFINITIONS)
//# include "DRStereoAlignment/Template/DRStereoAlignment.cc"
//#endif

class alignmentFcn : public MIFcn
{
   public:
      alignmentFcn();
      ~alignmentFcn();
      double iterate( double* values );

      void setup( HIHistoManager* hm,
		  const FIFrameIterator* begin,
		  const FIFrameIterator* end );
   private:
      HIHistoManager* m_hm;
      const FIFrameIterator* m_begin;
      const FIFrameIterator* m_end;
};

//  class plotFitFcn : public MIFcn
//  {
//     public:
//        plotFitFcn();
//        ~plotFitFcn();
//        double iterate( double* values );
		  
//        void include_plot( double plot, double phi0 );
//        void calculate_hist();
//        void print();
//        void fourier_integrate(
//  	 double* average, double* sincomp, double* coscomp );
//        double cheezychi2();
    
//     private:
//        double phi0frombin( int bin );

//        int full_points;
//        double full_sum;
//        double full_squaresum;

//        double full_mean;
//        double full_error;
		  
//        int points[ DRStereoAlignment::phi0bins ];
//        double sum[ DRStereoAlignment::phi0bins ];
//        double squaresum[ DRStereoAlignment::phi0bins ];
		  
//        double means[ DRStereoAlignment::phi0bins ];
//        double errors[ DRStereoAlignment::phi0bins ];
//  };

#endif /* DRSTEREOALIGNMENT_DRSTEREOALIGNMENT_H */
