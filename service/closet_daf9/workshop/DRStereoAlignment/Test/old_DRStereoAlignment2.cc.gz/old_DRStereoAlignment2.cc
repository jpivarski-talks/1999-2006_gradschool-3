// -*- C++ -*-
//
// Package:     <DRStereoAlignment>
// Module:      DRStereoAlignment
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Sat Jul 21 12:40:45 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "Experiment/report.h"
#include "DRStereoAlignment/DRStereoAlignment.h"
#include "DataHandler/Stream.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"
#include "FrameAccess/extract.h"
#include "DataHandler/Frame.h"

#include "Navigation/NavTrack.h"
#include "KinematicTrajectory/KTKinematicData.h"
#include "CLHEP/Vector/ThreeVector.h"
#include "JobControl/JobControl.h"
#include "ToolBox/HistogramPackage.h"
#include "MinuitInterface/MinuitInterface.h"

// STL classes
// You may have to uncomment some of these or other stl headers
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "DRStereoAlignment.DRStereoAlignment" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: fimodule.cc,v 1.2 2000/12/04 19:11:05 cdj Exp $";
static const char* const kTagString = "$Name: v03_06_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
DRStereoAlignment::DRStereoAlignment()
   : FrameIteratorModuleBase( "DRStereoAlignment", "This is my module" )
   //,m_header(0), m_headerHolder(&m_header)
{
   //You must set what streams you which to iterate over
   //  that is, what events should the Frames be stopped on
   iterateOver( Stream::kEvent );

}

// DRStereoAlignment::DRStereoAlignment( const DRStereoAlignment& rhs )
// {
//    // do actual copying here; if you implemented
//    // operator= correctly, you may be able to use just say      
//    *this = rhs;
// }

DRStereoAlignment::~DRStereoAlignment()
{
}

//
// assignment operators
//
// const DRStereoAlignment& DRStereoAlignment::operator=( const DRStereoAlignment& rhs )
// {
//   if( this != &rhs ) {
//      // do actual copying here, plus:
//      // "SuperClass"::operator=( rhs );
//   }
//
//   return *this;
// }

//
// member functions
//

//
// const member functions
//
void
DRStereoAlignment::iterate( const FIFrameIterator& iBegin,
			    const FIFrameIterator& iEnd )
{
   JobControl* jc = JobControl::instance();
   HIHistoManager* hm = jc->histogramManagerP();

   alignmentFcn alignment;
   alignment.setup( hm, &iBegin, &iEnd );

   MinuitInterface* mi = MinuitInterface::instance();
   mi->loadFcn( alignment );
   mi->setDiagLevel( MinuitInterface::kNormal );
   mi->runMigrad();
   
   double rotation = mi->parameter( 0 ).value();
   double roterr = mi->parameter( 0 ).parabolicErr();
   
   double transx = mi->parameter( 1 ).value();
   double xerr = mi->parameter( 1 ).parabolicErr();
   
   double transy = mi->parameter( 2 ).value();
   double yerr = mi->parameter( 2 ).parabolicErr();
   
   report( INFO, kFacilityString )
      << "rotation = " << rotation << " +/- " << roterr
      << ", transx = " << transx << " +/- " << xerr
      << ", transy = " << transy << " +/- " << yerr << endl;
}

//
// static member functions
//

alignmentFcn::alignmentFcn()
{
   m_hm = NULL;
   m_begin = NULL;
   m_end = NULL;

   addInitialParameter( "rotation", 1., 0.1 );
   addInitialParameter( "transx", 1., 0.1 );
   addInitialParameter( "transy", 1., 0.1 );
}

alignmentFcn::~alignmentFcn()
{ ; }

double alignmentFcn::iterate( double* values )
{
   double rotation = values[ 0 ];
   double transx = values[ 1 ];
   double transy = values[ 2 ];

   report( INFO, kFacilityString )
      << "Making a new \"momentum vs phi\" histogram with rotation = "
      << rotation << ", transx = " << transx << " and tranxy = " << transy << endl;

   static int iteration;
   HIHistProf* h_momentumvphi0 = m_hm->profile( iteration * 10 + 1
      "momentum vs phi0", DRStereoAlignment::phi0bins, 0., 2*3.1415926, 4., 6.,
      HIHistProf::kErrorOnMean );

   plotFitFcn momentumFit;

   unsigned int num_frames = 1;
   for( FIFrameIterator itFrame = (* m_begin);
	itFrame != (* m_end);
	++itFrame )
   {
      if ( num_frames % 1000 == 0 )
	 report( INFO, kFacilityString )
	    << num_frames << " events so far..." << endl;
      if ( num_frames >= 2000 )
	 break;
      num_frames++;

      FATable< NavTrack > navtracks;
      extract( itFrame->record( Stream::kEvent ), navtracks );
      FATable< NavTrack >::const_iterator navtracks_iter;
      FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
      FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
      for ( navtracks_iter = navtracks_begin;
	    navtracks_iter != navtracks_end;
	    navtracks_iter++ )
      {
	 HepVector3D momentum = navtracks_iter->muonFit()->momentum();
	 const crossing_angle = HepVector3D( -0.026, 0., 0. );
	 momentum = momentum - crossing_angle;

	 double phi0 = navtracks_iter->muonHelix()->phi0();
	    
	 h_momentumvphi0->fill( phi0, momentum.mag() );

	 momentumFit.include_plot( momentum.mag(), phi0 );

      } // end loop over tracks
   } // end loop over frames

   report( INFO, kFacilityString )
      << "Finished loop over events!" << endl;

   momentumFit.calculate_hist();

   report( INFO, kFacilityString )
      << "cheezychi2's: momentum " << momentumFit.cheezychi2() << endl;

   return momentumFit.cheezychi2();
}

void alignmentFcn::setup( HIHistoManager* hm,
			  const FIFrameIterator* begin,
			  const FIFrameIterator* end )
{
   m_hm = hm;
   m_begin = begin;
   m_end = end;
}

////////////////////////////////////////////////////////////////////////

//  plotFitFcn::plotFitFcn()
//  {
//     for ( int i = 0;  i < DRStereoAlignment::phi0bins;  i++ )
//     {
//        points[ i ] = 0;
//        sum[ i ] = 0.;
//        squaresum[ i ] = 0.;
//     }

//     full_points = 0;
//     full_sum = 0.;
//     full_squaresum = 0.;

//  //     addInitialParameter( "average", 5.2, 0.1 );
//  //     addInitialParameter( "sincomp", 0., 0.1 );
//  //     addInitialParameter( "coscomp", 0., 0.1 );
//  }

//  plotFitFcn::~plotFitFcn()
//  { ; }

//  double plotFitFcn::iterate( double* values )
//  {
//     double average = values[ 0 ];
//     double sincomp = values[ 1 ];
//     double coscomp = values[ 2 ];

//     double chi2 = 0.;

//     for ( int i = 0;  i < DRStereoAlignment::phi0bins;  i++ )
//     {
//        double phi0 = phi0frombin( i );
//        double func = average + sincomp * sin( phi0 ) + coscomp * cos( phi0 );
//        chi2 += sqr( func - means[ i ] ) / sqr( errors[ i ] );
//     }

//     return chi2;
//  }

//  void plotFitFcn::include_plot( double plot, double phi0 )
//  {
//     if ( plot < 0.  ||  plot > 7. )
//        return;

//     full_points++;
//     full_sum += plot;
//     full_squaresum += sqr( plot );

//     int phi0bin = int( floor( phi0 / (2*3.1415926) * DRStereoAlignment::phi0bins ) );
//     if ( phi0bin < 0  ||  phi0bin >= DRStereoAlignment::phi0bins )
//        return;

//     points[ phi0bin ]++;
//     sum[ phi0bin ] += plot;
//     squaresum[ phi0bin ] += sqr( plot );
//  }

//  void plotFitFcn::calculate_hist()
//  {
//     if ( full_points != 0 )
//     {
//        full_mean = full_sum / full_points;
//        full_error = sqrt( full_squaresum / full_points
//  			 - sqr( full_sum / full_points ) );
//     }
//     else
//        full_mean = full_error = 0.;

//     for ( int i = 0;  i < DRStereoAlignment::phi0bins;  i++ )
//        if ( points[ i ] != 0 )
//        {
//  	 means[ i ] = sum[ i ] / points[ i ];
//  	 errors[ i ] = sqrt( squaresum[ i ] / points[ i ]
//  			     - sqr( sum[ i ] / points[ i ] ) );
//        }
//        else
//        {
//  	 means[ i ] = 0;
//  	 errors[ i ] = 0;
//        }
//  }

//  void plotFitFcn::print()
//  {
//     cout << "phi0 bins:\n";
//     for ( int i = 0;  i < DRStereoAlignment::phi0bins;  i++ )
//        printf( "    %03d = %10.6g: %10.6g %10.6g\n",
//  	      i, phi0frombin( i ), means[ i ], errors[ i ] );
//     cout << endl;
//  }

//  void plotFitFcn::fourier_integrate(
//     double* average, double* sincomp, double* coscomp )
//  {
//     double fw_sum = 0.;

//     (* average) = 0.;
//     (* sincomp) = 0.;
//     (* coscomp) = 0.;

//     for ( int i = 0;  i < DRStereoAlignment::phi0bins;  i++ )
//     {
//        double fittingweight = 1. / sqr( errors[ i ] );
//        fw_sum += fittingweight;

//        double phi0 = phi0frombin( i );

//        (* average) += means[ i ]; // * fittingweight;
//        (* sincomp) += means[ i ] * sin( phi0 ); // * fittingweight;
//        (* coscomp) += means[ i ] * cos( phi0 ); // * fittingweight;
//     }
//     (* average) /= double( DRStereoAlignment::phi0bins );
//  //   (* average) /= fw_sum;

//     (* sincomp) /= double( DRStereoAlignment::phi0bins );
//  //   (* sincomp) /= fw_sum;
//     (* sincomp) /= 3.1415926;

//     (* coscomp) /= double( DRStereoAlignment::phi0bins );
//  //   (* coscomp) /= fw_sum;
//     (* coscomp) /= 3.1415926;
//  }

//  double plotFitFcn::cheezychi2()
//  {
//     double average_error = 0.;
//     double tmpN = 0;
//     for ( int i = 0;  i < DRStereoAlignment::phi0bins;  i++ )
//        if ( points[ i ] != 0 )
//        {
//  	 average_error += errors[ i ];
//  	 tmpN++;
//        }
//     average_error /= tmpN;

//     return ( full_error - average_error ) / average_error;
//  }

//  double plotFitFcn::phi0frombin( int bin )
//  {
//     return ( bin + 0.5 ) * (2*3.1415926) / DRStereoAlignment::phi0bins;
//  }
