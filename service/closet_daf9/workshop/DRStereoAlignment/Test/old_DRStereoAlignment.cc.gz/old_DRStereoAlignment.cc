// -*- C++ -*-
//
// Package:     <DRStereoAlignment>
// Module:      DRStereoAlignment
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Sat Jul 21 12:40:45 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "Experiment/report.h"
#include "DRStereoAlignment/DRStereoAlignment.h"
#include "DataHandler/Stream.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"
#include "FrameAccess/extract.h"
#include "DataHandler/Frame.h"

#include "Navigation/NavTrack.h"
#include "KinematicTrajectory/KTKinematicData.h"
#include "CLHEP/Vector/ThreeVector.h"
#include "JobControl/JobControl.h"
#include "ToolBox/HistogramPackage.h"
#include "MinuitInterface/MinuitInterface.h"

// STL classes
// You may have to uncomment some of these or other stl headers
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "DRStereoAlignment.DRStereoAlignment" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: fimodule.cc,v 1.2 2000/12/04 19:11:05 cdj Exp $";
static const char* const kTagString = "$Name: v03_06_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
DRStereoAlignment::DRStereoAlignment()
   : FrameIteratorModuleBase( "DRStereoAlignment", "This is my module" )
   //,m_header(0), m_headerHolder(&m_header)
{
   //You must set what streams you which to iterate over
   //  that is, what events should the Frames be stopped on
   iterateOver( Stream::kEvent );

}

// DRStereoAlignment::DRStereoAlignment( const DRStereoAlignment& rhs )
// {
//    // do actual copying here; if you implemented
//    // operator= correctly, you may be able to use just say      
//    *this = rhs;
// }

DRStereoAlignment::~DRStereoAlignment()
{
}

//
// assignment operators
//
// const DRStereoAlignment& DRStereoAlignment::operator=( const DRStereoAlignment& rhs )
// {
//   if( this != &rhs ) {
//      // do actual copying here, plus:
//      // "SuperClass"::operator=( rhs );
//   }
//
//   return *this;
// }

//
// member functions
//

//
// const member functions
//
void
DRStereoAlignment::iterate( const FIFrameIterator& iBegin,
			    const FIFrameIterator& iEnd )
{
   report( INFO, kFacilityString )
      << "starting iterator " << endl;

   JobControl* jc = JobControl::instance();
   HIHistoManager* hm = jc->histogramManagerP();

   HIHist1D* h_momentum = hm->histogram(
      100, "momentum", 100, 0., 15. );

//     HIHist2D* h_error_v_momentum = hm->histogram(
//        200, "momentum uncertainty VS momentum", 100, 0., 15., 100, 0., 0.01 );
   
   for( unsigned int timesIterated = 1;
	timesIterated <= 1;
	++timesIterated )
   {

      report( INFO, kFacilityString )
	 << "start iteration: " << timesIterated << endl;

      if ( iBegin == iEnd )
	 report( ERROR, kFacilityString )
	    << "iBegin == iEnd!" << endl;

//      momentumFitFcn momentumFit;

      unsigned int num_frames = 1;
      for( FIFrameIterator itFrame = iBegin;
	   itFrame != iEnd;
	   ++itFrame )
      {
	 if ( num_frames % 1000 == 0 )
	    report( INFO, kFacilityString )
	       << "number of frames: " << num_frames << endl;
	 if ( num_frames >= 10000 )
	    break;
	 num_frames++;

	 FATable< NavTrack > navtracks;
	 extract( itFrame->record( Stream::kEvent ), navtracks );
	 FATable< NavTrack >::const_iterator navtracks_iter;
	 FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
	 FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
	 for ( navtracks_iter = navtracks_begin;
	       navtracks_iter != navtracks_end;
	       navtracks_iter++ )
	 {
//  	    const int px = KTKinematicData::kPx;
//  	    const int py = KTKinematicData::kPy;
//  	    const int pz = KTKinematicData::kPz;

	    HepVector3D momentum = navtracks_iter->muonFit()->momentum();
//  	    HepSymMatrix errorMatrix = navtracks_iter->muonFit()->errorMatrix();
//  	    double momentum_error2 =
//  	       ( sqr( errorMatrix[ px ][ px ] ) * sqr( momentum.x() ) +
//  		 sqr( errorMatrix[ py ][ py ] ) * sqr( momentum.y() ) +
//  		 sqr( errorMatrix[ pz ][ pz ] ) * sqr( momentum.z() ) +
//  		 2 * sqr( errorMatrix[ px ][ py ] ) * momentum.x() * momentum.y() +
//  		 2 * sqr( errorMatrix[ py ][ pz ] ) * momentum.y() * momentum.z() +
//  		 2 * sqr( errorMatrix[ pz ][ px ] ) * momentum.z() * momentum.x()   )
//  	       / sqr( momentum.mag() );
	    double phi0 = navtracks_iter->muonHelix()->phi0();
	    
//  	    report( DEBUG, kFacilityString ) 
//  	       << "momentum error matrix is:\n"
//  	       << errorMatrix[ px ][ px ] << ", "
//  	       << errorMatrix[ px ][ py ] << ", "
//  	       << errorMatrix[ px ][ pz ] << "\n"
//  	       << errorMatrix[ py ][ px ] << ", "
//  	       << errorMatrix[ py ][ py ] << ", "
//  	       << errorMatrix[ py ][ pz ] << "\n"
//  	       << errorMatrix[ pz ][ px ] << ", "
//  	       << errorMatrix[ pz ][ py ] << ", "
//  	       << errorMatrix[ pz ][ pz ] << "\n" << endl;

//  	    report( DEBUG, kFacilityString )
//  	       << "momentum is " << momentum.mag()
//  	       << " +/- " << sqrt( abs( momentum_error2 ) ) << endl;

	    h_momentum->fill( momentum.mag() );
//	    h_error_v_momentum->fill( momentum.mag(), sqrt( abs( momentum_error2 ) ) );

//	    momentumFit.include_momentum( momentum.mag(), momentum_error, phi0 );

	 } // end loop over tracks
      } // end loop over frames

//      momentumFit.print();

//        MinuitInterface* mi = MinuitInterface::instance();
//        mi->loadFcn( mychi2 );
//        mi->setDiagLevel( MinuitInterface::kMax );
//        report( INFO, kFacilityString )
//  	 << "Successfully set up Minuit." << endl;

//        mi->runMigrad();
//        report( INFO, kFacilityString )
//  	 << "Successfully minimized." << endl;

//        mi->runMinos();
//        report( INFO, kFacilityString )
//  	 << "Successfully calculated the uncertainty." << endl;

//        MIStats stats( mi->minuitStats() );
//        HepMatrix covMatrix( mi->covarianceMatrix() );
//        report( INFO, kFacilityString )
//  	 << "Covariance Matrix:\n" << covMatrix << endl;

   } // end iterations
}

//
// static member functions
//

//  DRStereoAlignment::chi2Fcn::chi2Fcn()
//  {
//     m_momentum_list.clear();

//     addInitialParameter( "momentum", 5.2, 0.1 );
//  }

//  DRStereoAlignment::chi2Fcn::~chi2Fcn()
//  { ; }

//  double DRStereoAlignment::chi2Fcn::iterate( double* values )
//  {
//     double trial_momentum = values[ 0 ];
//     double chi2 = 0.;

//     vector< double >::const_iterator momentum_iter;
//     vector< double >::const_iterator momentum_begin = m_momentum_list.begin();
//     vector< double >::const_iterator momentum_end = m_momentum_list.end();
//     for ( momentum_iter = momentum_begin;
//  	 momentum_iter != momentum_end;
//  	 momentum_iter++ )
//     {
//        chi2 += sqr( trial_momentum - (* momentum_iter) );
//     } // end loop over momenta

//     return chi2;
//  }

//  void DRStereoAlignment::chi2Fcn::include_momentum( double momentum )
//  {
//     m_momentum_list.push_back( momentum );
//  }

//  void DRStereoAlignment::chi2Fcn::print_list()
//  {
//     cout << "momenta collected: ";

//     vector< double >::const_iterator momentum_iter;
//     vector< double >::const_iterator momentum_begin = m_momentum_list.begin();
//     vector< double >::const_iterator momentum_end = m_momentum_list.end();
//     for ( momentum_iter = momentum_begin;
//  	 momentum_iter != momentum_end;
//  	 momentum_iter++ )
//     {
//        cout << (* momentum_iter ) << ", ";
//     } // end loop over momenta

//     cout << endl;
//  }

