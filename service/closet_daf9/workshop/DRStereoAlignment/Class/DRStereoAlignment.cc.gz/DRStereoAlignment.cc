// -*- C++ -*-
//
// Package:     <DRStereoAlignment>
// Module:      DRStereoAlignment
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Sat Jul 21 12:40:45 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "Experiment/report.h"
#include "DRStereoAlignment/DRStereoAlignment.h"
#include "DataHandler/Stream.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"
#include "FrameAccess/extract.h"
#include "DataHandler/Frame.h"

#include "Navigation/NavTrack.h"
#include "KinematicTrajectory/KTKinematicData.h"
#include "CLHEP/Vector/ThreeVector.h"
#include "JobControl/JobControl.h"
#include "ToolBox/HistogramPackage.h"
#include "MinuitInterface/MinuitInterface.h"
#include "CleoDB/DBEventHeader.h"

#include <fstream.h>
#include <iostream.h>

// STL classes
// You may have to uncomment some of these or other stl headers
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "DRStereoAlignment.DRStereoAlignment" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: fimodule.cc,v 1.2 2000/12/04 19:11:05 cdj Exp $";
static const char* const kTagString = "$Name: v03_06_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
DRStereoAlignment::DRStereoAlignment()
   : FrameIteratorModuleBase( "DRStereoAlignment", "This is my module" )
   , m_geomalignment( new DBDRGeomAlignment[18], 18 )
   , m_geomalignmentHolder( &m_geomalignment )
{
   registerProxyFactory( Stream::kDRAlignment,
			 m_geomalignmentHolder.makeFactory(),
			 UsageTag() );

   //You must set what streams you which to iterate over
   //  that is, what events should the Frames be stopped on
   iterateOver( Stream::kEvent );

}

// DRStereoAlignment::DRStereoAlignment( const DRStereoAlignment& rhs )
// {
//    // do actual copying here; if you implemented
//    // operator= correctly, you may be able to use just say      
//    *this = rhs;
// }

DRStereoAlignment::~DRStereoAlignment()
{
}

//
// assignment operators
//
// const DRStereoAlignment& DRStereoAlignment::operator=( const DRStereoAlignment& rhs )
// {
//   if( this != &rhs ) {
//      // do actual copying here, plus:
//      // "SuperClass"::operator=( rhs );
//   }
//
//   return *this;
// }

//
// member functions
//

//
// const member functions
//
void
DRStereoAlignment::iterate( const FIFrameIterator& iBegin,
			    const FIFrameIterator& iEnd )
{
   ifstream starting_alignment(
      "/home/mccann/run/DRStereoAlignment/unaligned.drgeomalignment" );
   if ( ! m_geomalignment.readFromStream( starting_alignment ) )
      assert( 0 );

   JobControl* jc = JobControl::instance();
   HIHistoManager* hm = jc->histogramManagerP();

   alignmentFcn alignment( hm, &iBegin, &iEnd, &m_geomalignment );

   double values[3] = { m_geomalignment[0].get_rotZ(),
			m_geomalignment[0].get_deltaX(),
			m_geomalignment[0].get_deltaY() };
//     alignment.iterate( values );

//     values[ 0 ] += 0.1;
//     alignment.iterate( values );

//     values[ 0 ] -= 0.1;
//     values[ 1 ] += 0.01;
//     alignment.iterate( values );

//     values[ 1 ] -= 0.01;
//     values[ 2 ] += 0.01;
//     alignment.iterate( values );

    MinuitInterface* mi = MinuitInterface::instance();
    mi->loadFcn( alignment );
    mi->setDiagLevel( MinuitInterface::kNormal );
    mi->runMigrad();
   
//     double rotation = mi->parameter( 0 ).value();
//     double roterr = mi->parameter( 0 ).parabolicErr();
   
//     double transx = mi->parameter( 1 ).value();
//     double xerr = mi->parameter( 1 ).parabolicErr();
   
//     double transy = mi->parameter( 2 ).value();
//     double yerr = mi->parameter( 2 ).parabolicErr();
   
//     report( INFO, kFacilityString )
//        << "rotation = " << rotation << " +/- " << roterr
//        << ", transx = " << transx << " +/- " << xerr
//        << ", transy = " << transy << " +/- " << yerr << endl;
}

//
// static member functions
//

/////////////////////////////////////////////////////////////////

DRStereoAlignment::alignmentFcn::alignmentFcn(
   HIHistoManager* hm, const FIFrameIterator* begin, const FIFrameIterator* end,
   CLEOConstantsModifiable< DBDRGeomAlignment >* align ) :
   m_hm( hm ), m_begin( begin ), m_end( end ), m_align( align )
{
   addInitialParameter( "rotation", (* m_align)[0].get_rotZ(), 0.01 );
   addInitialParameter( "transx", (* m_align)[0].get_deltaX(), 0.001 );
   addInitialParameter( "transy", (* m_align)[0].get_deltaY(), 0.001 );
   
   for ( int i = 0;  i < 4;  i++ )
   {
      h_momentumvphi0s.push_back( m_hm->profile(
	 i * 100 + 1,
	 "momentum vs phi0", 79, 0., 2*3.1415926, 4., 6.,
	 HIHistProf::kErrorOnMean ) );
      h_posmomentumvphi0s.push_back( m_hm->profile(
	 i * 100 + 2,
	 "positive momentum vs phi0", 79, 0., 2*3.1415926, 4., 6.,
	 HIHistProf::kErrorOnMean ) );
      h_negmomentumvphi0s.push_back( m_hm->profile(
	 i * 100 + 3,
	 "negative momentum vs phi0", 79, 0., 2*3.1415926, 4., 6.,
	 HIHistProf::kErrorOnMean ) );
      h_posmomentumvcotThs.push_back( m_hm->profile(
	 i * 100 + 4,
	 "positive momentum vs cotTh", 100, -2.5, 2.5, 4., 6.,
	 HIHistProf::kErrorOnMean ) );
      h_negmomentumvcotThs.push_back( m_hm->profile(
	 i * 100 + 5,
	 "negative momentum vs cotTh", 100, -2.5, 2.5, 4., 6.,
	 HIHistProf::kErrorOnMean ) );
      h_eventmomentumvphi0s.push_back( m_hm->profile(
	 i * 100 + 6,
	 "event momentum vs phi0", 79, 0., 2*3.1415926, -0.5, 0.5,
	 HIHistProf::kErrorOnMean ) );
      h_eventmomentumxys.push_back( m_hm->histogram(
	 i * 100 + 7,
	 "event momentum Y vs X", 100, -0.5, 0.5, 100, -0.5, 0.5,
	 HIHistProf::kErrorOnMean ) );
      h_d0missvphi0s.push_back( m_hm->profile(
	 i * 100 + 8,
	 "d0miss vs phi0", 79, 0., 2*3.1415926, -0.0006, 0.0006,
	 HIHistProf::kErrorOnMean ) );
      h_z0missvphi0s.push_back( m_hm->profile(
	 i * 100 + 9,
	 "z0miss vs phi0", 79, 0., 2*3.1415926, -0.06, 0.06,
	 HIHistProf::kErrorOnMean ) );
   }
}

DRStereoAlignment::alignmentFcn::~alignmentFcn()
{ ; }

double DRStereoAlignment::alignmentFcn::iterate( double* values )
{
   static int iteration;
   int i = iteration;
   iteration++;

   double rotation = values[ 0 ];
   double transx = values[ 1 ];
   double transy = values[ 2 ];

   (* m_align)[0].set_rotZ( rotation );
   (* m_align)[0].set_deltaX( transx );
   (* m_align)[0].set_deltaY( transy );

   report( NOTICE, kFacilityString )
      << "trial " << iteration << " rotation = " << (* m_align)[0].get_rotZ()
      << ", transx = " << (* m_align)[0].get_deltaX()
      << " and tranxy = " << (* m_align)[0].get_deltaY() << endl;

   unsigned int num_frames = 1;
//   unsigned int good_events = 0;

   double pos_deviation = 0.;
   double norm_pos_deviation = 0.;
   unsigned int pos_tracks = 0;
   double neg_deviation = 0.;
   double norm_neg_deviation = 0.;
   unsigned int neg_tracks = 0;

   for( FIFrameIterator itFrame = (* m_begin);
	itFrame != (* m_end);
	++itFrame )
   {
      if ( num_frames % 1000 == 0 )
	 report( NOTICE, kFacilityString )
	    << num_frames << " events so far..." << endl;
      if ( num_frames >= 10000 )
	 break;
      num_frames++;

      FAItem< DBEventHeader > header;
      extract( itFrame->record( Stream::kEvent ), header );
      unsigned int run = header->run();
      unsigned int event = header->number();

      HepVector3D eventmomentum = HepVector3D( 0., 0., 0. );
//      HepSymMatrix posmomentum_error, negmomentum_error;
      double posd0, negd0, posz0, negz0, posphi0;
      DABoolean posseen = false;      
      DABoolean negseen = false;      

      FATable< NavTrack > navtracks;
      extract( itFrame->record( Stream::kEvent ), navtracks );
      FATable< NavTrack >::const_iterator navtracks_iter;
      FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
      FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
      for ( navtracks_iter = navtracks_begin;
	    navtracks_iter != navtracks_end;
	    navtracks_iter++ )
      {
	 HepVector3D momentum = navtracks_iter->muonFit()->momentum();
	 const HepVector3D crossing_angle = HepVector3D( -0.013, 0., 0. );
	 momentum = momentum - crossing_angle;

	 double phi0 = navtracks_iter->muonHelix()->phi0();

	 TRHelixFit loc_trackHelix = (* navtracks_iter->muonHelix() );
	 Meters movelength;
	 KTHelix::MoveStatus status =
	    loc_trackHelix.moveToReferencePoint( HepPoint3D( -0.00160, 0., 0. ), movelength );
	 if ( abs( loc_trackHelix.d0() ) > 0.0015  ||
	      abs( loc_trackHelix.z0() ) > 0.04       )
	    break;
    	 if ( momentum.mag() < 4.7  ||  momentum.mag() > 5.7 )
    	    break;

	 eventmomentum += momentum;
	 h_momentumvphi0s[ i ]->fill( phi0, momentum.mag() );

	 HepSymMatrix errorMatrix = navtracks_iter->muonFit()->errorMatrix();
 	 const int px = KTKinematicData::kPx;
 	 const int py = KTKinematicData::kPy;
 	 const int pz = KTKinematicData::kPz;
 	 double momentum_error2 =
 	    ( sqr( errorMatrix[ px ][ px ] ) * sqr( momentum.x() ) +
 	      sqr( errorMatrix[ py ][ py ] ) * sqr( momentum.y() ) +
 	      sqr( errorMatrix[ pz ][ pz ] ) * sqr( momentum.z() ) +
 	      2 * sqr( errorMatrix[ px ][ py ] ) * momentum.x() * momentum.y() +
 	      2 * sqr( errorMatrix[ py ][ pz ] ) * momentum.y() * momentum.z() +
 	      2 * sqr( errorMatrix[ pz ][ px ] ) * momentum.z() * momentum.x()   )
 	    / sqr( momentum.mag() );
	 double deviation2 = sqr( momentum.mag() - 5.25564526667 );
	 double norm_deviation2 = sqr( momentum.mag() - 5.25564526667 ) / momentum_error2;

	 if ( num_frames % 1000 == 0 )
	    report( NOTICE, kFacilityString )
	       << "momentum is " << momentum.mag() << " +/- "
	       << sqrt( momentum_error2 ) << endl;

	 if ( navtracks_iter->muonHelix()->curvature() > 0. )
	 {
	    posseen = true;
	    h_posmomentumvphi0s[ i ]->fill( phi0, momentum.mag() );
	    h_posmomentumvcotThs[ i ]->fill( navtracks_iter->muonHelix()->cotTheta(), momentum.mag() );
//	    posmomentum_error = navtracks_iter->muonFit()->errorMatrix();
	    posd0 = navtracks_iter->muonHelix()->d0();
	    posz0 = navtracks_iter->muonHelix()->z0();
	    posphi0 = phi0;

	    pos_deviation += deviation2;
	    norm_pos_deviation += norm_deviation2;
	    pos_tracks++;
	 }
	 else
	 {
	    negseen = true;
	    h_negmomentumvphi0s[ i ]->fill( phi0, momentum.mag() );
	    h_negmomentumvcotThs[ i ]->fill( navtracks_iter->muonHelix()->cotTheta(), momentum.mag() );
//	    negmomentum_error = navtracks_iter->muonFit()->errorMatrix();
	    negd0 = navtracks_iter->muonHelix()->d0();
	    negz0 = navtracks_iter->muonHelix()->z0();

	    neg_deviation += deviation2;
	    norm_neg_deviation += norm_deviation2;
	    neg_tracks++;
	 }
      } // end loop over tracks

      if ( navtracks.size() == 2  &&  posseen  &&  negseen )
      {
	 h_eventmomentumvphi0s[ i ]->fill( posphi0, eventmomentum.mag() );
	 h_eventmomentumxys[ i ]->fill( eventmomentum.x(), eventmomentum.y() );
	 h_d0missvphi0s[ i ]->fill( posphi0, posd0 + negd0 );
	 h_z0missvphi0s[ i ]->fill( posphi0, posz0 - negd0 );

//	 chi2 += sqr( eventmomentum.mag() );
//	 good_events++;
      }

   } // end loop over frames

   report( NOTICE, kFacilityString )
      << "Finished loop over events! pos deviation = " << pos_deviation
      << " / " << pos_tracks << " tracks and neg deviation = " << neg_deviation
      << " / " << neg_tracks << " tracks." << endl;

   report( NOTICE, kFacilityString )
      << "Norm pos deviation = "
      << norm_pos_deviation << " / " << pos_tracks << " tracks and norm neg deviation = "
      << norm_neg_deviation << " / " << neg_tracks << " tracks." << endl;
   
   report( NOTICE, kFacilityString )
      << "chi2 / dof = " << ( pos_deviation + neg_deviation ) << " / "
      << ( pos_tracks + neg_tracks ) << " = "
      << ( ( pos_deviation + neg_deviation ) / double( pos_tracks + neg_tracks ) )
      << endl;

   return ( ( pos_deviation + neg_deviation ) / double( pos_tracks + neg_tracks ) );
}

// protected against use

DRStereoAlignment::alignmentFcn::alignmentFcn()
{ ; }

