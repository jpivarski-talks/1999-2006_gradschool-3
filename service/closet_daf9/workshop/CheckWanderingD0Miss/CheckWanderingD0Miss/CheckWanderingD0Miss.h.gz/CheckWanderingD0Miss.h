// -*- C++ -*-
#if !defined(CHECKWANDERINGD0MISS_CHECKWANDERINGD0MISS_H)
#define CHECKWANDERINGD0MISS_CHECKWANDERINGD0MISS_H
//
// Package:     <CheckWanderingD0Miss>
// Module:      CheckWanderingD0Miss
//
/**\class CheckWanderingD0Miss CheckWanderingD0Miss.h CheckWanderingD0Miss/CheckWanderingD0Miss.h
 
 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Mon Feb 26 17:45:23 EST 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "Processor/Processor.h"
#include "HistogramInterface/HistogramPackage.h"
#include "Navigation/NavTrack.h"
#include "HistogramInterface/HIHistProf.h"
#include "CLHEP/Vector/ThreeVector.h"

// forward declarations

class CheckWanderingD0Miss : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------

      // ------------ Constructors and destructor ----------------
      CheckWanderingD0Miss( void );                      // anal1 
      virtual ~CheckWanderingD0Miss();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( HIHistoManager& );                  

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      //virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      //virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      CheckWanderingD0Miss( const CheckWanderingD0Miss& );

      // ------------ assignment operator(s) ---------------------
      const CheckWanderingD0Miss& operator=( const CheckWanderingD0Miss& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (CheckWanderingD0Miss::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      // ------------ private const member functions -------------

      // ------------ data members -------------------------------

      HIHist1D* m_d0;
      HIHist1D* m_d0err;
      HIHist1D* m_d0miss;
      HIHist1D* m_d0norm_miss;
      HIHistProf* m_d0missVphi;
      HIHistProf* m_d0norm_missVphi;
      HIHistProf* m_d0missVposPhi;
      HIHistProf* m_d0norm_missVposPhi;

      HIHist1D* m_z0;
      HIHist1D* m_z0err;
      HIHist1D* m_z0miss;
      HIHist1D* m_z0norm_miss;
      HIHistProf* m_z0missVphi;
      HIHistProf* m_z0norm_missVphi;
      HIHistProf* m_z0missVposPhi;
      HIHistProf* m_z0norm_missVposPhi;

      // ------------ static data members ------------------------

};

// inline function definitions

#endif /* CHECKWANDERINGD0MISS_CHECKWANDERINGD0MISS_H */
