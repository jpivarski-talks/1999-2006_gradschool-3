// -*- C++ -*-
//
// Package:     CheckWanderingD0Miss
// Module:      CheckWanderingD0Miss
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Mon Feb 26 17:45:23 EST 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "CheckWanderingD0Miss/CheckWanderingD0Miss.h"
#include "Experiment/report.h"
#include "Experiment/units.h"  // for converting to/from standard CLEO units

#include "DataHandler/Record.h"
#include "DataHandler/Frame.h"
#include "FrameAccess/extract.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"


// STL classes
// You may have to uncomment some of these or other stl headers 
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "Processor.CheckWanderingD0Miss" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: processor.cc,v 1.17 2000/12/04 19:11:11 cdj Exp $";
static const char* const kTagString = "$Name: v03_06_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
CheckWanderingD0Miss::CheckWanderingD0Miss( void )               // anal1
   : Processor( "CheckWanderingD0Miss" )
{
   report( DEBUG, kFacilityString ) << "here in ctor()" << endl;

   // ---- bind a method to a stream -----
   // These lines ARE VERY IMPORTANT! If you don't bind the 
   // code you've just written (the "action") to a stream, 
   // your code won't get executed!

   bind( &CheckWanderingD0Miss::event,    Stream::kEvent );
   //bind( &CheckWanderingD0Miss::beginRun, Stream::kBeginRun );
   //bind( &CheckWanderingD0Miss::endRun,   Stream::kEndRun );

   // do anything here that needs to be done at creation time
   // (e.g. allocate resources etc.)

}

CheckWanderingD0Miss::~CheckWanderingD0Miss()                    // anal5
{
   report( DEBUG, kFacilityString ) << "here in dtor()" << endl;
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}

//
// member functions
//

// ------------ methods for beginning/end "Interactive" ------------
// --------------------------- init method -------------------------
void
CheckWanderingD0Miss::init( void )          // anal1 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in init()" << endl;

   // do any initialization here based on Parameter Input by User
   // (e.g. run expensive algorithms that are based on parameters
   //  specified by user at run-time)

}

// -------------------- terminate method ----------------------------
void
CheckWanderingD0Miss::terminate( void )     // anal5 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in terminate()" << endl;

   // do anything here BEFORE New Parameter Change
   // (e.g. write out result based on parameters from user-input)
 
}

// ---------------- standard place to book histograms ---------------
void
CheckWanderingD0Miss::hist_book( HIHistoManager& iHistoManager )
{
   report( DEBUG, kFacilityString ) << "here in hist_book()" << endl;

   // book your histograms here

   m_d0 = iHistoManager.histogram(
      110, "D0", 100, -0.2E-2, 0.2E-2 );
   m_d0err = iHistoManager.histogram(
      120, "D0 error (squared)", 100, 0, 0.35E-7 );
   m_d0miss = iHistoManager.histogram(
      130, "D0 miss", 100, -0.15E-2, 0.15E-2 );
   m_d0norm_miss = iHistoManager.histogram(
      140, "D0 normalized miss", 100, -3.5, 3.5 );
   m_d0missVphi = iHistoManager.profile(
      150, "D0miss vs phi0?1!+phi0?2!", 157, 3.14159, 9.424778, -0.15E-2, 0.15E-2,
      HIHistProf::kErrorOnMean );
   m_d0norm_missVphi = iHistoManager.profile(
      160, "D0 normalized miss vs phi0?1!+phi0?2!", 157, 3.14159, 9.424778,
      -3.5, 3.5, HIHistProf::kErrorOnMean );
   m_d0missVposPhi = iHistoManager.profile(
      170, "d0?track 1! + d0?track 2! vs phi0?positive track!",
      157, 0., 2.*3.1415926, -0.15E-2, 0.15E-2, HIHistProf::kErrorOnMean );
   m_d0norm_missVposPhi = iHistoManager.profile(
      180, "Normalized D0Miss vs phi0?positive track!",
      157, 0., 2.*3.1415926, -3.5, 3.5, HIHistProf::kErrorOnMean );

   m_z0 = iHistoManager.histogram(
      210, "Z0", 100, -0.04, 0.04 );
   m_z0err = iHistoManager.histogram(
      220, "Z0 error (squared)", 100, 0, 0.35E-4 );
   m_z0miss = iHistoManager.histogram(
      230, "Z0 miss", 100, -0.025, 0.025 );
   m_z0norm_miss = iHistoManager.histogram(
      240, "Z0 normalized miss", 100, -3.5, 3.5 );
   m_z0missVphi = iHistoManager.profile(
      250, "Z0miss vs phi0?1!+phi0?2!",
      157, 3.14159, 9.424778, -0.025, 0.025, HIHistProf::kErrorOnMean );
   m_z0norm_missVphi = iHistoManager.profile(
      260, "Z0 normalized miss vs phi0?1!+phi0?2!",
      157, 3.14159, 9.424778, -3.5, 3.5, HIHistProf::kErrorOnMean );
   m_z0missVposPhi = iHistoManager.profile(
      270, "z0?track 1! - z0?track 2! vs phi0?positive track!",
      157, 0., 2.*3.1415926, -0.025, 0.025, HIHistProf::kErrorOnMean );
   m_z0norm_missVposPhi = iHistoManager.profile(
      280, "Normalized Z0Miss vs phi0?positive track!",
      157, 0., 2.*3.1415926, -3.5, 3.5, HIHistProf::kErrorOnMean );

}

// --------------------- methods bound to streams -------------------
ActionBase::ActionResult
CheckWanderingD0Miss::event( Frame& iFrame )          // anal3 equiv.
{
   report( DEBUG, kFacilityString ) << "here in event()" << endl;

   FATable< NavTrack > navtracks;
   extract( iFrame.record( Stream::kEvent ), navtracks );
   FATable< NavTrack >::const_iterator navtracks_iterator;
   FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
   FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
   report( DEBUG, kFacilityString ) << "event: got NavTracks" << endl;

   DBCandidate::Hypo particle = DBCandidate::kElectron;

   double event_d0[2];
   double event_d0_err[2];
   double event_z0[2];
   double event_z0_err[2];
   double event_phi0[2];
   bool event_pos[2];
   HepVector3D event_momentum[2];
   int whichTrack = 0;
   int passedTrackQualityCuts = 0;

   // loop over bhabhas
   for( navtracks_iterator = navtracks_begin;
        navtracks_iterator != navtracks_end;
        navtracks_iterator++ )
   {
      // Get the Kalman-fitted track
      FAItem< TDKinematicFit > trackFit =
	 navtracks_iterator->kinematicFit( particle );
      if ( trackFit == NULL )
      {
	 report( EMERGENCY, kFacilityString )
	    << "kinematicFit is missing from the NavTrack!" << endl;
	 return ActionBase::kFailed;
      }

      // get the Kalman-fitted helix
      FAItem< TRHelixFit > trackHelix =
         navtracks_iterator->helixFit( particle );
      if ( trackHelix == NULL )
      {
         report( EMERGENCY, kFacilityString )
            << "helixFit is missing from the NavTrack!" << endl;
         return ActionBase::kFailed;
      }
      TRHelixFit loc_trackHelix = (* trackHelix );
   
      // Move the track's reference point to the origin so that d0 and
      // z0 will be right (later, this will be to the beamspot)
      report( INFO, kFacilityString )
         << "Attempting to move helix." << endl;
      Meters movelength;
      KTHelix::MoveStatus status =
         loc_trackHelix.moveToReferencePoint( HepPoint3D( 0., 0., 0. ),
                                              movelength );
      if ( status != KTMoveControl::kMoveOK )
      {
         report( EMERGENCY, kFacilityString )
            << "trackHelix.moveToReferencePoint returned "
            << status << " (not kMoveOK, as it should)." << endl;
         return ActionBase::kFailed;
      }
      report( INFO, kFacilityString )
         << "Moved helix sucessfully." << endl;
      
      // Get its quality object
      FAItem< TRTrackFitQuality > trackQuality =
         navtracks_iterator->quality( particle );
      if ( trackQuality == NULL )
      {
         report( EMERGENCY, kFacilityString )
            << "quality object is missing from the NavTrack!" << endl;
         return ActionBase::kFailed;
      }

      // some cut variables
      HepVector3D momentum = event_momentum[ whichTrack ] = trackFit->momentum();
      double dof = double( trackQuality->degreesOfFreedom() );

      // the cuts (contrapositive of my other producers)
      if ( (! trackQuality->fitAbort() )                               &&
	   momentum.mag() > 0.1                                        &&
	   momentum.mag() < 7.0                                        &&
	   abs( loc_trackHelix.cotTheta() ) < 1.25                     &&
	   dof > 0.                                                    &&
	   trackQuality->chiSquare() > 0.                              &&
	   ( trackQuality->chiSquare() / dof ) < 6.                    &&
	   ( double( trackQuality->numberHits() )
	     / double( trackQuality->numberHitsExpected() ) ) > 0.5    &&
	   abs( loc_trackHelix.d0() ) < 0.2                            &&
	   abs( loc_trackHelix.z0() ) < 0.15                           &&
	   sqrt( abs( loc_trackHelix.errorMatrix()(
	      KTHelix::kCotTheta, KTHelix::kCotTheta ) ) ) < 0.5       &&
	   sqrt( abs( loc_trackHelix.errorMatrix()(
	      KTHelix::kZ0, KTHelix::kZ0 ) ) ) < 0.25                      )
      {
	 report( INFO, kFacilityString ) << "   Track passed cuts!" << endl;
	 passedTrackQualityCuts++;
	 
	 m_d0->fill( event_d0[ whichTrack ] =
		     loc_trackHelix.d0() );
	 m_d0err->fill( event_d0_err[ whichTrack ] =
			loc_trackHelix.errorMatrix()( KTHelix::kD0, KTHelix::kD0 ) );
	 
	 m_z0->fill( event_z0[ whichTrack ] =
		     loc_trackHelix.z0() );
	 m_z0err->fill( event_z0_err[ whichTrack ] =
			loc_trackHelix.errorMatrix()( KTHelix::kZ0, KTHelix::kZ0 ) );
	 
	 event_phi0[ whichTrack ] = loc_trackHelix.phi0();
	 if ( loc_trackHelix.curvature() > 0. )
	    event_pos[ whichTrack ] = true;
	 else
	    event_pos[ whichTrack ] = false;
	 
	 whichTrack++;
      } // end track passed cuts
      else
      {
	 report( INFO, kFacilityString ) << "   Track failed to pass cuts!" << endl;
      } // end track didn't pass cuts
      
   } // end foreach track

   HepVector3D pdiff = ( event_momentum[0] + event_momentum[1] );

   if ( passedTrackQualityCuts == 2                   &&
	( (  event_pos[0] && !event_pos[1] ) ||
	  ( !event_pos[0] &&  event_pos[1] )    )     &&
	pdiff.perp() < 0.025                              )
   {
      double phi = event_phi0[0] + event_phi0[1];
      double posPhi;
      if ( event_pos[0] )
	 posPhi = event_phi0[0];
      else
	 posPhi = event_phi0[1];

      double d0miss = event_d0[0] + event_d0[1];
      m_d0miss->fill( d0miss );
      m_d0missVphi->fill( phi, d0miss );
      m_d0missVposPhi->fill( posPhi, d0miss );

      if ( event_d0_err[0] > 0.  &&  event_d0_err[1] > 0. )
      {
	 double d0norm_miss = ( ( event_d0[0] + event_d0[1] )
				/ sqrt( event_d0_err[0] + event_d0_err[1] ) );
	 m_d0norm_miss->fill( d0norm_miss );
	 m_d0norm_missVphi->fill( phi, d0norm_miss );
	 m_d0norm_missVposPhi->fill( posPhi, d0norm_miss );
      }

      double z0miss = event_z0[0] - event_z0[1];
      m_z0miss->fill( z0miss );
      m_z0missVphi->fill( phi, z0miss );
      m_z0missVposPhi->fill( posPhi, z0miss );

      if ( event_z0_err[0] > 0.  &&  event_z0_err[1] > 0. )
      {
	 double z0norm_miss = ( ( event_z0[0] - event_z0[1] )
				/ sqrt( event_z0_err[0] + event_z0_err[1] ) );
	 m_z0norm_miss->fill( z0norm_miss );
	 m_z0norm_missVphi->fill( phi, z0norm_miss );
	 m_z0norm_missVposPhi->fill( posPhi, z0norm_miss );
      }   
   } // endif we have two good tracks

   return ActionBase::kPassed;
}

/*
ActionBase::ActionResult
CheckWanderingD0Miss::beginRun( Frame& iFrame )       // anal2 equiv.
{
   report( DEBUG, kFacilityString ) << "here in beginRun()" << endl;

   return ActionBase::kPassed;
}
*/

/*
ActionBase::ActionResult
CheckWanderingD0Miss::endRun( Frame& iFrame )         // anal4 equiv.
{
   report( DEBUG, kFacilityString ) << "here in endRun()" << endl;

   return ActionBase::kPassed;
}
*/

//
// const member functions
//

//
// static member functions
//
