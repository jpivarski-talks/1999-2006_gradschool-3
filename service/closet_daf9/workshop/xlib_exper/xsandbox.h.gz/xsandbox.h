#include <stdio.h>
#include <math.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <map>

typedef char SBColor;
// typedef bool BoolFunc( SBCoord coord );

class SBCoord;
class SBCoord
{
   public:
      SBCoord();
      SBCoord( int _x, int _y );
      void operator=( SBCoord const &other )
      { X = other.x(); Y = other.y(); }

      int x() const { return X; }
      int y() const { return Y; }
      int nx() const { return ( X + 1 ); }
      int ny() const { return ( Y + 1 ); }
      bool within( SBCoord upperLeft, SBCoord lowerRight ) const
      { return ( X >= upperLeft.x()   &&  Y >= upperLeft.y()  &&
		 X <= lowerRight.x()  &&  Y <= lowerRight.y()    ); }
      bool within( SBCoord lowerRight ) const
      { return ( X <= lowerRight.x()  &&  Y <= lowerRight.y() ); }
      int area() const
      { return ( ( X + 1 ) * ( Y + 1 ) ); }
   private:
      int X;
      int Y;
};

class SBRegion
{
   public:
      SBRegion( SBCoord coord );
      void setSize( SBCoord newsize );
      void clear();
      void set( SBCoord coord, bool value );
      void on( SBCoord coord )
      { set( coord, true ); }
      void off( SBCoord coord )
      { set( coord, false ); }
//       void expand( BoolFunc& criteria );

      bool get( SBCoord coord ) const
      { return val[ coord.y() ][ coord.x() ]; }
   private:
      bool** val;
      SBCoord size;
};

class SBWindow
{
   public:
      SBWindow( SBCoord _size, char* _display );
      bool handleEvent();
      void setSize( SBCoord newsize );
      void clear();

      // inline functions for less overhead
      void set( SBCoord coord, SBColor color )
      { if ( coord.within( size ) )
	 XPutPixel( image, coord.x(), coord.y(), long( color ) ); }
      void flush()
      { if ( exposeCalled ) handleExpose(); }

      SBCoord getSize() const;
   private:
      void init();
      void handleExpose();

      // set by constructor
      bool           exposeCalled;  // if handleExpose() was ever called
      SBCoord        size;
      Display*       display;

      // set by init()
      GC             gc;
      int            screen;
      Window         main, root;
      unsigned long  white_pixel, black_pixel;
      XImage*        image;
      SBColor*       data;
      SBCoord        imageSize;
};
