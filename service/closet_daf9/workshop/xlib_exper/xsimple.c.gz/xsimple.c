/* 
 * xsimple : Affiche une chaine dans une fenetre X...
 * http://echo-linux.alienor.fr/articles/xlib/xlib.html
 * http://www.the-labs.com/X11/XLib-Manual/
 * http://users.actcom.co.il/~choo/lupg/tutorials/xlib-programming/xlib-programming.html
 */

#include <stdio.h>
#include <X11/Xlib.h>

GC      gc;
Display *display;
int     screen;
Window  win, root;
unsigned long white_pixel, black_pixel;
/* Pixmap  pix; */
XImage *image;
char    data[1024];

/*
 * fonction associee a l'evenement EXPOSE 
 */

void expose ()
{
  /* XDrawString (display, win, gc, 10, 30, "Hello, world !", 14); */
  int i, j;

  XPutImage( display, win, gc, image, 0, 0, 10, 10, 32, 32 );

  for( i = 0;  i < 32;  i++ )
    for( j = 0;  j < 32;  j++ )
      XPutPixel( image, i, j, ( i * j ) % 256 );

/*   XAddPixel( image, 1 ); */

  printf( "pixel color == %d\n", XGetPixel( image, 0, 0 ) );
  for( i = 0;  i < 32;  i++ )
    {
      for( j = 0;  j < 32;  j++ )
	printf( "%03d ", data[ ((i*32)+j) ] );
      printf( "\n" );
    }
}

/*
 * programme principal
 */

main(ac, av)
  int ac;
char **av;
{
  char *dpyn = NULL;
  int i;

  /* selection du display en ligne */
  if (ac == 3) {
    if (strcmp (&av[1][1], "display") == 0) {
      dpyn = av[2];
    }
    else {
      fprintf (stderr, "Usage:    xsimple [-display display_name]\n");
      exit (1);
    }
  }

  if ((display = XOpenDisplay (dpyn)) == NULL) {
    fprintf (stderr, "Can't open Display\n");
    exit (1);
  }

  gc = DefaultGC (display, screen);
  screen = DefaultScreen (display);
  root = RootWindow (display, screen);
  white_pixel = WhitePixel (display, screen);
  black_pixel = BlackPixel (display, screen);


  win = XCreateSimpleWindow (display, root, 0, 0, 100, 90, 2,
			     black_pixel, white_pixel);

  XSelectInput (display, win, ( ExposureMask |
				ButtonPressMask |
				ButtonMotionMask |
				KeyPressMask 
				/* Button1MotionMask |
				 * Button2MotionMask |
				 * Button3MotionMask  */ ) );

  XStoreName (display, win, "xsimple");
  XMapWindow (display, win);

  for( i = 0;  i < 1024;  i++ )
    data[ i ] = 0x00;

  image = XCreateImage( display, DefaultVisual( display, 0 ),
			8, XYPixmap, 0, data,
			32, 32, 8, 0 );
  XInitImage( image );

  /*  pix = XCreatePixmap( display, win, 100, 100, 8 ); */

  for (;;) {
    XEvent ev;
    
    XNextEvent (display, &ev);

    switch (ev.type)
      {
      case Expose:
	expose();
	break;
	
      case KeyPress:
	printf( "le clef %d = %c!\n",
		ev.xkey.keycode, ev.xkey.keycode );
	expose();
	break;
	
      case MotionNotify:
	if ( ev.xmotion.state & Button1Mask )
	  printf( "Button1 " );
	if ( ev.xmotion.state & Button2Mask )
	  printf( "Button2 " );
	if ( ev.xmotion.state & Button3Mask )
	  printf( "Button3 " );
	if ( ev.xmotion.state & ShiftMask )
	  printf( "Shift " );
	if ( ev.xmotion.state & ControlMask )
	  printf( "Control " );

	printf( "(%d, %d)!\n", ev.xmotion.x, ev.xmotion.y );
	break;
	
      default:
	break;
      }

  }
}

