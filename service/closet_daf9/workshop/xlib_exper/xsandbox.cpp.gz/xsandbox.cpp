#include "xsandbox.h"

/////////////////////////////////////////////////// SBCoord

SBCoord::SBCoord()
{
   X = 0;    Y = 0;
}

SBCoord::SBCoord( int _x, int _y )
{
   X = _x;   Y = _y;
}

/////////////////////////////////////////////////// SBRegion

SBRegion::SBRegion( SBCoord _size )
{
   int row, col;
   size = _size;

   val = (bool**)malloc( sizeof(bool*) * size.ny() );
   if ( val == NULL )
   {
      fprintf( stderr,
	       "Not enough memory to create region of size %d, %d.\n",
	       size.x(), size.y() );
      exit( 1 );
   }

   for( row = 0;  row < size.ny();  row++ )
   {
      val[ row ] = (bool*)malloc( sizeof(bool) * size.nx() );
      if ( val[ row ] == NULL )
      {
	 fprintf( stderr,
	     "Not enough memory to create region of size %d, %d.\n",
		  size.x(), size.y() );
	 exit( 1 );
      }

      for( col = 0;  col < size.nx(); col++ )
	 val[ row ][ col ] = false;
   }
}

void SBRegion::setSize( SBCoord newsize )
{
   int row, col;

   bool** tmp = (bool**)malloc( sizeof(bool*) * newsize.ny() );
   if ( tmp == NULL )
   {
      fprintf( stderr,
	       "Not enough memory to resize region to %d, %d.\n",
	       newsize.x(), newsize.y() );
      exit( 1 );
   }

   for( row = 0;  row < newsize.ny();  row++ )
   {
      tmp[ row ] = (bool*)malloc( sizeof(bool) * newsize.nx() );
      if ( tmp[ row ] == NULL )
      {
	 fprintf( stderr,
	     "Not enough memory to resize region to %d, %d.\n",
		  size.x(), size.y() );
	 exit( 1 );
      }

      for( col = 0;  col < newsize.nx(); col++ )
      {
	 SBCoord where( row, col );
	 if ( where.within( size ) )
	    tmp[ row ][ col ] = val[ row ][ col ];
	 else
	    tmp[ row ][ col ] = false;
      }
   }

   for( row = 0;  row < size.ny();  row++ )
      free( val[ row ] );
   free( val );

   val = tmp;
   size = newsize;
}

void SBRegion::clear()
{
   int row, col;
   for( row = 0;  row < size.ny();  row++ )
      for( col = 0;  col < size.nx(); col++ )
	 val[ row ][ col ] = false;
}

// set will do more (edge detection, etc) so don't inline it!
void SBRegion::set( SBCoord coord, bool value )
{
   if ( coord.within( size ) )
      val[ coord.y() ][ coord.x() ] = value;
}

/////////////////////////////////////////////////// SBWindow

SBWindow::SBWindow( SBCoord _size, char* _display )
{
   bool useDefault = ( _display == NULL );

   exposeCalled = false;
   size = _size;
   display = XOpenDisplay( _display );
   if ( display == NULL )
   {
      if ( useDefault )
	 fprintf( stderr,
		  "Couldn't open display. Check $DISPLAY variable.\n" );
      else
	 fprintf( stderr,
		  "Couldn't open display \"%s\"\n", _display );
      exit( 1 );
   }

   init();
}

bool SBWindow::handleEvent()
{
   XEvent event;
   XNextEvent( display, &event );

   switch ( event.type )
   {
      case Expose:
	 handleExpose();
	 break;

//       case ConfigureNotify:
// 	 printf( "Resize to (%d, %d)\n",
// 		 event.xconfigure.width, event.xconfigure.height );
// 	 break;

      case ButtonPress:
	 printf( "Click " );
	 if ( event.xbutton.button == Button1 )
	    printf( "Button1 " );
	 if ( event.xbutton.button == Button2 )
	    printf( "Button2 " );
	 if ( event.xbutton.button == Button3 )
	    printf( "Button3 " );
	 if ( event.xmotion.state & ShiftMask )
	    printf( "Shift " );
	 if ( event.xmotion.state & ControlMask )
	    printf( "Control " );
	 printf( "(%d, %d)\n", event.xbutton.x, event.xbutton.y );
	 break;
	
      case MotionNotify:
         printf( "Drag " );
	 if ( event.xmotion.state & Button1Mask )
	    printf( "Button1 " );
	 if ( event.xmotion.state & Button2Mask )
	    printf( "Button2 " );
	 if ( event.xmotion.state & Button3Mask )
	    printf( "Button3 " );
	 if ( event.xmotion.state & ShiftMask )
	    printf( "Shift " );
	 if ( event.xmotion.state & ControlMask )
	    printf( "Control " );
	 
	 printf( "(%d, %d)\n", event.xmotion.x, event.xmotion.y );
	 break;

      case KeyPress:
//	 printf( "Key %d = %c\n", event.xkey.keycode );
	 if ( event.xkey.keycode == 21 )
	    return false;
	 break;
	
      default:
	 break;
   }
   return true;
}

void SBWindow::setSize( SBCoord newsize )
{
   free( data );
   size = newsize;

   SBColor* data = (SBColor*)malloc( sizeof(SBColor) * size.area() );
   if ( data == NULL )
   {
      fprintf( stderr,
	 "Not enough memory to resize windowbuffer to %d, %d.\n",
	       size.x(), size.y() );
      exit( 1 );
   }

   // this is optional and may later be removed
   clear();
}

void SBWindow::clear()
{
   int row, col;
   for( row = 0;  row < imageSize.ny();  row++ )
      for( col = 0;  col < imageSize.nx();  col++ )
//       {
// 	 printf( "%d, %d\n", row, col );
 	 XPutPixel( image, col, row, 13 );
//       }
}

void SBWindow::init()
{
   screen = DefaultScreen( display );
   gc = DefaultGC( display, screen );
   root = RootWindow( display, screen );
   white_pixel = WhitePixel( display, screen );
   black_pixel = BlackPixel( display, screen );

   main = XCreateSimpleWindow( display, root, 0, 0,
			       size.nx(), size.ny(), 2,
			       black_pixel, white_pixel );

   const long eventMask =
      ( ExposureMask | // StructureNotifyMask |
	ButtonPressMask | ButtonMotionMask | KeyPressMask );

   XSelectInput( display, main, eventMask );

   XStoreName( display, main, "xsandbox" );
   XMapWindow( display, main );

   imageSize = size;  // Earlier, I had problems...
   data = (SBColor*)malloc( sizeof(SBColor) * imageSize.area() );
   if ( data == NULL )
   {
      fprintf( stderr,
	 "Not enough memory to create windowbuffer of size %d, %d.\n",
	       imageSize.x(), imageSize.y() );
      exit( 1 );
   }
   image = XCreateImage( display, DefaultVisual( display, 0 ),
			 8, ZPixmap, 0, data,
			 imageSize.nx(), imageSize.ny(), 32,
			 ( sizeof(SBColor) * imageSize.nx() ) );
   XInitImage( image );

   // this is optional and may later be removed
   clear();
}

void SBWindow::handleExpose()
{
   exposeCalled = true;
   XPutImage( display, main, gc, image, 0, 0, 0, 0,
	      imageSize.nx(), imageSize.ny() );
   XFlush( display );
}

/////////////////////////////////////////////////// main

int main( int argc, char** argv )
{
   char* display = NULL;
   if ( argc == 3 )
   {
      if ( !strcmp( argv[1], "-display" ) )
	 display = argv[2];
      else
      {
	 fprintf( stderr,
		  "Usage:    xsandbox [-display display_name]\n" );
	 exit (1);
      }
   }

   SBCoord initial_size( 400, 300 );
   SBWindow sandbox_window( initial_size, display );
      
   while ( sandbox_window.handleEvent() );
}

