#include "interpreter.h"

extern vector< string > tabbing_names;

///////////////////////////////////////////////////// ObjectType

ObjectType::ObjectType( ObjectType& other )
{
   base = other.getBase();
   ObjectType* otherNext = other.getNext();
   if ( otherNext )
      next = new ObjectType( (* otherNext) );
   else
      next = NULL;
   constant = other.isConstant();
}

ObjectType::ObjectType( ObjectType::Base _base, bool _constant )
{
   base = _base;
   next = NULL;
   constant = _constant;
}

ObjectType::ObjectType( char* name, bool _constant )
{
   int pos = 0;
   setType( name, pos );
   constant = _constant;
}

ObjectType::ObjectType( char* name, int& pos, bool _constant )
{
   constant = _constant;  // important that this is set first!
   setType( name, pos );
}

ObjectType::Base ObjectType::getBase()
{
   return base;
}

ObjectType* ObjectType::getNext()
{
   return next;
}

bool ObjectType::isConstant()
{
   return constant;
}

bool ObjectType::isSame( ObjectType& other )
{
   if ( other.getBase() != base )
      return false;

   switch ( base )
   {
      case kUndetermined:
	 return false;

      case kBoolean:
      case kInteger:
      case kReal:
      case kString:
      case kComplex:
      case kUncertain:
      case kDirectory:
      case kHistogram:
      case k2DHistogram:
      case kProfileHistogram:
      case kNtuple:
      case kColumnNtuple:
	 return true;

      case kVectorOf:
      case kTreeOf:
      case kMapOf:
	 assert( next );
	 return next->isSame( (* other.getNext()) );
   }
}

void ObjectType::setType( char* name, int& pos )
{
   char cur = name[ pos ];
   switch ( cur )
   {
      case 'b': case 'B':
	 pos++;
	 base = kBoolean;
	 next = NULL;
	 break;

      case 'i': case 'I':
	 pos++;
	 base = kInteger;
	 next = NULL;
	 break;

      case 'r': case 'R':
	 pos++;
	 base = kReal;
	 next = NULL;
	 break;

      case 's': case 'S':
	 pos++;
	 base = kString;
	 next = NULL;
	 break;

      case 'c': case 'C':
	 pos++;
	 base = kComplex;
	 next = NULL;
	 break;

      case 'u': case 'U':
	 pos++;
	 base = kUndetermined;
	 next = NULL;
	 break;

      case 'd': case 'D':
	 pos++;
	 base = kDirectory;
	 next = NULL;
	 break;

      case 'h': case 'H':
	 pos++;
	 cur = name[ pos ];
	 switch ( cur )
	 {
	    case '_':
	       base = kHistogram;
	       break;

	    case '2':
	       pos++;
	       base = k2DHistogram;
	       break;

	    case 'p': case 'P':
	       pos++;
	       base = kProfileHistogram;
	       break;
	 }
	 next = NULL;
	 break;

      case 'n': case 'N':
	 pos++;
	 cur = name[ pos ];
	 switch ( cur )
	 {
	    case '_':
	       base = kNtuple;
	       break;

	    case 'c': case 'C':
	       pos++;
	       base = kColumnNtuple;
	       break;
	 }
	 next = NULL;
	 break;

      case 'v': case 'V':
	 pos++;
	 base = kVectorOf;
	 next = new ObjectType( name, pos, constant );
	 break;

      case 't': case 'T':
	 pos++;
	 base = kTreeOf;
	 next = new ObjectType( name, pos, constant );
	 break;

      case 'm': case 'M':
	 pos++;
	 base = kMapOf;
	 next = new ObjectType( name, pos, constant );
	 break;
   }
   if ( name[ pos ] != '_' )
      base = kUndetermined;
}

///////////////////////////////////////////////////// Interpreter

Interpreter::Interpreter()
   : unnamedArg( "blank" )
{
   memory = new Memory();
   stopPos = 0;
   stopStatus = kOk;
}

Interpreter::~Interpreter()
{
   collectGarbage();
   delete memory;
}

Interpreter::Status Interpreter::interpret( ExpressionTreeNode* tree, ObjPtr value )
{
   string name( tree->getName() );
   stopPos = tree->getPos();

   if ( tree->getType() == kReal )
   {
      value = new ObjectReal( tree->realVal, true );
      tmpObjs.push_back( value );
      return kOk;
   }
   else if ( !strncmp( name.c_str(), "F_", 2 ) )
   {
      if ( !strcmp( name.c_str(), "F_assign" ) )
      {
	 FunctionAssign f_assign( memory );
	 stopStatus = getArgList( tree, f_assign, true );
	 if ( stopStatus != kOk )
	    return stopStatus;

	 if ( f_assign.argsOk() )
	 {
	    stopStatus = f_assign.execute( tree->firstChild()->getNameRef(),
					   value );
	    tmpObjs.push_back( value );
	    return stopStatus;
	 }
	 else
	    return ( stopStatus = kBadArgumentList );
      }

      else if ( !strcmp( name.c_str(), "F_add" ) )
      {
	 FunctionAdd f_add;
	 stopStatus = getArgList( tree, f_add, false );
	 if ( stopStatus != kOk )
	    return stopStatus;

	 if ( f_add.argsOk() )
	 {
	    stopStatus = f_add.execute( value );
	    tmpObjs.push_back( value );
	    return stopStatus;
	 }
	 else
	    return ( stopStatus = kBadArgumentList );
      }

      else
	 return ( stopStatus = kUndeclaredFunction );
   } // end if( function )

   else if ( !strncmp( name.c_str(), "r_", 2 ) )
   {
      if ( memory->retrieve( name, value ) )
	 return kOk;
      else
	 return ( stopStatus = kUndeclaredVariable );
   } // end if( real )

   else if ( !strcmp( name.c_str(), ":" ) )
      assert( false );

   else
      return ( stopStatus = kNotImplemented );
}

Interpreter::Status Interpreter::getArgList(
   ExpressionTreeNode* tree, Function& func, bool backDoor )
{
   vector< ExpNodePtr > children = tree->getChildren();
   vector< ExpNodePtr >::const_iterator iter;
   vector< ExpNodePtr >::const_iterator iter_begin = children.begin();
   vector< ExpNodePtr >::const_iterator iter_end = children.end();
   ObjPtr value;

   if ( backDoor )  // fix this!!!!
      iter_begin++;

   for ( iter = iter_begin;  iter != iter_end;  iter++ )
   {
      if ( !strcmp( (* iter)->getName().c_str(), ":" ) )
      {
	 assert( (* iter)->numChildren() == 2 );
	 if ( !strcmp( (* iter)->firstChild()->getName().c_str(), ":" ) )
	    return ( stopStatus = kNestedColons );
	 stopStatus = interpret( (* iter)->lastChild(), value );
	 if ( stopStatus != kOk )
	    return stopStatus;
	 func.addArg( (* iter)->firstChild()->getNameRef(), value );
      }
      else
      {
	 stopStatus = interpret( (* iter), value );
	 if ( stopStatus != kOk )
	    return stopStatus;
	 func.addArg( unnamedArg, value );
      }
   }

   return kOk;
}

void Interpreter::printErrorString( int indent )
{
   pointout( stopPos, indent );

   switch ( stopStatus )
   {
      case kOk:
	 break;
	 
      case kUndeclaredVariable:
	 printf( "Undeclared variable.\n" );
	 break;

      case kUndeclaredFunction:
	 printf( "Undeclared function.\n" );
	 break;

      case kBadArgumentList:
	 printf( "There is no version of this function which takes these arguments.\n" );
	 break;

      case kNestedColons:
	 printf( "Colons may only separate name:value pairs.\n" );
	 break;

      case kNotImplemented:
	 printf( "This has not yet been implemented.\n" );
	 break;
   }
}

void Interpreter::collectGarbage()
{
   while ( ! tmpObjs.empty() )
   {
      ObjPtr tmp = tmpObjs.back();
      if ( ! tmp->stored )
	 delete tmp;
      tmpObjs.pop_back();
   }
}

void Interpreter::pointout( int pos, int skip )
{
   while ( skip > 0 )
   {
      printf( " " );
      skip--;
   }
   while ( pos > 0 )
   {
      printf( "-" );
      pos--;
   }
   printf( "^\n" );
}

///////////////////////////////////////////////////// Object

Object::Object( ObjectType& _type )
   : type( _type )
{
   stored = false;
}

Object::Object( ObjectType::Base base, bool constant )
   : type( base, constant )
{
   stored = false;
}

Object::Object( bool constant )
   : type( ObjectType::kUndetermined, constant )
{
   stored = false;
}

ObjectType* Object::getType()
{
   stored = false;
   return &type;
}

///////////////////////////////////////////////////// Memory

Memory::~Memory()
{
   map< string, ObjPtr >::const_iterator iter;
   map< string, ObjPtr >::const_iterator iter_begin = data.begin();
   map< string, ObjPtr >::const_iterator iter_end = data.end();

   for ( iter = iter_begin;  iter != iter_end;  iter++ )
      delete iter->second;

//   data.clear();
}

void Memory::store( string& name, ObjPtr value )
{
   map< string, ObjPtr >::const_iterator iter;
   iter = data.find( name );
   if ( iter != data.end() )  // if this name has been found to exist
      delete iter->second;    // be sure there's no memory leak

   data[ name ] = value;
   value->stored = true;  // make sure the new one doesn't get garbage
                          // collected
}

bool Memory::retrieve( string& name, ObjPtr& value )
{
   map< string, ObjPtr >::const_iterator iter;
   iter = data.find( name );
   if ( iter == data.end() )
      return false;
   value = iter->second;
   return true;
}

///////////////////////////////////////////////////// Argument

Argument::Argument( string& _name, ObjectType::Base _type, ObjPtr _value )
   : name( _name )
{
   type = _type;
   value = _value;
}

string Argument::getName()
{
   return name;
}

ObjectType::Base Argument::getType()
{
   return type;
}

ObjPtr Argument::getValue()
{
   return value;
}

void Argument::print()
{
   value->print();
}

///////////////////////////////////////////////////// Function

Function::Function()
   : Object( ObjectType::kReal, true )
{ }

Function::~Function()
{
   flushArgs();
}

void Function::print()
{
   printf( "[function]\n" );   // later will include argument list, but never name
}

void Function::addArg( string& name, ObjPtr value )
{
   argumentList.push_back( new Argument( name, ObjectType::kReal, value ) );
}

void Function::flushArgs()
{
   while ( ! argumentList.empty() )
   {
      delete argumentList.back();
      argumentList.pop_back();
   }
}

void Function::printArgs()
{
   vector< Argument* >::const_iterator iter;
   vector< Argument* >::const_iterator iter_begin = argumentList.begin();
   vector< Argument* >::const_iterator iter_end = argumentList.end();
   
   for ( iter = iter_begin;  iter != iter_end;  iter++ )
      (* iter)->print();
   printf( "\n" );
}

///////////////////////////////////////////////////// FunctionAssign

FunctionAssign::FunctionAssign( Memory* _mem )
   : Function()
{
   mem = _mem;
}

bool FunctionAssign::argsOk()
{
   // need to change this when lvalues can be arguments
   return ( argumentList.size() == 1 );
}

Interpreter::Status FunctionAssign::execute( string& lvalue, ObjPtr& value )
{
   ObjectReal* tmp = dynamic_cast< ObjectReal* >( argumentList[0]->getValue() );
   value = new ObjectReal( tmp->val );
   mem->store( lvalue, value );
   tabbing_names.push_back( lvalue );
   return Interpreter::kOk;
}

Interpreter::Status FunctionAssign::execute( ObjPtr& value )
{
   return Interpreter::kOk;
}

///////////////////////////////////////////////////// FunctionAdd

FunctionAdd::FunctionAdd()
   : Function()
{ }

bool FunctionAdd::argsOk()
{
   vector< Argument* >::const_iterator iter;
   vector< Argument* >::const_iterator iter_begin = argumentList.begin();
   vector< Argument* >::const_iterator iter_end = argumentList.end();
   
   for ( iter = iter_begin;  iter != iter_end;  iter++ )
      if ( (* iter)->getType() != ObjectType::kReal )
	 return false;

   return true;
}

Interpreter::Status FunctionAdd::execute( ObjPtr& value )
{
   vector< Argument* >::const_iterator iter;
   vector< Argument* >::const_iterator iter_begin = argumentList.begin();
   vector< Argument* >::const_iterator iter_end = argumentList.end();
   
   double sum = 0.;
   for ( iter = iter_begin;  iter != iter_end;  iter++ )
   {
      ObjectReal* tmp = dynamic_cast< ObjectReal* >( (* iter)->getValue() );
      sum += tmp->val;
   }
   value = new ObjectReal( sum, true );

   return Interpreter::kOk;
}

///////////////////////////////////////////////////// ObjectReal

ObjectReal::ObjectReal( bool constant )
   : Object( ObjectType::kReal, constant )
{
   val = 0.;
}

ObjectReal::ObjectReal( double _val, bool constant )
   : Object( ObjectType::kReal, constant )
{
   val = _val;
}

void ObjectReal::print()
{
   printf( "%g\n", val );
}

// ///////////////////////////////////////////////////// ObjectType

// ObjectType::ObjectType( string& name, int& pos, bool firstTime,
// 			TokenType& status )
// {
//    int length = name.length();
//    if ( pos >= length )
//    {
//       status = kBadPrefix;
//       return;
//    }
//    char cur = name[pos];

//    of = NULL;

//    if ( firstTime )
//    {
//       if ( ( cur >= 'A'  &&  cur <= 'Z' )  ||  cur == '_' )
// 	 constant = true;
//       else if ( cur >= 'a'  &&  cur <= 'z' )
// 	 constant = false;
//       else
// 	 assert( false );
//    }

//    switch ( cur )
//    {
//       case '_':
// 	 status = kBadPrefix;
// 	 return;
//       case 'b': case 'B':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kBoolean;
// 	 break;
//       case 'i': case 'I':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kInteger;
// 	 break;
//       case 'r': case 'R':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kReal;
// 	 break;
//       case 'c': case 'C':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kComplex;
// 	 break;
//       case 'u': case 'U':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kUncertain;
// 	 break;

//       case 'd': case 'D':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kDirectory;
// 	 break;

//       case 'h': case 'H':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 if ( cur == '_' )
// 	    base = kHistogram;
// 	 else if ( cur == '2' )
// 	 {
// 	    pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	    cur = name[pos];
// 	    base = k2DHistogram;
// 	 }
// 	 else if ( cur == 'p'  ||  cur == 'P' )
// 	 {
// 	    pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	    cur = name[pos];
// 	    base = kProfileHistogram;
// 	 }
// 	 else
// 	 {
// 	    status = kBadPrefix;
// 	    return;
// 	 }
// 	 break;
//       case 'n': case 'N':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 if ( cur == '_' )
// 	    base = kNtuple;
// 	 else if ( cur == 'c'  ||  cur == 'C' )
// 	 {
// 	    pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	    cur = name[pos];
// 	    base = kColumnNtuple;
// 	 }
// 	 else
// 	 {
// 	    status = kBadPrefix;
// 	    return;
// 	 }
// 	 break;

//       case 'v': case 'V':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kVectorOf;
// 	 of = new ObjectType( name, pos, false, status );
// 	 pos--; cur = name[pos];
// 	 if ( status != kNothing )
// 	    return;
// 	 break;
//       case 't': case 'T':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kTreeOf;
// 	 of = new ObjectType( name, pos, false, status );
// 	 pos--; cur = name[pos];
// 	 if ( status != kNothing )
// 	    return;
// 	 break;
//       case 'm': case 'M':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kMapOf;
// 	 of = new ObjectType( name, pos, false, status );
// 	 pos--; cur = name[pos];
// 	 if ( status != kNothing )
// 	    return;
// 	 break;

//       case 'f': case 'F':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kFunction;
// 	 break;
//       case 'l': case 'L':
// 	 pos++; if ( pos >= length ) { status = kBadPrefix; return; }
// 	 cur = name[pos];
// 	 base = kLink;
// 	 break;

//       default:
// 	 status = kBadPrefix;
// 	 return;
//    }
   
//    if ( cur != '_' )
//    {
//       status = kBadPrefix;
//       return;
//    }

//    pos++;
//    if ( pos >= length )
//       status = kMissingName;
//    else
//       status = kNothing;
// }

// ObjectType::ObjectType( string& name, TokenType& status )
// {
//    int pos = 0;
//    ObjectType( name, pos, true, status );
// }

// ObjectType::ObjectType( const char* name, TokenType& status )
// {
//    int pos = 0;
//    string name2( name );
//    ObjectType( name2, pos, true, status );
// }

// ObjectType::ObjectType( Base _base )
// {
//    base = _base;
//    constant = true;
//    of = NULL;
// }

// ObjectType::ObjectType()
// {
//    base = kUndetermined;
//    constant = true;
//    of = NULL;
// }

// ObjectType::~ObjectType()
// {
//    if ( of )
//       delete of;
// }

// ObjectType::Base ObjectType::getBase()
// {
//    return base;
// }

// ObjectType* ObjectType::getOf()
// {
//    return of;
// }

// bool ObjectType::sameQ( ObjectType* other )
// {
//    assert( other );
//    Base _base = other->getBase();
//    if ( base != _base )
//       return false;
//    // otherwise, they're the same at this level
//    switch ( _base )
//    {
//      case kBoolean:
//      case kInteger:
//      case kReal:
//      case kComplex:
//      case kUncertain:
//      case kDirectory:
//      case kHistogram:
//      case k2DHistogram:
//      case kProfileHistogram:
//      case kNtuple:
//      case kColumnNtuple:
//      case kFunction:
//      case kLink:
// 	return true;

//      case kVectorOf:
//      case kTreeOf:
//      case kMapOf:
// 	assert( of  &&  other->getOf() );
// 	return of->sameQ( other->getOf() );

//       default:
// 	 assert( false );
//    }
// }

// void ObjectType::printDiagnostic()
// {
//    switch ( base )
//    {
//      case kBoolean:
//      case kInteger:
//      case kReal:
//      case kComplex:
//      case kUncertain:
//      case kDirectory:
//      case kHistogram:
//      case k2DHistogram:
//      case kProfileHistogram:
//      case kNtuple:
//      case kColumnNtuple:
//      case kFunction:
//      case kLink:
// 	if ( of != NULL )
// 	   printf( "badly-terminated " );
// 	break;

//      case kVectorOf:
//      case kTreeOf:
//      case kMapOf:
// 	if ( of == NULL )
// 	   printf( "badly-linked " );
// 	break;

//       default:
// 	 printf( "bad type!\n" );
// 	 return;
//    }

//    switch ( base )
//    {
//      case kBoolean:
// 	printf( "boolean\n" );
// 	break;
//      case kInteger:
// 	printf( "integer\n" );
// 	break;
//      case kReal:
// 	printf( "real\n" );
// 	break;
//      case kComplex:
// 	printf( "complex\n" );
// 	break;
//      case kUncertain:
// 	printf( "uncertain\n" );
// 	break;
//      case kVectorOf:
// 	printf( "vector of " );
// 	of->printDiagnostic();
// 	break;
//      case kTreeOf:
// 	printf( "tree of " );
// 	of->printDiagnostic();
// 	break;
//      case kMapOf:
// 	printf( "map of " );
// 	of->printDiagnostic();
// 	break;

//      case kDirectory:
// 	printf( "directory\n" );
// 	break;

//      case kHistogram:
// 	printf( "histogram\n" );
// 	break;
//      case k2DHistogram:
// 	printf( "2-D histogram\n" );
// 	break;
//      case kProfileHistogram:
// 	printf( "profile histogram\n" );
// 	break;
//      case kNtuple:
// 	printf( "ntuple\n" );
// 	break;
//      case kColumnNtuple:
// 	printf( "column-wise ntuple\n" );
// 	break;

//      case kFunction:
// 	printf( "function\n" );
// 	break;
//      case kLink:
// 	printf( "link\n" );
// 	break;
//    }
// }

