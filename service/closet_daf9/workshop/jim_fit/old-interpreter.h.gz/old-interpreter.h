#if !defined(INTERPRETER_H)
#define INTERPRETER_H

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string>
#include <vector>
#include <map>
#include "parser.h"

//      START              TYPE

//       b_                boolean
//       i_                integer
//       r_                real
//       s_                string

//       c_                complex
//       u_                uncertain real

//       d_                directory (structure)

//       h_                1-D histogram
//       h2_               2-D histogram
//       hp_               profile histogram
//       n_                row-wise ntuple
//       nc_               column-wise ntuple

//       v?_               vector (array) of type "?"
//       t?_               tree of type "?"
//       m?_               map (point-by-point function, interpolated if
//                         real, complex, uncertain)

//       f_                function (as much is evaluated as possible)
//                     (the prefix for a constant function need not be typed)
//       l_                function (link) where evaluation is postponed

class ObjectType;
class Memory;
class Object;
typedef Object* ObjPtr;
class Function;
class FunctionAssign;
class FunctionAdd;

class ObjectType
{
   public:
      typedef enum {
	 kUndetermined,
	 
	 kBoolean,
	 kInteger,
	 kReal,
	 kString,
	 kComplex,
	 kUncertain,
	 
	 kDirectory,
	 
	 kHistogram,
	 k2DHistogram,
	 kProfileHistogram,
	 kNtuple,
	 kColumnNtuple,
	 
	 kVectorOf,
	 kTreeOf,
	 kMapOf
      } Base;

      ObjectType( ObjectType& other );
      ObjectType( Base _base, bool _constant );
      ObjectType( char* prefix, bool _constant );
      ObjectType( char* prefix, int& pos, bool _constant );
      
      Base getBase();
      ObjectType* getNext();
      bool isConstant();
      bool isSame( ObjectType& other );
   private:
      void setType( char* prefix, int& pos );

      Base base;
      ObjectType* next;    // only used for vectors, trees and maps
      bool constant;
};

class Interpreter
{
   public:
      typedef enum {
	 kOk,
	 kUndeclaredVariable,
	 kUndeclaredFunction,
	 kBadArgumentList,
	 kNestedColons,
	 kNotImplemented
      } Status;

      Interpreter();
      ~Interpreter();

      Status interpret( ExpressionTreeNode* tree, ObjPtr value );
      void printErrorString( int indent );
      void collectGarbage();
   private:
      Status getArgList( ExpressionTreeNode* tree, Function& func,
			 bool backDoor );
      void pointout( int pos, int skip );

      string unnamedArg;
      Memory* memory;
      int stopPos;
      Status stopStatus;

      vector< ObjPtr > tmpObjs;
};

class Object
{
   public:
      Object( ObjectType& _type );
      Object( ObjectType::Base base, bool constant );
      Object( bool constant );

      ObjectType* getType();
      virtual void print() = 0;

      bool stored;
   private:
      ObjectType type;
};

class Memory
{
   public:
      ~Memory();
      void store( string& name, ObjPtr value  );
      bool retrieve( string& name, ObjPtr& value );
   private:
      map< string, ObjPtr > data;
};

class Argument
{
   public:
      Argument( string& _name, ObjectType::Base _type, ObjPtr _value );

      string getName();
      ObjectType::Base getType();
      ObjPtr getValue();

      void print();
   private:
      string name;
      ObjectType::Base type;
      ObjPtr value;
};

class Function : public Object
{
   public:
      Function();
      ~Function();

      void print();

      void addArg( string& name, ObjPtr value );
      void flushArgs();
      void printArgs();

      virtual bool argsOk() = 0;
      virtual Interpreter::Status execute( ObjPtr& value ) = 0;
   protected:
      vector< Argument* > argumentList;
};

class FunctionAssign : public Function
{
   public:
      FunctionAssign( Memory* _mem );
      bool argsOk();
      Interpreter::Status execute( string& lvalue, ObjPtr& value );
      Interpreter::Status execute( ObjPtr& value );
   private:
      Memory* mem;
};

class FunctionAdd : public Function
{
   public:
      FunctionAdd();
      bool argsOk();
      Interpreter::Status execute( ObjPtr& value );
};

class ObjectReal : public Object
{
   public:
      ObjectReal( bool constant );
      ObjectReal( double _val, bool constant );

      void print();

      double val;
};

// class ObjectType
// {
//    public:
//       typedef enum {
// 	 kUndetermined,

// 	 kBoolean,
// 	 kInteger,
// 	 kReal,
// 	 kComplex,
// 	 kUncertain,

// 	 kDirectory,

// 	 kHistogram,
// 	 k2DHistogram,
// 	 kProfileHistogram,
// 	 kNtuple,
// 	 kColumnNtuple,
	 
// 	 kVectorOf,
// 	 kTreeOf,
// 	 kMapOf,
	 
// 	 kFunction,
// 	 kLink
//       } Base;
      
//       ObjectType( string& name, int& pos, bool firstTime,
//                   TokenType& status );

//       // user-level constructors
//       ObjectType( string& name, TokenType& status );
//       ObjectType( const char* name, TokenType& status );
//       ObjectType( Base _base );
//       ObjectType();

//       ~ObjectType();

//       Base getBase();
//       ObjectType* getOf();
//       bool sameQ( ObjectType* other );
//       void printDiagnostic();
//    private:
//       Base base;
//       bool constant;
//       ObjectType* of;
// };

#endif /* INTERPRETER_H */
