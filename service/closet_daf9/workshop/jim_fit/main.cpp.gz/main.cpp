#include <string>
#include "commandline.h"
#include "parser.h"
#include "interpreter.h"

extern "C" CPPFunction* rl_attempted_completion_function;
//  extern "C" char* rl_basic_word_break_characters;
//  extern "C" char* rl_completer_quote_characters;

int main( int argc, char** argv )
{
   rl_initialize();
   using_history();
   rl_attempted_completion_function = (CPPFunction *)tabbing_completion;
//     char* local_word_break_chars;
//     char* local_word_break_chars2;
//     sprintf( local_word_break_chars,
//  	    " \t\n\"%s", "()[]:|&!=<>+-*/%^.'" );
//     local_word_break_chars2 = xmalloc( strlen( local_word_break_chars + 1 ) );
//     strcpy( local_word_break_chars2, local_word_break_chars );
//     rl_completer_quote_characters = local_word_break_chars2;

   Interpreter interp;

   while( true )
   {
      // get the line
      char* char_input = readline( "-> " );
      if ( char_input )
      {
	 int hist_result;
	 char* error_message;
	 hist_result = history_expand( char_input, &error_message );
	 if ( hist_result )
	    fprintf( stderr, "%s\n", error_message );

	 if ( hist_result < 0  ||  hist_result == 2 )
	    free( error_message );
	 else
	    add_history( char_input );
      }
      string user_input = char_input;
      free( char_input );

      // remove leading prompts (so that I can do the easy line copy
      // by mouse)
      int pos = 0;
      int prompts = 0;
      while ( user_input[pos]   == '-'  &&
	      user_input[pos+1] == '>'  &&
	      user_input[pos+2] == ' ' )
      {
	 pos += 3;
	 prompts++;
      }
      string no_prompts( user_input.substr( pos ) );

      // run the interpreter
      ExpressionTree tree( no_prompts );
      if ( tree.valid() )
      {
// 	 tree.print();
	 
	 ReturnValue retVal;
	 if ( interp.interpret( tree.getRoot(), retVal )
	      == Interpreter::kOk )
	    printf( "Type: %s, Value: %s\n",
		    retVal.object->printType().c_str(),
		    retVal.object->print().c_str() );
	 else
	    interp.printErrorString( 3 * (prompts + 1) );

	 interp.collectGarbage();
      }
      else
 	 tree.printErrorString( 3 * (prompts + 1) );
      
   }

   return(0);
}
