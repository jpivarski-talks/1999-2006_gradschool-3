#include "parser.h"

///////////////////////////////////////////////////// ExpressionTreeNode

ExpressionTreeNode::ExpressionTreeNode(
   ExpNodePtr _parent, string& _name, TokenType _type, InsertionMode mode, int pos )
   : name( _name )
{
   setUp( _parent, _type, mode, pos );
}

ExpressionTreeNode::ExpressionTreeNode(
   ExpNodePtr _parent, const char* _name, TokenType _type, InsertionMode mode, int pos )
   : name( _name )
{
   setUp( _parent, _type, mode, pos );
}

void ExpressionTreeNode::setUp(
   ExpNodePtr _parent, TokenType _type, InsertionMode mode, int pos )
{
   parent = _parent;
   type = _type;
   nodePos = pos;

   boolVal = false;
   intVal = 0;
   realVal = 0.;

   ExpNodePtr tmp;
   if ( parent )
      switch ( mode )
      {
	 case kNewTree:
	    break;
	 case kInsertNewChild:
	    parent->addChild( this );
	    break;
	 case kAboveLastChild:
	    tmp = parent->replaceLastChild( this );
	    if ( tmp )
	       addChild( tmp );
	    break;
      }
}

ExpressionTreeNode::~ExpressionTreeNode()
{ }

ExpNodePtr ExpressionTreeNode::getParent()
{
   return parent;
}

string ExpressionTreeNode::getName()
{
   return name;
}

string& ExpressionTreeNode::getNameRef()
{
   return name;
}

TokenType ExpressionTreeNode::getType()
{
   return type;
}

int ExpressionTreeNode::getPos()
{
   return nodePos;
}

ExpNodePtr ExpressionTreeNode::firstChild()
{
   if ( children.empty() )
      return NULL;
   else
      return children.front();
}

ExpNodePtr ExpressionTreeNode::lastChild()
{
   if ( children.empty() )
      return NULL;
   else
      return children.back();
}

int ExpressionTreeNode::numChildren()
{
   return children.size();
}

ExpNodePtr ExpressionTreeNode::addChild( ExpNodePtr _child )
{
   children.push_back( _child );
   return _child;
}

ExpNodePtr ExpressionTreeNode::replaceLastChild( ExpNodePtr to )
{
   ExpNodePtr from = lastChild();

   if ( from )
      children.pop_back();
   children.push_back( to );
   return from;
}

vector< ExpNodePtr > ExpressionTreeNode::getChildren()
{
   return children;
}

void ExpressionTreeNode::killChildren()
{
   vector< ExpNodePtr >::const_iterator iter;
   for( iter = children.begin();  iter != children.end();  iter++ )
      delete (* iter);
}

void ExpressionTreeNode::killProgenity()
{
   vector< ExpNodePtr >::const_iterator iter;
   for( iter = children.begin();  iter != children.end();  iter++ )
   {
      (* iter)->killProgenity();
      delete (* iter);
   }
}

void ExpressionTreeNode::printDiagnostic()
{
   printf( "Name: \"%s\" at %d\n", name.c_str(), this );
   if ( parent )
      printf( "Parent: \"%s\" at %d\n", parent->getName().c_str(), parent );
   else
      printf( "Parent: none.\n" );
   
   vector< ExpNodePtr >::const_iterator iter;
   if ( children.empty() )
      printf( "Children: none.\n" );
   else
      for( iter = children.begin();  iter != children.end();  iter++ )
	 printf( "  Child: \"%s\" at %d\n", (* iter)->getName().c_str(), (* iter) );

   printf( "\n" );
}

void ExpressionTreeNode::print()
{
   vector< ExpNodePtr >::const_iterator iter;
   switch ( type )
   {
      case kBoolean:
	 if ( boolVal )
	    printf( "true" );
	 else
	    printf( "false" );
	 break;

      case kInteger:
	 printf( "%d", intVal );
	 break;

      case kReal:
	 printf( "%g", realVal );
	 break;

      case kVariable:
	 printf( "%s", name.c_str() );
	 break;

      case kBinaryL1:           // ":" for argument label delimiting
      case kBinaryL2:           // "||" as in "or"
      case kBinaryL3:           // "&&" as in "and"
      case kPreunaryL35:        // "!" as in "not"
      case kBinaryL4:           // ":=" for assignment
      case kBinaryL5:           // "!=" "==" ">" "<" ">=" and "<="
      case kBinaryL6:           // "+" "-" as in "add" and "subtract"
      case kBinaryL7:           // "*" "/" "%" as in "mult" "div" and "mod"
      case kBinaryL8:           // "^" as in "exponentiate"
      case kPreunaryL9:         // "+" or "-" (sign for numbers or variables)
      case kPostunaryL95:       // "!" as in "factorial"
      case kBinaryL97:          // "." for getting members of an object
      case kFunction:
	 printf( "%s", name.c_str() );
	 if ( children.empty() )
	    printf( "()" );
	 else
	 {
	    printf( "( " );
	    iter = children.begin();
	    do {
	       (* iter )->print();
	       iter++;
	       if ( iter != children.end() )
		  printf( ", " );
	       else
		  printf( " )" );
	    } while ( iter != children.end() );
	 }
	 break;

//        case kColon:
//  	 assert( numChildren() == 2 );
//  	 iter = children.begin();
//  	 (* iter )->print();
//  	 printf( " : " );
//  	 iter++;
//  	 (* iter )->print();
//  	 break;

      case kPlainString:
	 printf( "'%s'", name.c_str() );
	 break;
      case kFormattedString:
	 printf( "\"%s\"", name.c_str() );
	 break;

      case kNothing:
	 break;

      default:
	 printf( "...\n" );
	 assert( false );
   }
}

///////////////////////////////////////////////////// ExpressionTree

ExpressionTree::ExpressionTree( string& master )
   : defaultVariablePrefix( "r_" ),
     defaultFunctionPrefix( "F_" )
{
   ExpNodePtr tmp = new ExpressionTreeNode( NULL, "root", kFunction,
					    ExpressionTreeNode::kNewTree, 0 );
   pos = 0;
   ExpectationType expectationMode = kExpectExpression;

   finishState = makeTree( master, tmp, pos, expectationMode );

   if ( finishState > kErrorSeparator  &&  ! parenDepth.empty() )
      finishState = kUnbalancedParens;

   if ( tmp->numChildren() == 1 )
      root = tmp->lastChild();
   else
      root = NULL;
   delete tmp;
}

ExpressionTree::~ExpressionTree()
{
   if ( root )
   {
      root->killProgenity();
      delete root;
   }
}

bool ExpressionTree::valid()
{
   return ( finishState > kErrorSeparator );
}

void ExpressionTree::print()
{
   if ( root )
      root->print();
   printf( "\n" );
}

void ExpressionTree::printErrorString( int indent )
{
   vector< ParenDepthType >::const_iterator parenIter;

   if ( finishState < kErrorSeparator )
   {
      pointout( pos, indent );
      switch ( finishState )
      {
	 case kProgramError:
	    printf( "Program Error!\n" );
	    break;
	 case kUnknownToken:
	    printf( "Unknown Token!\n" );
	    break;
	 case kIllegalCombination:
	    printf( "Illegal Combination!\n" );
	    break;
	 case kBadlyExpressedNumber:
	    printf( "Badly Expressed Number!\n" );
	       break;
	 case kUnclosedString:
	    printf( "Unclosed String!\n" );
	    break;
	 case kUnbalancedParens:
	    printf( "Unbalanced (or badly nested) parenthesis!\n" );
	    printf( "Paren stack: " );
	    for ( parenIter = parenDepth.begin();
		  parenIter != parenDepth.end();
		  parenIter++ )
	       switch ( (* parenIter) )
	       {
		  case kRoundParen:
		     printf( "( " );
		     break;
		  case kSquareParen:
		     printf( "[ " );
		     break;
//  		  case kColonParen:
//  		     // don't show these, they would only be confusing
//  		     break;
	       }

	    printf( "\n" );
	    break;
      }
   }
}

ExpNodePtr ExpressionTree::getRoot()
{
   return root;
}

TokenType ExpressionTree::getExpressionToken( string& master, int& pos,
					      string& name )
{
   int length = master.length();
   if ( pos >= length )
      return kNothing;
   char cur;

   bool seenDecimal;
   double sinceDecimal;
   double exponent;
   bool posExp;

   int namePos;
   bool couldBeTrue, couldBeFalse, isBool;

   // Get past any initial whitespace
   while ( true )
   {
      if ( pos >= length )
	 return kNothing;
      cur = master[pos];
      if ( cur != ' '  &&  cur != 9 )    //  ASCII 9 == tab
	 break;
      pos++;
   }

   // read the first two characters of the token
   name = cur;
   pos++;
   switch ( cur )
   {
      case '(':
	 return kParenOpen;
      case ')':
	 return kParenClose;
      case 39:                           //  ASCII 39 == singleQuote
	 return kQuote;
      case 34:                           //  ASCII 34 == doubleQuote
	 return kDoubleQuote;
      case '!':
	 name = "not";
	 return kPreunaryL35;
      case '+':
	 name = "pos";
	 return kPreunaryL9;
      case '-':
	 name = "neg";
	 return kPreunaryL9;
      case '/':
	 if ( master[pos] == '/' )
	 {
	    name += '/';
	    pos++;
	    return kCommentStart;
	 }
	 else
	    return kIllegalCombination;

      case '[':
      case ']':
      case ',':
      case ':':
      case '|':
      case '&':
      case '<':
      case '>':
      case '=':
      case '*':
      case '%':
      case '^':
	 return kIllegalCombination;
   }
   if ( !( ( cur >= '0'  &&  cur <= '9' )  ||
	   ( cur >= 'A'  &&  cur <= 'Z' )  ||
	   ( cur >= 'a'  &&  cur <= 'z' )  ||
	   cur == '_'  ||  cur == '~'  ||
	   cur == '.' )                       )
      return kUnknownToken;

   // The token is a number. Read to its end.
   if ( ( cur >= '0'  &&  cur <= '9' )  ||  cur == '.' )
   {
      if ( cur >= '0'  &&  cur <= '9' )
	 readInInt = ( cur - '0' );

      seenDecimal = ( cur == '.' );

      if ( cur == '.'  &&
	   ( pos >= length  ||
	     !( (cur = master[pos]) >= '0'  &&  cur <= '9' ) ) )
	 return kIllegalCombination;

      while ( true )
      {
	 if ( pos >= length )
	 {
	    if ( seenDecimal )
	       return kReal;
	    else
	       return kInteger;
	 }
	 cur = master[pos];
	 if ( cur >= '0'  &&  cur <= '9' )
//	    name += cur;
	 {
	    if ( ! seenDecimal )
	    {
	       readInInt *= 10;
	       readInInt += ( cur - '0' );
	    }
	    else
	    {
	       sinceDecimal *= 0.1;
	       readInReal += double( cur - '0' ) * sinceDecimal;
	    }
	 }

	 else if ( cur == '.' )
	 {
	    if ( seenDecimal )
	       return kBadlyExpressedNumber;
	    seenDecimal = true;
//	    name += cur;
	    sinceDecimal = 1.;
	    readInReal = double( readInInt );
	 }

	 else if ( cur == 'e'  ||  cur == 'E' )
	 {
//	    name += cur;
	    if ( ! seenDecimal )
	       readInReal = double( readInInt );

	    exponent = 0.;

	    pos++;
	    if ( pos >= length )
	       return kBadlyExpressedNumber;
	    cur = master[pos];
	    if ( cur == '+'  ||  cur == '-' )
	    {
//	       name += cur;
	       posExp = ( cur == '+' );

	       pos++;
	       if ( pos >= length )
		  return kBadlyExpressedNumber;
	       cur = master[pos];
	    }
	    else
	       posExp = true;

	    if ( !( cur >= '0'  &&  cur <= '9' ) )
	       return kBadlyExpressedNumber;
	    while ( cur >= '0'  &&  cur <= '9'  &&  pos < length )
	    {
//	       name += cur;
	       exponent *= 10.;
	       exponent += double( cur - '0' );

	       pos++;
	       cur = master[pos];
	    }

	    if ( ! posExp )
	       exponent *= -1.;
	    readInReal *= pow( 10., exponent );
	    return kReal;
	 }
	 else  // no exponent
	 {
	    if ( seenDecimal )
	       return kReal;
	    else
	       return kInteger;
	 }

	 pos++;
      }
   }

   // The token is either a variable or a function name.
   // Read the rest of the name of the token
   // until whitespace or another token
   readInNoPrefix = true;
   couldBeTrue = ( cur == 't'  ||  cur == 'T' );
   couldBeFalse = ( cur == 'f'  ||  cur == 'F' );
   isBool = false;
   namePos = 1;

   while ( true )
   {
      if ( pos >= length )
      {
	 if ( isBool )
	    return kBoolean;
	 else
	    return kVariable;
      }
      cur = master[pos];
      if ( cur == ' '  ||  cur == 9 )    //  ASCII 9 == tab
	 while ( true )
	 {
	    pos++;
	    if ( pos >= length )
	    {
	       if ( isBool )
		  return kBoolean;
	       else
		  return kVariable;
	    }

	    cur = master[pos];
	    if ( cur == '(' )
	       return kFunction;
	    if ( cur != ' '  &&  cur != 9 )  //  ASCII 9 == tab
	    {
	       if ( isBool )
		  return kBoolean;
	       else
		  return kVariable;
	    }

	 }
      if ( cur == '(' )
	 return kFunction;
      if ( ( cur >= '0'  &&  cur <= '9' )  ||
	   ( cur >= 'A'  &&  cur <= 'Z' )  ||
	   ( cur >= 'a'  &&  cur <= 'z' )  ||
	   cur == '_'  ||  cur == '~'          )
      {
	 name += cur;
	 pos++;
	 namePos++;

	 if ( cur == '_' )
	    readInNoPrefix = false;

	 if ( couldBeTrue )
	 {
	    switch ( namePos )
	    {
	       case 2:
		  if ( cur != 'r'  &&  cur != 'R' )
		     couldBeTrue = false;
		  break;
	       case 3:
		  if ( cur != 'u'  &&  cur != 'U' )
		     couldBeTrue = false;
		  break;
	       case 4:
		  if ( cur != 'e'  &&  cur != 'E' )
		     couldBeTrue = false;
		  else
		  {
		     readInBool = true;
		     isBool = true;
		  }
		  break;
	       default:  // if you see a fifth character
		  couldBeTrue = false;
		  isBool = false;
	    }
	 }
	 if ( couldBeFalse )
	    switch ( namePos )
	    {
	       case 2:
		  if ( cur != 'a'  &&  cur != 'A' )
		     couldBeFalse = false;
		  break;
	       case 3:
		  if ( cur != 'l'  &&  cur != 'L' )
		     couldBeFalse = false;
		  break;
	       case 4:
		  if ( cur != 's'  &&  cur != 'S' )
		     couldBeFalse = false;
		  break;
	       case 5:
		  if ( cur != 'e'  &&  cur != 'E' )
		     couldBeFalse = false;
		  else
		  {
		     readInBool = false;
		     isBool = true;
		  }
		  break;
	       default:  // if you see a sixth character
		  couldBeFalse = false;
		  isBool = false;
	    }
      }
      else
	 return kVariable;
   }
}

TokenType ExpressionTree::getOperatorToken( string& master, int& pos,
					    string& name )
{
   int length = master.length();
   if ( pos >= length )
      return kNothing;
   char cur;

   // Get past any initial whitespace
   while ( true )
   {
      if ( pos >= length )
	 return kNothing;
      cur = master[pos];
      if ( cur != ' '  &&  cur != 9 )    //  ASCII 9 == tab
	 break;
      pos++;
   }

   // read the first two characters of the token
   name = cur;
   pos++;
   switch ( cur )
   {
      case ')':
	 return kParenClose;
      case '[':
	 return kSquareParenOpen;
      case ']':
	 return kSquareParenClose;
      case ',':
	 return kComma;
      case ':':
	 if ( master[pos] == '=' )
	 {
	    name += '=';
	    pos++;
	    return kBinaryL4;
	 }
	 else
//	    return kColon;
	    return kBinaryL1;
      case '|':
	 name += master[pos];
	 pos++;
	 if ( cur == '|' )
	    return kBinaryL2;
	 else
	    return kUnknownToken;
      case '&':
	 name += master[pos];
	 pos++;
	 if ( cur == '&' )
	    return kBinaryL3;
	 else
	    return kUnknownToken;
      case '!':
	 if ( master[pos] == '=' )
	 {
	    name += '=';
	    pos++;
	    return kBinaryL5;
	 }
	 else
	    return kPostunaryL95;
      case '<':
      case '>':
	 if ( master[pos] == '=' )
	 {
	    name += '=';
	    pos++;
	 }
	 return kBinaryL5;
      case '=':
	 if ( master[pos] == '=' )
	 {
	    name += '=';
	    pos++;
	    return kBinaryL5;
	 }
	 return kUnknownToken;
      case '+':
      case '-':
	 return kBinaryL6;
      case '*':
	 if ( master[pos] == '*' )
	 {
	    int nPos = name.length() - 1;
	    name[nPos] = '^';
	    pos++;
	    return kBinaryL8;
	 }
	 else
	    return kBinaryL7;
      case '/':
	 if ( master[pos] == '/' )
	 {
	    name += '/';
	    pos++;
	    return kCommentStart;
	 }
	 else
	    return kBinaryL7;
      case '%':
	 return kBinaryL7;
      case '^':
	 return kBinaryL8;
      case '.':
	 return kBinaryL97;

      case '(':
      case 39:                           //  ASCII 39 == singleQuote
      case 34:                           //  ASCII 34 == doubleQuote
	 return kIllegalCombination;
   }
   if ( !( ( cur >= '0'  &&  cur <= '9' )  ||
	   ( cur >= 'A'  &&  cur <= 'Z' )  ||
	   ( cur >= 'a'  &&  cur <= 'z' )  ||
	   cur == '_'  ||  cur == '~' )        )
      return kUnknownToken;
   else
      return kIllegalCombination;
}

TokenType ExpressionTree::getPlainStrToken( string& master, int& pos,
					    string& name )
{
   int length = master.length();
   if ( pos >= length )
      return kUnclosedString;
   char cur;

   name = "";

   while ( (cur = master[pos]) != 39 )   //  ASCII 39 == singleQuote
   {
      if ( pos >= length )
	 return kUnclosedString;
      name += cur;
      pos++;
   }
   return kPlainString;
}

TokenType ExpressionTree::getFormattedStrToken( string& master, int& pos,
						string& name )
{
   int length = master.length();
   if ( pos >= length )
      return kUnclosedString;
   char cur;
   char prev = 0;

   name = "";

   while ( (cur = master[pos]) != 34  ||     //  ASCII 34 == doubleQuote
	   (cur == 34  &&  prev == 92 )  )   //  ASCII 92 == backslash
   {
      if ( pos >= length )
	 return kUnclosedString;
      if ( prev == 92 )                      //  ASCII 92 == backslash
      {
	 int nPos = name.length() - 1;
	 switch ( cur )
	 {
	    case '0': name[nPos] = 0;   break;
	    case 'a': name[nPos] = 7;   break;
	    case 'b': name[nPos] = 8;   break;
	    case 't': name[nPos] = 9;   break;
	    case 'n': name[nPos] = 10;  break;
	    case 'v': name[nPos] = 11;  break;
	    case 'f': name[nPos] = 12;  break;
	    case 'r': name[nPos] = 13;  break;
	    case  34: name[nPos] = 34;  break;
	    case  92: name[nPos] = 92;  break;
	    case 'd': name[nPos] = 127; break;
	    default:
	       name += cur;
	 }
      }
      else
	 name += cur;
      pos++;
      prev = cur;
   }
   return kFormattedString;
}

void ExpressionTree::pointout( int pos, int skip )
{
   while ( skip > 0 )
   {
      printf( " " );
      skip--;
   }
   while ( pos > 0 )
   {
      printf( "-" );
      pos--;
   }
   printf( "^\n" );
}

TokenType ExpressionTree::getToken( string& master, int& pos, string& name,
				    ExpectationType expectationMode )
{
   switch ( expectationMode )
   {
      case kExpectExpression:
	 return getExpressionToken( master, pos, name );
      case kExpectOperator:
	 return getOperatorToken( master, pos, name );
      case kExpectPlainStr:
	 return getPlainStrToken( master, pos, name );
      case kExpectFormattedStr:
	 return getFormattedStrToken( master, pos, name );
   }
}

char* ExpressionTree::mapOpName( string& name )
{
   if ( !strcmp( name.c_str(), "(" ) )
      return "F_identity";
   if ( !strcmp( name.c_str(), "[" ) )
      return "F_element";

   if ( !strcmp( name.c_str(), ":" ) )    // ":" is not a function
      return ":";
   if ( !strcmp( name.c_str(), "||" ) )
      return "F_or";
   if ( !strcmp( name.c_str(), "&&" ) )
      return "F_and";
   if ( !strcmp( name.c_str(), "not" ) )
      return "F_not";
   if ( !strcmp( name.c_str(), ":=" ) )
      return "F_assign";
   if ( !strcmp( name.c_str(), "!=" ) )
      return "F_ne";
   if ( !strcmp( name.c_str(), "==" ) )
      return "F_eq";
   if ( !strcmp( name.c_str(), ">" ) )
      return "F_gt";
   if ( !strcmp( name.c_str(), "<" ) )
      return "F_lt";
   if ( !strcmp( name.c_str(), ">=" ) )
      return "F_ge";
   if ( !strcmp( name.c_str(), "<=" ) )
      return "F_le";
   if ( !strcmp( name.c_str(), "+" ) )
      return "F_add";
   if ( !strcmp( name.c_str(), "-" ) )
      return "F_subtract";
   if ( !strcmp( name.c_str(), "*" ) )
      return "F_mult";
   if ( !strcmp( name.c_str(), "/" ) )
      return "F_divide";
   if ( !strcmp( name.c_str(), "%" ) )
      return "F_mod";
   if ( !strcmp( name.c_str(), "^" ) )
      return "F_pow";
   if ( !strcmp( name.c_str(), "pos" ) )
      return "F_pos";
   if ( !strcmp( name.c_str(), "neg" ) )
      return "F_neg";
   if ( !strcmp( name.c_str(), "!" ) )
      return "F_factorial";
   if ( !strcmp( name.c_str(), "." ) )
      return "F_member";

   assert( false );
}

TokenType ExpressionTree::makeTree( string& master, ExpNodePtr parent, int& pos,
				    ExpectationType& expectationMode )
{
   string name;
   TokenType token;

   while( ( ( token=getToken( master, pos, name, expectationMode ) )
	    > kErrorSeparator )
	  &&  token != kNothing  &&  token != kCommentStart )
   {
//       printf( "token %d \"%s\", expectationMode %d, parent \"%s\"\n",
//  	      token, name.c_str(), expectationMode, parent->getName().c_str() );

      token = processToken( master, parent, pos, token, name, expectationMode );

      if ( expectationMode == kPopUpTree )
	 return token;
   }
   return token;
}

TokenType ExpressionTree::processToken(
   string& master, ExpNodePtr parent, int& pos, TokenType token,
   string& name, ExpectationType& expectationMode )
{
   TokenType tmpToken;
   ExpNodePtr tmp;

   switch ( token )
   {
      case kBoolean:
	 tmp = new ExpressionTreeNode( parent, "", token,
				       ExpressionTreeNode::kInsertNewChild, pos );
	 tmp->boolVal = readInBool;
	 expectationMode = kExpectOperator;
	 return token;
	 
      case kInteger:
	 tmp = new ExpressionTreeNode( parent, "", token,
				       ExpressionTreeNode::kInsertNewChild, pos );
	 tmp->intVal = readInInt;
	 expectationMode = kExpectOperator;
	 return token;
	 
      case kReal:
	 tmp = new ExpressionTreeNode( parent, "", token,
				       ExpressionTreeNode::kInsertNewChild, pos );
	 tmp->realVal = readInReal;
	 expectationMode = kExpectOperator;
	 return token;
	 
      case kVariable:
	 if ( readInNoPrefix )
	    name = ( defaultVariablePrefix + name );
	 tmp = new ExpressionTreeNode( parent, name, token,
				 ExpressionTreeNode::kInsertNewChild, pos );

	 expectationMode = kExpectOperator;
	 return token;
	 
      case kFunction:
	 if ( readInNoPrefix )
	    name = ( defaultFunctionPrefix + name );
	 tmp = new ExpressionTreeNode( parent, name, token,
				       ExpressionTreeNode::kInsertNewChild, pos );
	 
	 // read in the "("
	 tmpToken = getExpressionToken( master, pos, name );
	 assert( tmpToken == kParenOpen );
	 parenDepth.push_back( kRoundParen );
	 
	 // make a subtree from this level
	 tmpToken = makeTree( master, tmp, pos, expectationMode );
	 if ( tmpToken < kErrorSeparator )
	    return tmpToken;
	 
	 // after the closing paren
	 expectationMode = kExpectOperator;
	 return tmpToken;
	 
      case kParenOpen:
	 parenDepth.push_back( kRoundParen );
	 tmp = new ExpressionTreeNode( parent, mapOpName( name ), kFunction,
				       ExpressionTreeNode::kInsertNewChild, pos );
	 
	 // make a subtree from this level
	 expectationMode = kExpectExpression;
	 tmpToken = makeTree( master, tmp, pos, expectationMode );
	 if ( tmpToken < kErrorSeparator )
	    return tmpToken;
	 
	 // after the closing paren
	 expectationMode = kExpectOperator;
	 return tmpToken;
	 
      case kParenClose:
//  	 if ( parenDepth.back() == kColonParen )
//  	    parenDepth.pop_back();
	 
	 if ( parent == NULL  ||  parenDepth.empty()  ||
	      ( parenDepth.back() != kRoundParen ) )
	    return kUnbalancedParens;
	 parenDepth.pop_back();
	 
	 // pop up from this subtree
	 expectationMode = kPopUpTree;
	 return token;
	 
      case kSquareParenOpen:
	 parenDepth.push_back( kSquareParen );
	 assert( parent  &&  parent->lastChild() );
	 
	 tmp = new ExpressionTreeNode( parent, mapOpName( name ), kFunction,
				       ExpressionTreeNode::kAboveLastChild, pos );
	 
	 // make a subtree for this level
	 expectationMode = kExpectExpression;
	 tmpToken = makeTree( master, tmp, pos, expectationMode );
	 if ( tmpToken < kErrorSeparator )
	    return tmpToken;
	 
	 // after the closing square paren
	 expectationMode = kExpectOperator;
	 return tmpToken;
	 
      case kSquareParenClose:
	 if ( parent == NULL  ||  ( parenDepth.back() != kSquareParen ) )
	    return kUnbalancedParens;
	 parenDepth.pop_back();
	 
	 // pop up from this subtree
	 expectationMode = kPopUpTree;
	 return token;
	 
//        case kColon:
//  	 if ( parenDepth.back() == kColonParen )
//  	    return kIllegalCombination;
//  	 parenDepth.push_back( kColonParen );
//  	 assert( parent  &&  parent->lastChild() );
	 
//  	 tmp = new ExpressionTreeNode( parent, name, token,
//  				       ExpressionTreeNode::kAboveLastChild );
	 
//  	 // make a subtree from this level
//  	 expectationMode = kExpectExpression;
//  	 tmpToken = makeTree( master, tmp, pos, expectationMode );
//  	 if ( tmpToken < kErrorSeparator )
//  	    return tmpToken;

//  	 if ( tmpToken == kComma )
//  	    expectationMode = kExpectExpression;
//  	 else if ( tmpToken == kParenClose )
//  	    expectationMode = kExpectOperator;
//  	 else
//  	    assert( false );
//  	 return tmpToken;
	 
      case kComma:
//  	 if ( parenDepth.back() == kColonParen )
//  	 {
//  	    parenDepth.pop_back();
//  	    expectationMode = kPopUpTree;
//  	    return kComma;
//  	 }
//  	 // else this was not a labled argument
	 expectationMode = kExpectExpression;
	 return token;
	 
      case kPreunaryL35:        // "!" as in "not"
      case kPreunaryL9:         // "+" or "-" (sign for numbers or variables)
	 // don't worry about operator precidence for preunary operators
	 tmp = new ExpressionTreeNode( parent, mapOpName( name ), token,
				       ExpressionTreeNode::kInsertNewChild, pos );

	 // make a subtree from this level
	 expectationMode = kExpectExpression;
	 tmpToken = makeTree( master, tmp, pos, expectationMode );
	 if ( tmpToken < kErrorSeparator )
	    return tmpToken;

	 // after the sub-expression, don't change exexpectationMode,
	 // it might be kPopUpTree
	 return tmpToken;

      case kPostunaryL95:       // "!" as in "factorial"
	 if ( parent->getType() > kOperatorSeparator  &&
	      parent->getType() > token )
	    return processToken( master, parent->getParent(), pos, token, name,
				 expectationMode );

	 new ExpressionTreeNode( parent, mapOpName( name ), token,
				 ExpressionTreeNode::kAboveLastChild, pos );
	 expectationMode = kExpectOperator;
	 return token;

      case kBinaryL1:           // ":" for argument label delimiting
      case kBinaryL2:           // "||" as in "or"
      case kBinaryL3:           // "&&" as in "and"
      case kBinaryL4:           // ":=" for assignment
      case kBinaryL5:           // "!=" "==" ">" "<" ">=" and "<="
      case kBinaryL6:           // "+" "-" as in "add" and "subtract"
      case kBinaryL7:           // "*" "/" "%" as in "mult" "div" and "mod"
      case kBinaryL8:           // "^" as in "exponentiate"
      case kBinaryL97:          // "." for getting members of an object
	 if ( parent->getType() > kOperatorSeparator )
	 {
	    if ( !strcmp( name.c_str(), "^" ) )
	    {
	       if ( parent->getType() > token )
		  return processToken( master, parent->getParent(), pos, token, name,
				       expectationMode );
	    }

	    else if ( !strcmp( name.c_str(), ":=" ) )
	    {
	       if ( parent->getType() > token )
		  return processToken( master, parent->getParent(), pos, token, name,
				       expectationMode );
	    }

	    else
	    {
	       if ( parent->getType() >= token )
		  return processToken( master, parent->getParent(), pos, token, name,
				       expectationMode );
	    }
	 }

	 tmp = new ExpressionTreeNode( parent, mapOpName( name ), token,
				       ExpressionTreeNode::kAboveLastChild, pos );

	 // make a right-subtree from this level
	 expectationMode = kExpectExpression;
	 tmpToken = makeTree( master, tmp, pos, expectationMode );
	 if ( tmpToken < kErrorSeparator )
	    return tmpToken;
	 
	 // after the sub-expression, don't change expectationMode,
	 // it might be kPopUpToken
	 return tmpToken;
	 
      case kQuote:
	 // read in the string
	 tmpToken = getPlainStrToken( master, pos, name );
	 if ( tmpToken < kErrorSeparator )
	    return tmpToken;
	 assert( tmpToken == kPlainString );
	 
	 new ExpressionTreeNode( parent, name, tmpToken,
				 ExpressionTreeNode::kInsertNewChild, pos );
	 
	 // read in the closing quote
	 tmpToken = getExpressionToken( master, pos, name );
	 assert( tmpToken == kQuote );
	 
	 expectationMode = kExpectOperator;
	 return tmpToken;
	 
      case kDoubleQuote:
	 // read in the string
	 tmpToken = getFormattedStrToken( master, pos, name );
	 if ( tmpToken < kErrorSeparator )
	    return tmpToken;
	 assert( tmpToken == kFormattedString );
	 
	 new ExpressionTreeNode( parent, name, tmpToken,
				 ExpressionTreeNode::kInsertNewChild, pos );
	 
	 // read in the closing quote
	 tmpToken = getExpressionToken( master, pos, name );
	 assert( tmpToken == kDoubleQuote );
	    
	 expectationMode = kExpectOperator;
	 return tmpToken;
      }
}
