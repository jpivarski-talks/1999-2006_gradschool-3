#if !defined(INTERPRETER_H)
#define INTERPRETER_H

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string>
#include <vector>
#include <map>
#include "parser.h"

//      START              TYPE

//       b_                boolean
//       i_                integer
//       r_                real
//       s_                string

//       c_                complex
//       u_                uncertain real

//       d_                directory (structure)

//       h_                1-D histogram
//       h2_               2-D histogram
//       hp_               profile histogram
//       n_                row-wise ntuple
//       nc_               column-wise ntuple

//       v?_               vector (array) of type "?"
//       t?_               tree of type "?"
//       m?_               map (point-by-point function, interpolated if
//                         real, complex, uncertain)

//       f_                function (as much is evaluated as possible)
//                     (the prefix for a constant function need not be typed)
//       l_                function (link) where evaluation is postponed

class Interpreter;
class Memory;
class Object;
typedef Object* ObjPtr;
struct RVal
{
      ObjPtr object;
      bool stored;
};
typedef RVal* RValPtr;

class Object
{
   public:
      typedef enum {
	 kBoolean,
	 kInteger,
	 kReal,
	 kString,
	 kComplex,
	 kUncertain,
	 
	 kDirectory,
	 
	 kHistogram,
	 k2DHistogram,
	 kProfileHistogram,
	 kNtuple,
	 kColumnNtuple,
	 
	 kVectorOf,
	 kTreeOf,
	 kMapOf,

	 kFunction,
	 kLink
      } Type;

      // The sole constructor and destructor
      Object( Type _type );
      ~Object();

      Type getType();

///////////////////////////////////// Functions which assume type boolean
   public:
      void b_set( bool val );
      bool b_get();
      string b_print();

   private:

///////////////////////////////////// Functions which assume type integer
   public:
      void i_set( int val );
      int i_get();
      string i_print();

   private:

///////////////////////////////////// Functions which assume type real
   public:
      void r_set( double val );
      double r_get();
      string r_print();

   private:

///////////////////////////////////// Functions which assume type string
   public:

   private:

///////////////////////////////////// Functions which assume type complex
   public:

   private:

///////////////////////////////////// Functions which assume type uncertain
   public:

   private:

///////////////////////////////////// Functions which assume type directory
   public:

   private:

///////////////////////////////////// Functions which assume type histogram
   public:

   private:

///////////////////////////////////// Functions which assume type 2D-histogram
   public:

   private:

///////////////////////////////////// Functions which assume type profile hist
   public:

   private:

///////////////////////////////////// Functions which assume type ntuple
   public:

   private:

///////////////////////////////////// Functions which assume type column ntuple
   public:

   private:

///////////////////////////////////// Functions which assume type vector
   public:

   private:

///////////////////////////////////// Functions which assume type tree
   public:

   private:

///////////////////////////////////// Functions which assume type map
   public:

   private:

///////////////////////////////////// Functions which assume type function
   public:

   private:

///////////////////////////////////// Functions which assume type link
   public:

   private:

///////////////////////////////////// The two words of data
   private:
      Type type;   // never changes--- is only set when constructed

      void* data;  // this word of data is recast as whatever is needed
                   // (the interpretation depends on "type".
};

class Interpreter
{
   public:
      typedef enum {
	 kOk,
	 kBadVariablePrefix,
	 kUndeclaredVariable,
	 kUndeclaredFunction,
	 kAssignmentDisagreement,
	 kBadArgumentList,
	 kNestedColons,
	 kNotImplemented
      } Status;

      Interpreter();
      ~Interpreter();

      Status interpret( ExpressionTreeNode* tree, RValPtr& retVal );
      // will need to add an ignorelist to this, for interpreting
      // function and link assignment lists

      void printErrorString( int indent );
      void collectGarbage();
   private:
      bool readprefix( string& name, int& pos, Object::Type& type );

      void pointout( int pos, int skip );

      Memory* memory;

      int stopPos;
      Status stopStatus;
      vector< RValPtr > tmp_retvals;
};

class Memory
{
   public:
      ~Memory();
      void store( string& name, ObjPtr object );
      bool retrieve( string& name, ObjPtr& object );
   private:
      map< string, ObjPtr > data;
};

class JF_Boolean
{
   public:
      bool value;
   private:
};

class JF_Integer
{
   public:
      int value;
   private:
};

class JF_Real
{
   public:
      double value;
   private:
};

class JF_String
{
   public:
//      JF_String();
   private:
};

class JF_Complex
{
   public:
//      JF_Complex();
   private:
};

class JF_Uncertain
{
   public:
//      JF_Uncertain();
   private:
};

class JF_Directory
{
   public:
//      JF_Directory();
   private:
};

class JF_Histogram
{
   public:
//      JF_Histogram();
   private:
};

class JF_2DHistogram
{
   public:
//      JF_2DHistogram();
   private:
};

class JF_ProfileHistogram
{
   public:
//      JF_ProfileHistogram();
   private:
};

class JF_Ntuple
{
   public:
//      JF_Ntuple();
   private:
};

class JF_ColumnNtuple
{
   public:
//      JF_ColumnNtuple();
   private:
};

class JF_Vector
{
   public:
//      JF_Vector();
   private:
};

class JF_Tree
{
   public:
//      JF_Tree();
   private:
};

class JF_Map
{
   public:
//      JF_Map();
   private:
};

class JF_Function
{
   public:
//      JF_Function();
   private:
};

class JF_Link
{
   public:
//      JF_Link();
   private:
};

#endif /* INTERPRETER_H */
