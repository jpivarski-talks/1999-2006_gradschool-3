#if !defined(HBOOK_INTERFACE)
#define HBOOK_INTERFACE

// constants, enums and typedefs
typedef int        FInteger;
typedef float      FReal;
typedef double     FDouble;
typedef bool       FLogical;
typedef short      FLength;
typedef char       FChar ;
typedef char       FCharacter ;

#ifdef __cplusplus
extern "C"
{
#endif

extern void hbookn_( const FInteger* pIdentifier, const FChar* pTitle,
		     const FInteger* pNumberItems , const FChar* pTopdir,
		     const FInteger* pChunkSize, const FChar* pLabels,
		     const FInteger aLenTitle, const FInteger aLenTopdir,
		     const FInteger aLenOneLabel ) ;
extern void hbook1_( const FInteger* pIdentifier, const FChar* pTitle,
		     const FInteger* pNumberBins , const FReal* pLowEdge,
		     const FReal* pHighEdge, const FReal* pWidth,
		     const FInteger aLenTitle ) ;
extern void hbook2_( const FInteger* pIdentifier, const FChar* pTitle,
		     const FInteger* pXNumberBins , const FReal* pXLowEdge,
		     const FReal* pXHighEdge, const FInteger* pYNumberBins ,
		     const FReal* pYLowEdge, const FReal* pYHighEdge,
		     const FReal* pWidth, const FInteger aLenTitle ) ;
extern void hbprof_( const FInteger* pIdentifier, const FChar* pTitle,
		     const FInteger* pNumberBins , const FReal* pLowEdgeX,
		     const FReal* pHighEdgeX, const FReal* pMinimumY,
		     const FReal* pMaximumY, const FChar* pChopt,
		     const FInteger aLenTitle, const FInteger aLenChopt) ;
extern void hfn_(    const FInteger* pIdentifier, const FReal* pEntry ) ;
extern void hf1_(    const FInteger* pIdentifier, const FReal* pEntry,
		     const FReal* pWeight ) ;
extern void hf2_(    const FInteger* pIdentifier, const FReal* pXEntry,
		     const FReal* pYEntry, const FReal* pWeight ) ;
extern void hff1_(   const FInteger* pIdentifier, const FInteger* pHistAddress,
		     const FReal* pEntry, const FReal* pWeight ) ;
extern void hff2_(   const FInteger* pIdentifier, const FInteger* pHistAddress,
		     const FReal* pXEntry, const FReal* pYEntry, 
		     const FReal* pWeight ) ;
extern void hfill_(  const FInteger* pIdentifier, const FReal* pXEntry,
		     const FReal* pYEntry, const FReal* pWeight ) ;
extern void hrend_(  const FChar* pTopdir, const FInteger aLenTopdir ) ;
extern void hropen_( const FInteger* pLun, const FChar* pTopdir,
		     const FChar* pFilename, const FChar* pChopt,
		     const FInteger* pLrec, FInteger* pIstat,
		     const FInteger aLenTopdir, const FInteger aLenFilenam,
		     const FInteger aLenChopt ) ;
extern void hrout_(  const FInteger* pIdentifier, FInteger* pIcycle,
		     const FChar* pChopt, const FInteger aLenChopt ) ;
extern void hcdir_(  const FChar* pTopdir, const FChar* pChopt,
		     const FInteger aLenTopdir, const FInteger aLenChopt ) ;
extern void hmdir_(  const FChar* pTopdir, const FChar* pChopt,
		     const FInteger aLenTopdir, const FInteger aLenChopt ) ;
extern FLogical hexist_( const FInteger* aIdentifier ) ;

// Arithmetic Operation function
extern void hopera_( const FInteger* pIdentifier1, const FChar* pChoper,
		     const FInteger* pIdentifier2, FInteger* pIdentifier3,
		     const FReal* pScale1, const FReal* pScale2, 
		     const FInteger aLenChoper );

extern void hscale_( const FInteger* pIdentifier1, const FReal* pScale );

extern void hcopy_( const FInteger* pIdentifier1, FInteger* pIdentifier2, 
		    const FChar* pTitle, const FInteger aLenTitle );
// Global Error Filling
extern void hpake_( const FInteger* pIdentifier, const FReal* pErrorArray ); 

// Channel value return functions
extern FReal hi_( const FInteger* pIdentifier, 
		  const FInteger* pChannelNumber );

extern FReal hij_( const FInteger* pIdentifier, 
		   const FInteger* pChannelNumber1,
		   const FInteger* pChannelNumber2 );

extern FReal hie_( const FInteger* pIdentifier, 
		   const FInteger* pChannelNumber );

extern FReal hsum_( const FInteger* pIdentifier );

extern FReal hmin_( const FInteger* pIdentifier );

extern FReal hmax_( const FInteger* pIdentifier );

extern void hbookinit_( void ) ;
#ifdef __cplusplus
}
#endif

#endif /* HBOOK_INTERFACE */
