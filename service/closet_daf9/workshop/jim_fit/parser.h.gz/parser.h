#if !defined(PARSER_H)
#define PARSER_H

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string>
#include <vector>
#include "commandline.h"

class ExpressionTreeNode;
typedef ExpressionTreeNode* ExpNodePtr;
class ExpressionTree;

typedef enum {
   kProgramError,
   kUnknownToken,
   kIllegalCombination,
   kBadlyExpressedNumber,
   kUnclosedString,
   kUnbalancedParens,
   kErrorSeparator,
   kBoolean,
   kInteger,
   kReal,
   kVariable,
   kFunction,
   kParenOpen,
   kParenClose,
   kSquareParenOpen,
   kSquareParenClose,
   kQuote,
   kDoubleQuote,
//   kColon,
   kComma,
   kPlainString,
   kFormattedString,
   kCommentStart,
   kNothing,
   kOperatorSeparator,
   kBinaryL1,           // ":" for argument label delimiting
   kBinaryL2,           // "||" as in "or"
   kBinaryL3,           // "&&" as in "and"
   kPreunaryL35,        // "!" as in "not"
   kBinaryL4,           // ":=" for assignment
   kBinaryL5,           // "!=" "==" ">" "<" ">=" and "<="
   kBinaryL6,           // "+" "-" as in "add" and "subtract"
   kBinaryL7,           // "*" "/" "%" as in "mult" "div" and "mod"
   kBinaryL8,           // "^" as in "exponentiate"
   kPreunaryL9,         // "+" or "-" (sign for numbers or variables)
   kPostunaryL95,       // "!" as in "factorial"
   kBinaryL97           // "." for getting members of an object
} TokenType;

class ExpressionTreeNode
{
   public:
      typedef enum {
	 kNewTree,
	 kInsertNewChild,
	 kAboveLastChild
      } InsertionMode;

      ExpressionTreeNode( ExpNodePtr _parent, string& _name,
			  TokenType _type, InsertionMode mode, int pos );
      ExpressionTreeNode( ExpNodePtr _parent, const char* _name,
			  TokenType _type, InsertionMode mode, int pos );
      ~ExpressionTreeNode();

      ExpNodePtr getParent();
      string getName();
      string& getNameRef();
      TokenType getType();
      int getPos();
      ExpNodePtr firstChild();
      ExpNodePtr lastChild();
      int numChildren();
      ExpNodePtr addChild( ExpNodePtr _child );
      ExpNodePtr replaceLastChild( ExpNodePtr to );
      vector< ExpNodePtr > getChildren();
      void killChildren();
      void killProgenity();
      void printDiagnostic();
      void print();

      bool boolVal;
      int intVal;
      double realVal;

   private:
      void setUp( ExpNodePtr _parent, TokenType _type,
		  InsertionMode mode, int pos );

      ExpNodePtr parent;
      string name;
      TokenType type;
      int nodePos;

      vector< ExpNodePtr > children;
};

class ExpressionTree
{
   public:
      typedef enum {
	 kRoundParen,
	 kSquareParen //,
//	 kColonParen
      } ParenDepthType;

      typedef enum {
	 kExpectExpression,
	 kExpectOperator,
	 kExpectPlainStr,
	 kExpectFormattedStr,
	 kPopUpTree
      } ExpectationType;

      ExpressionTree( string& master );
      ~ExpressionTree();
      bool valid();
      void print();
      void printErrorString( int indent );
      ExpNodePtr getRoot();
   private:
      TokenType getExpressionToken( string& master, int& pos, string& name );
      TokenType getOperatorToken( string& master, int& pos, string& name );
      TokenType getPlainStrToken( string& master, int& pos, string& name );
      TokenType getFormattedStrToken( string& master, int& pos, string& name );

      TokenType getToken( string& master, int& pos, string& name,
			  ExpectationType expectationMode );
      char* mapOpName( string& name );
      TokenType makeTree( string& master, ExpNodePtr parent, int& pos,
			  ExpectationType& expectationMode );
      TokenType processToken(
	 string& master, ExpNodePtr parent, int& pos, TokenType token,
	 string& name, ExpectationType& expectationMode );

      void pointout( int pos, int skip );

      TokenType finishState;
      int pos;
      ExpNodePtr root;
      vector< ParenDepthType > parenDepth;

      // All of the following are only meaningful IMMEDIATELY after
      // getting a token.
      bool readInBool;
      int readInInt;
      double readInReal;

      bool readInNoPrefix;
      const string defaultVariablePrefix;
      const string defaultFunctionPrefix;
};

#endif /* PARSER_H */
