#if !defined(COMMANDLINE_H)
#define COMMANDLINE_H

#include <stdio.h>
#include <string>
#include <vector>

typedef char** CPPFunction();

#if defined(__cplusplus)
extern "C"
{
#endif

void rl_initialize();
char* readline( const char* iPrompt );
void using_history();
int history_expand(char *, char **);
void add_history();
char** completion_matches();

char* xmalloc();

#if defined(__cplusplus)
}
#endif

char** tabbing_completion( char* text, int start, int end );
char* tabbing_generator( char* text, int state );
char* tabbing_dupstr( char* s );

#endif /* COMMANDLINE_H */
