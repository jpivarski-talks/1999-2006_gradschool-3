#if !defined(INTERPRETER_H)
#define INTERPRETER_H

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string>
#include <vector>
#include <map>
#include "parser.h"

//      START              TYPE

//       b_                boolean
//       i_                integer
//       r_                real
//       s_                string

//       c_                complex
//       u_                uncertain real

//       d_                directory (structure)

//       h_                1-D histogram
//       h2_               2-D histogram
//       hp_               profile histogram
//       n_                row-wise ntuple
//       nc_               column-wise ntuple

//       v?_               vector (array) of type "?"
//       t?_               tree of type "?"
//       m?_               map (point-by-point function, interpolated if
//                         real, complex, uncertain)

//       f_                function (as much is evaluated as possible)
//                     (the prefix for a constant function need not be typed)
//       l_                function (link) where evaluation is postponed

class Memory;

class Object
{
   public:
      typedef enum {
	 kBoolean,
	 kInteger,
	 kReal,
	 kString,
	 kComplex,
	 kUncertain,
	 
	 kDirectory,
	 
	 kHistogram,
	 k2DHistogram,
	 kProfileHistogram,
	 kNtuple,
	 kColumnNtuple,
	 
	 kVectorOf,
	 kTreeOf,
	 kMapOf,

	 kFunction,
	 kLink
      } Type;
      
      Object( Type _type );

      Type getType();
      string printType();
      virtual string print() = 0;
      virtual void del() = 0;

      virtual bool b_set( bool _value );
      virtual bool b_get( bool& _value );

      virtual bool i_set( int _value );
      virtual bool i_get( int& _value );

      virtual bool r_set( double _value );
      virtual bool r_get( double& _value );

   private:
      Type type;
};

class ObjectBoolean : public Object
{
   public:
      ObjectBoolean();

      string print();
      void del();

      bool b_set( bool _value );
      bool b_get( bool& _value );
   private:
      bool value;
};

class ObjectInteger : public Object
{
   public:
      ObjectInteger();

      string print();
      void del();

      bool i_set( int _value );
      bool i_get( int& _value );
   private:
      int value;
};

class ObjectReal : public Object
{
   public:
      ObjectReal();

      string print();
      void del();

      bool r_set( double _value );
      bool r_get( double& _value );
   private:
      double value;
};
typedef Object* ObjPtr;

struct ReturnValue
{
      Object* object;
      bool stored;
};

class Interpreter
{
   public:
      typedef enum {
	 kOk,
	 kBadVariablePrefix,
	 kUndeclaredVariable,
	 kUndeclaredFunction,
	 kAssignmentDisagreement,
	 kBadArgumentList,
	 kNestedColons,
	 kNotImplemented
      } Status;

      Interpreter();
      ~Interpreter();

      Status interpret( ExpressionTreeNode* tree, ReturnValue& retVal );
      // will need to add an ignorelist to this, for interpreting
      // function and link assignment lists

      void printErrorString( int indent );
      void collectGarbage();
   private:
      bool readprefix( string& name, int& pos, Object::Type& type );

      void pointout( int pos, int skip );

      Memory* memory;

      int stopPos;
      Status stopStatus;
      vector< ReturnValue > tmp_retvals;
};

class Memory
{
   public:
      ~Memory();
      void store( string& name, ObjPtr object );
      bool retrieve( string& name, ObjPtr& object );
   private:
      map< string, ObjPtr > data;
};

#endif /* INTERPRETER_H */
