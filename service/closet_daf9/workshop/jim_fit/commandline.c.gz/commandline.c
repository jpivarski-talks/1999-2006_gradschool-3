#include "commandline.h"

extern "C" char* rl_line_buffer;
extern "C" int rl_attempted_completion_over;

vector< string > tabbing_names;

char* tabbing_dupstr( char* s )
{
   char *r;   
   r = xmalloc( strlen(s) + 1 );
   strcpy( r, s );
   return ( r );
}

char** tabbing_completion ( char* text, int start, int end )
{
   // ASCII 39 == singleQuote, ASCII 34 == doubleQuote
   // if it's quoted, it may be a filename
   if ( start != 0  &&  ( rl_line_buffer[ (start-1) ] == 39  ||
			  rl_line_buffer[ (start-1) ] == 34 )    )
   {
      rl_attempted_completion_over = 0;
      return (char**)NULL;
   }
   // If the string is not in a quotation or is at the beginning of a
   // line, it may be a variable.
   else
   {
      rl_attempted_completion_over = 1;
      return completion_matches( text, tabbing_generator );
   }
}

char* tabbing_generator( char* text, int state )
{
   static int len;
   static vector< string >::const_iterator iter;
   static vector< string >::const_iterator iter_end;
     
   /* If this is a new word to complete, initialize now.  This includes
      saving the length of TEXT for efficiency, and initializing the index
      variable to 0. */
   if ( state == 0 )
   {
      len = strlen( text );
      iter = tabbing_names.begin();
      iter_end = tabbing_names.end();
   }
     
   /* Return the next name which partially matches from the command list. */
   while ( iter != iter_end )
   {
      char* name = (char*)iter->c_str();
      iter++;
      if ( !strncmp( name, text, len ) )
  	 return ( tabbing_dupstr( name ) );
   }

   /* If no names matched, then return NULL. */
   return ((char *)NULL);
}
