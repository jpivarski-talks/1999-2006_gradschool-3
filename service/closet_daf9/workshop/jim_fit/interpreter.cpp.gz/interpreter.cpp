#include "interpreter.h"

extern vector< string > tabbing_names;

///////////////////////////////////////////////////// Object

Object::Object( Object::Type _type )
{
   type = _type;
}

Object::Type Object::getType()
{
   return type;
}

string Object::printType()
{
   switch ( type )
   {
      case kBoolean:
	 return string( "boolean" );
      case kInteger:
	 return string( "integer" );
      case kReal:	 
	 return string( "real" );
      case kString:	 
	 return string( "string" );
      case kComplex:	 
	 return string( "complex" );
      case kUncertain:	 
	 return string( "uncertain" );
			 
      case kDirectory:	 
	 return string( "directory" );
			 
      case kHistogram:	 
	 return string( "histogram" );
      case k2DHistogram: 
	 return string( "2D-histogram" );
      case kProfileHistogram:
	 return string( "profile histogram" );
      case kNtuple:	 
	 return string( "ntuple" );
      case kColumnNtuple:
	 return string( "column-wise ntuple" );

	 // later these three will go deeper into the stack for a full name
      case kVectorOf:	 
	 return string( "vector of " );
      case kTreeOf:	 
	 return string( "tree of " );
      case kMapOf:	 
	 return string( "map of" );
			 
      case kFunction:	 
	 return string( "function with return type " );
      case kLink:	 
	 return string( "link with return type " );
   }
}

bool Object::b_set( bool _value )  { return false; }
bool Object::b_get( bool& _value )  { return false; }

bool Object::i_set( int _value )  { return false; }
bool Object::i_get( int& _value )  { return false; }

bool Object::r_set( double _value )  { return false; }
bool Object::r_get( double& _value )  { return false; }

///////////////////////////////////////////////////// ObjectBoolean

ObjectBoolean::ObjectBoolean()
   : Object( kBoolean )
{ }

string ObjectBoolean::print()
{
   if ( value )
      return string( "true" );
   else
      return string( "false" );
}

void ObjectBoolean::del()
{ }

bool ObjectBoolean::b_set( bool _value )
{
   value = _value;
   return true;
}

bool ObjectBoolean::b_get( bool& _value )
{
   _value = value;
   return true;
}

///////////////////////////////////////////////////// ObjectInteger

ObjectInteger::ObjectInteger()
   : Object( kInteger )
{ }

string ObjectInteger::print()
{
   char tmp_char[ 30 ];
   sprintf( tmp_char, "%d", value );
   return string( tmp_char );
}

void ObjectInteger::del()
{ }

bool ObjectInteger::i_set( int _value )
{
   value = _value;
   return true;
}

bool ObjectInteger::i_get( int& _value )
{
   _value = value;
   return true;
}

///////////////////////////////////////////////////// ObjectReal

ObjectReal::ObjectReal()
   : Object( kReal )
{ }

string ObjectReal::print()
{
   char tmp_char[ 30 ];
   sprintf( tmp_char, "%g", value );
   return string( tmp_char );
}

void ObjectReal::del()
{ }

bool ObjectReal::r_set( double _value )
{
   value = _value;
   return true;
}

bool ObjectReal::r_get( double& _value )
{
   _value = value;
   return true;
}

///////////////////////////////////////////////////// Interpreter

Interpreter::Interpreter()
{
   memory = new Memory();
   stopPos = 0;
   stopStatus = kOk;
}

Interpreter::~Interpreter()
{
   collectGarbage();
   delete memory;
}

Interpreter::Status Interpreter::interpret( ExpressionTreeNode* tree, ReturnValue& retVal )
{
   string name( tree->getName() );
   TokenType token = tree->getType();
   stopPos = tree->getPos();
   stopStatus = kOk;

   // Terminal types
   if ( token == kBoolean      ||
	token == kInteger      ||
	token == kReal         ||
        token == kPlainString  ||
        token == kFormattedString )
   {
      switch ( token )
      {
	 case kBoolean:
	    retVal.object = new ObjectBoolean();
	    retVal.object->b_set( tree->boolVal );
	    break;
	    
	 case kInteger:
	    retVal.object = new ObjectInteger();
	    retVal.object->i_set( tree->intVal );
	    break;
	    
	 case kReal:
	    retVal.object = new ObjectReal();
	    retVal.object->r_set( tree->realVal );
	    break;

	 case kPlainString:
	 case kFormattedString:
//  	    retVal->object = new Object( Object::kString );
//  	    retVal->object->s_set( tree->realVal );
	    break;
      }
      retVal.stored = false;
      tmp_retvals.push_back( retVal );
      return stopStatus = kOk;
   }

   // if variable exists, this is resolved and is a terminal type also
   else if ( token == kVariable )
   {
      int pos = 0;
      Object::Type type;
      if ( ! readprefix( name, pos, type ) )
	 return stopStatus = kBadVariablePrefix;

      ObjPtr object;
      if ( memory->retrieve( name, object ) )
      {
	 retVal.object = object;
	 retVal.stored = true;
	 // no reason to push this into tmp_retvals
	 return stopStatus = kOk;
      }
      
      return stopStatus = kUndeclaredVariable;
   }

   else if ( token == kFunction      ||
	     token == kBinaryL1      ||
	     token == kBinaryL2      ||
	     token == kBinaryL3      ||
	     token == kPreunaryL35   ||
	     token == kBinaryL4      ||
	     token == kBinaryL5      ||
	     token == kBinaryL6      ||
	     token == kBinaryL7      ||
	     token == kBinaryL8      ||
	     token == kPreunaryL9    ||
	     token == kPostunaryL95  ||
	     token == kBinaryL97        )
   {
      // handle assignment specially--- there is no F_assign function in memory
      if ( !strcmp( name.c_str(), "F_assign" ) )
      {
	 vector< ExpNodePtr > children = tree->getChildren();
	 
	 if ( children.size() != 2 )
	    return stopStatus = kBadArgumentList;

	 // get the LHS (this will need to be spiffier for function
	 // and link assignment
	 int pos = 0;
	 Object::Type type;
	 name = children[0]->getName(); // now "name" is the LHS variable name
 	 if ( ! readprefix( name, pos, type ) )
	 {
	    stopPos = children[0]->getPos();
	    return stopStatus = kBadVariablePrefix;
	 }

	 if ( type == Object::kFunction )
	 {
	    return stopStatus = kNotImplemented;
	 } // end if LHS is a function
	 else if ( type == Object::kLink )
	 {
	    return stopStatus = kNotImplemented;
	 } // end if LHS is a link
	 else
	 {
	    // evaluate the RHS
	    ReturnValue tmpRetVal;
	    stopStatus = interpret( children[1], tmpRetVal );
	    if ( stopStatus != kOk )
	       return stopStatus;

	    // in case of error, be pointing at the assignment
	    stopPos = tree->getPos();

	    // check for type disagreement
	    if ( type != tmpRetVal.object->getType() )
	       return stopStatus = kAssignmentDisagreement;

	    // store the value and be sure it doesn't get garbage collected
	    memory->store( name, tmpRetVal.object );
	    tmpRetVal.stored = true;
	    retVal = tmpRetVal;
	    return stopStatus = kOk;
	 } // end if LHS is a variable
      } // end if function is "F_assign"

      else  // other functions
      {
	 return stopStatus = kNotImplemented;
      }

   } // end if token is a function
   
   else
      assert( 0 );
}

void Interpreter::printErrorString( int indent )
{
   pointout( stopPos, indent );

   switch ( stopStatus )
   {
      case kOk:
	 break;
	 
      case kBadVariablePrefix:
	 printf( "Variable has a bad prefix.\n" );
	 break;

      case kUndeclaredVariable:
	 printf( "Undeclared variable.\n" );
	 break;

      case kUndeclaredFunction:
	 printf( "Undeclared function.\n" );
	 break;

      case kAssignmentDisagreement:
	 printf( "The LHS and RHS of this assignment have different types.\n" );
	 break;

      case kBadArgumentList:
	 printf( "There is no version of this function which takes these arguments.\n" );
	 break;

      case kNestedColons:
	 printf( "Colons may only separate name:value pairs.\n" );
	 break;

      case kNotImplemented:
	 printf( "This has not yet been implemented.\n" );
	 break;
   }
}

void Interpreter::collectGarbage()
{
   while ( ! tmp_retvals.empty() )
   {
      ReturnValue tmp = tmp_retvals.back();

      if ( ! tmp.stored )
  	 tmp.object->del();

      tmp_retvals.pop_back();
   }
}

bool Interpreter::readprefix( string& name, int& pos, Object::Type& type )
{
   // This will need to be improved in the future, including the
   // argument return type to handle vectors, trees and maps
   if ( ! strncmp( name.c_str(), "b_", 2 ) )
      type = Object::kBoolean;
   else if ( ! strncmp( name.c_str(), "i_", 2 ) )
      type = Object::kInteger;
   else if ( ! strncmp( name.c_str(), "r_", 2 ) )
      type = Object::kReal;
   else if ( ! strncmp( name.c_str(), "s_", 2 ) )
      type = Object::kString;
   else if ( ! strncmp( name.c_str(), "c_", 2 ) )
      type = Object::kComplex;
   else if ( ! strncmp( name.c_str(), "u_", 2 ) )
      type = Object::kUncertain;
   else if ( ! strncmp( name.c_str(), "d_", 2 ) )
      type = Object::kDirectory;
   else if ( ! strncmp( name.c_str(), "h_", 2 ) )
      type = Object::kHistogram;
   else if ( ! strncmp( name.c_str(), "h2_", 3 ) )
      type = Object::k2DHistogram;
   else if ( ! strncmp( name.c_str(), "hp_", 3 ) )
      type = Object::kProfileHistogram;
   else if ( ! strncmp( name.c_str(), "n_", 2 ) )
      type = Object::kNtuple;
   else if ( ! strncmp( name.c_str(), "nc_", 3 ) )
      type = Object::kColumnNtuple;
   else if ( ! strncmp( name.c_str(), "v?_", 3 ) )   // no!
      type = Object::kVectorOf;
   else if ( ! strncmp( name.c_str(), "t?_", 3 ) )   // no!
      type = Object::kTreeOf;
   else if ( ! strncmp( name.c_str(), "m?_", 3 ) )   // no!
      type = Object::kMapOf;
   else if ( ! strncmp( name.c_str(), "f_", 2 ) )
      type = Object::kFunction;
   else if ( ! strncmp( name.c_str(), "l_", 2 ) )
      type = Object::kLink;
   else
      return false;
   return true;
}

void Interpreter::pointout( int pos, int skip )
{
   while ( skip > 0 )
   {
      printf( " " );
      skip--;
   }
   while ( pos > 0 )
   {
      printf( "-" );
      pos--;
   }
   printf( "^\n" );
}

///////////////////////////////////////////////////// Memory

Memory::~Memory()
{
   map< string, ObjPtr >::const_iterator iter;
   map< string, ObjPtr >::const_iterator iter_begin = data.begin();
   map< string, ObjPtr >::const_iterator iter_end = data.end();

   for ( iter = iter_begin;  iter != iter_end;  iter++ )
      iter->second->del();

//   data.clear();
}

void Memory::store( string& name, ObjPtr object )
{
   map< string, ObjPtr >::const_iterator iter;
   iter = data.find( name );
   if ( iter != data.end() )  // if this name has been found to exist
      iter->second->del();    // be sure there's no memory leak
   else
      tabbing_names.push_back( name );

   data[ name ] = object;
}

bool Memory::retrieve( string& name, ObjPtr& object )
{
   map< string, ObjPtr >::const_iterator iter;
   iter = data.find( name );
   if ( iter == data.end() )
      return false;
   object = iter->second;
   return true;
}

