#include <iostream>
#include <string>

int main()
{
   string a;
   return(0);
}
