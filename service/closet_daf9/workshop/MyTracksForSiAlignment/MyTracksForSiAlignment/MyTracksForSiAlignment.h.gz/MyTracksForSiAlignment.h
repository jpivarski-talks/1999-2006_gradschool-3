// -*- C++ -*-
#if !defined(MYTRACKSFORSIALIGNMENT_MYTRACKSFORSIALIGNMENT_H)
#define MYTRACKSFORSIALIGNMENT_MYTRACKSFORSIALIGNMENT_H
//
// Package:     <MyTracksForSiAlignment>
// Module:      MyTracksForSiAlignment
//
/**\class MyTracksForSiAlignment MyTracksForSiAlignment.h MyTracksForSiAlignment/MyTracksForSiAlignment.h
 
 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Thu Sep  6 11:33:53 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "Processor/Processor.h"
#include "HistogramInterface/HistogramPackage.h"

// forward declarations

class MyTracksForSiAlignment : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------

      // ------------ Constructors and destructor ----------------
      MyTracksForSiAlignment( void );                      // anal1 
      virtual ~MyTracksForSiAlignment();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( HIHistoManager& );                  

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      //virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      //virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      MyTracksForSiAlignment( const MyTracksForSiAlignment& );

      // ------------ assignment operator(s) ---------------------
      const MyTracksForSiAlignment& operator=( const MyTracksForSiAlignment& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (MyTracksForSiAlignment::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      // ------------ private const member functions -------------

      // ------------ data members -------------------------------

      // ------------ static data members ------------------------

};

// inline function definitions

#endif /* MYTRACKSFORSIALIGNMENT_MYTRACKSFORSIALIGNMENT_H */
