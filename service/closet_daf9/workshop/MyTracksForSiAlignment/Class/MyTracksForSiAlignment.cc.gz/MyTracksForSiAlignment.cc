// -*- C++ -*-
//
// Package:     MyTracksForSiAlignment
// Module:      MyTracksForSiAlignment
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Thu Sep  6 11:33:54 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "MyTracksForSiAlignment/MyTracksForSiAlignment.h"
#include "Experiment/report.h"
#include "Experiment/units.h"  // for converting to/from standard CLEO units

#include "DataHandler/Record.h"
#include "DataHandler/Frame.h"
#include "FrameAccess/extract.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"

#include "CleoDB/DBEventHeader.h"
#include "Navigation/NavTrack.h"
#include "C3cc/CcQedEvent.h"
#include "CLHEP/Vector/ThreeVector.h"
#include "TrackRoot/TRSubdetectorLists.h"

// STL classes
// You may have to uncomment some of these or other stl headers 
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "Processor.MyTracksForSiAlignment" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: processor.cc,v 1.17 2000/12/04 19:11:11 cdj Exp $";
static const char* const kTagString = "$Name: v03_06_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
MyTracksForSiAlignment::MyTracksForSiAlignment( void )               // anal1
   : Processor( "MyTracksForSiAlignment" )
{
   report( DEBUG, kFacilityString ) << "here in ctor()" << endl;

   // ---- bind a method to a stream -----
   // These lines ARE VERY IMPORTANT! If you don't bind the 
   // code you've just written (the "action") to a stream, 
   // your code won't get executed!

   bind( &MyTracksForSiAlignment::event,    Stream::kEvent );
   //bind( &MyTracksForSiAlignment::beginRun, Stream::kBeginRun );
   //bind( &MyTracksForSiAlignment::endRun,   Stream::kEndRun );

   // do anything here that needs to be done at creation time
   // (e.g. allocate resources etc.)

}

MyTracksForSiAlignment::~MyTracksForSiAlignment()                    // anal5
{
   report( DEBUG, kFacilityString ) << "here in dtor()" << endl;
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}

//
// member functions
//

// ------------ methods for beginning/end "Interactive" ------------
// --------------------------- init method -------------------------
void
MyTracksForSiAlignment::init( void )          // anal1 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in init()" << endl;

   // do any initialization here based on Parameter Input by User
   // (e.g. run expensive algorithms that are based on parameters
   //  specified by user at run-time)

}

// -------------------- terminate method ----------------------------
void
MyTracksForSiAlignment::terminate( void )     // anal5 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in terminate()" << endl;

   // do anything here BEFORE New Parameter Change
   // (e.g. write out result based on parameters from user-input)
 
}

// ---------------- standard place to book histograms ---------------
void
MyTracksForSiAlignment::hist_book( HIHistoManager& iHistoManager )
{
   report( DEBUG, kFacilityString ) << "here in hist_book()" << endl;

   // book your histograms here

}

// --------------------- methods bound to streams -------------------
ActionBase::ActionResult
MyTracksForSiAlignment::event( Frame& iFrame )          // anal3 equiv.
{
   report( DEBUG, kFacilityString ) << "here in event()" << endl;

   double event_curvature = 1.;
   HepVector3D event_momentum = HepVector3D( 0., 0., 0. );

   FAItem< DBEventHeader > header;
   extract( iFrame.record( Stream::kEvent ), header );
   report( DEBUG, kFacilityString ) << "using header" << endl;
   unsigned int run = header->run();
   unsigned int event = header->number();

   if ( run == 113347  ||
	run == 113455  ||
	run == 113560  ||
	run == 113668     )
      return ActionBase::kFailed;

   FATable< NavTrack > navtracks;
   extract( iFrame.record( Stream::kEvent ), navtracks );
   FATable< NavTrack >::const_iterator navtracks_iterator;
   FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
   FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();

   // I want exactly two good tracks
   if ( navtracks.size() != 2 )
      return ActionBase::kFailed;

   for( navtracks_iterator = navtracks_begin;
	navtracks_iterator != navtracks_end;
	navtracks_iterator++ )
   {
      // Get the Kalman-fitted track
      FAItem< TDKinematicFit > trackFit = navtracks_iterator->muonFit();
      if ( trackFit == NULL )
      {
	 report( EMERGENCY, kFacilityString )
	    << "muonFit is missing from the NavTrack!" << endl;
	 return ActionBase::kFailed;
      }

      // and the Kalman-fitted helix
      FAItem< TRHelixFit > trackHelix = navtracks_iterator->muonHelix();
      if ( trackHelix == NULL )
      {
	 report( EMERGENCY, kFacilityString )
	    << "muonHelix is missing from the NavTrack!" << endl;
	 return ActionBase::kFailed;
      }

      // Get its quality object
      FAItem< TRTrackFitQuality > trackQuality = navtracks_iterator->muonQuality();
      if ( trackQuality == NULL )
      {
	 report( EMERGENCY, kFacilityString )
	    << "muonQuality is missing from the NavTrack!" << endl;
	 return ActionBase::kFailed;
      }

      if ( trackQuality->fitAbort() )
	 return ActionBase::kFailed;

      // event curvature is negative (opposite charges)
      event_curvature *= trackHelix->curvature();
      // event momentum cut is 0.300
      event_momentum += trackFit->momentum();

      // both tracks satisfy:
      // mindr layers is 30
      // min rphi layers is 2
      // min z layers is 2
      // cotTheta cut is 1.25
      if ( ( trackQuality->numberSubdetectorHitLayers( TRSubdetectorLists::kDR3Axial ) +
	     trackQuality->numberSubdetectorHitLayers( TRSubdetectorLists::kDR3Stereo ) ) < 30  ||
	   trackQuality->numberSubdetectorHitLayers( TRSubdetectorLists::kSVR ) < 2             ||
	   trackQuality->numberSubdetectorHitLayers( TRSubdetectorLists::kSVZ ) < 2             ||
	   trackHelix->cotTheta() > 1.25                                                           )
	 return ActionBase::kFailed;
      
   } // end navtracks loop

   // event curvature is negative (opposite charges)
   if ( event_curvature > 0. )
      return ActionBase::kFailed;

   // event momentum cut is 0.300
   double xdiff2 = sqr( event_momentum.x() + 0.0261 );
   double ydiff2 = sqr( event_momentum.y() + 0.0003 );
   if ( ( xdiff2 + ydiff2 ) > 0.300 )
      return ActionBase::kFailed;

   return ActionBase::kPassed;
}

/*
ActionBase::ActionResult
MyTracksForSiAlignment::beginRun( Frame& iFrame )       // anal2 equiv.
{
   report( DEBUG, kFacilityString ) << "here in beginRun()" << endl;

   return ActionBase::kPassed;
}
*/

/*
ActionBase::ActionResult
MyTracksForSiAlignment::endRun( Frame& iFrame )         // anal4 equiv.
{
   report( DEBUG, kFacilityString ) << "here in endRun()" << endl;

   return ActionBase::kPassed;
}
*/

//
// const member functions
//

//
// static member functions
//
