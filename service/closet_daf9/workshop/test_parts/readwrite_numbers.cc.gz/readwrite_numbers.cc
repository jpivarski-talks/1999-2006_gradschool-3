#include <stdio.h>
#include <stdlib.h>

void main()
{
   printf( "sizeof( unsigned long ) = %d, sizeof( unsigned int ) = %d\n",
	   sizeof( unsigned long ), sizeof( unsigned int ) );

   FILE* file = NULL;
   int size = 1000;
   printf( "size = %d\n", size );

   // output section
   file = fopen( "numbers.bin", "wb" );
   fwrite( &size, sizeof( unsigned long ), 1, file );
   printf( "writing: " );
   for ( unsigned long i = 0;  i < size;  i++ )
   {
      fwrite( &i, sizeof( unsigned long ), 1, file );
      printf( "%d ", i );
   }
   printf( "\n" );

   fclose( file );

   // input section
   file = fopen( "numbers.bin", "rb" );
   unsigned long* buffer = NULL;
   unsigned long size2 = 0;
   fread( &size2, sizeof( unsigned long ), 1, file );
   printf( "read size2 = %d\n", size2 );
   buffer = (unsigned long *)( malloc( sizeof( unsigned long ) * size2 ) );
   int howmany = fread( buffer, sizeof( unsigned long ), size2, file );
   printf( "read %d numbers from file.\n", howmany );
   printf( "read: " );
   for ( unsigned long i = 0;  i < size;  i++ )
   {
      printf( "%d ", buffer[ i ] );
   }
   printf( "\n" );

   free( buffer );
   fclose( file );
}
