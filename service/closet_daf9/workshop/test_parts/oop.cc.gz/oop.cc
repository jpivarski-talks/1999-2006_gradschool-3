#include <string>
#include <iostream>
#include "oop.h"

void bookhist()
{
   m_HistListHead = new P1TMP_NGoodTracks( m_HistListHead, 1000 );
   m_HistListHead = new P1TMP_NBadTracks( m_HistListHead, 1001 );
}

void event()
{
   for( P1TMP_Histogram* current = m_HistListHead;
	current != NULL;
	current = current->GetNext() )
   {
      current->CalcAndFill( 7 );  // input comes from iFrame
   }
}

void main()
{
   bookhist();
   event();
   delete m_HistListHead; // actually in destructor of P1TrackMonProc3
}

// Generic Histogram Stuff

// P1TMP_Histogram::P1TMP_Histogram()
// {
//    cout << "(P1TMP_Histogram) Constructor does nothing at all.\n"; 
// }

P1TMP_Histogram::~P1TMP_Histogram()
{
   cout << "(P1TMP_Histogram) Deleting next one in the list.\n";
   delete m_NextHist;
}

void P1TMP_Histogram::LinkUp( P1TMP_Histogram* iOldHead )
{
   cout << "(P1TMP_Histogram) Just linking up the list.\n";
   m_NextHist = iOldHead;
}

// Histogram of the number of good tracks

P1TMP_NGoodTracks::P1TMP_NGoodTracks( P1TMP_Histogram* iOldHead,
				      int iId )
{
   cout << "(NGoodTracks) Book the histogram including specifics "
        << "about name, number of channels, id, etc. Then explicitly "
        << "call the P1TMP_Histogram constructor with iOldHead.\n";
   histpointer = 3; // given from the histogram class
   LinkUp( iOldHead );
}

int P1TMP_NGoodTracks::CalcAndFill( int input )
{
   cout << "(NGoodTracks) Use the input to calculate a value to put "
        << "into the histogram, and use histpointer to fill it.\n";
   return 0; // or ActionBase::kPassed
}

// Histogram of the number of bad tracks

P1TMP_NBadTracks::P1TMP_NBadTracks( P1TMP_Histogram* iOldHead,
				      int iId )
{
   cout << "(NBadTracks) Book the histogram including specifics "
        << "about name, number of channels, id, etc. Then explicitly "
        << "call the inherited linkup function with iOldHead.\n";
   histpointer = 4; // given from the histogram class
   LinkUp( iOldHead );
}

int P1TMP_NBadTracks::CalcAndFill( int input )
{
   cout << "(NBadTracks) Use the input to calculate a value to put "
        << "into the histogram, and use histpointer to fill it.\n";
   return 0; // or ActionBase::kPassed
}

