#include <iostream>

class P1TMP_Histogram;

void bookhist();
void event();

P1TMP_Histogram* m_HistListHead = NULL;
                          // Actually a member of the P1TMP class

class P1TMP_Histogram
{
   public:
      ~P1TMP_Histogram();
      P1TMP_Histogram* GetNext() const { return m_NextHist; }

      virtual int CalcAndFill( int input ) = 0;   // pure virtual
   protected:
      void LinkUp( P1TMP_Histogram* iOldHead );
   private:
      P1TMP_Histogram* m_NextHist;
};

class P1TMP_NGoodTracks : public P1TMP_Histogram
{
   public:
      P1TMP_NGoodTracks( P1TMP_Histogram* iOldHead, int iId );
      int CalcAndFill( int input );
   private:
      int histpointer; // actaully a HIHist1D pointer
};

class P1TMP_NBadTracks : public P1TMP_Histogram
{
   public:
      P1TMP_NBadTracks( P1TMP_Histogram* iOldHead, int iId );
      int CalcAndFill( int input );
   private:
      int histpointer; // actaully a HIHist1D pointer
};

