#include <iostream.h>
#include <math.h>

typedef bool DABoolean;

// May be used by individual histograms to do some statistics
#define P1TMP_TALLIER_NODE_SIZE 15
class Tallier_Node;
class Tallier
{
   public:
      Tallier();
      ~Tallier();
      void Enter( float iNewValue );
      int GetEntries() const { return m_Entries; }
      float GetTotal() const { return m_Total; }
      float Mean();
      float StdDev();
   private:
      Tallier_Node* m_Head;
      int m_Entries;
      float m_Total;
      float m_Mean;
      DABoolean m_MeanUpdated;
};
class Tallier_Node
{
   public:
      Tallier_Node( Tallier_Node* iOldHead );

      ~Tallier_Node();
      DABoolean Enter( float iNewValue );
      void StartIterate();
      DABoolean Iterate( float& Value );
   private:
      Tallier_Node* m_Next;
      int m_End;
      int m_Pointer;
      float m_Val[ P1TMP_TALLIER_NODE_SIZE ];
};
// end Tallier
