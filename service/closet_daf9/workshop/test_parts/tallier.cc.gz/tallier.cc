#include <iostream.h>
#include <math.h>
#include "tallier.h"

//////////// Tallier and Tallier_Node: for doing
          // calculations of mean and standard deviation

Tallier::Tallier()
{
   m_Head = NULL;
   m_Entries = 0;
   m_Total = 0.0;
   m_Mean = 0.0;
   m_MeanUpdated = false;
}

Tallier::~Tallier()
{
   delete m_Head;
}

void Tallier::Enter( float iNewValue )
{
   m_Entries++;
   m_Total += iNewValue;
   while ( m_Head == NULL  ||  ! m_Head->Enter( iNewValue ) )
   {
      m_Head = new Tallier_Node( m_Head );
   }
}

float Tallier::Mean()
{
   if ( m_MeanUpdated )
      return m_Mean;
   else
   {
      m_MeanUpdated = true;
      return ( m_Mean = m_Total / float( m_Entries ) );
   }
}

float Tallier::StdDev()
{
   float mean = Mean();
   float stdev = 0;
   float datum, diff;
   m_Head->StartIterate();
   while ( m_Head->Iterate( datum ) )
   {
      diff = datum - mean;
      stdev += diff * diff;
   }
   stdev /= ( m_Entries - 1 );
   stdev = sqrt( stdev );
   return stdev;
}

Tallier_Node::Tallier_Node( Tallier_Node* iOldHead )
{
   m_Next = iOldHead;
   m_End = 0;
}

Tallier_Node::~Tallier_Node()
{
   delete m_Next;
}

void Tallier_Node::StartIterate()
{
   m_Pointer = 0;
}

DABoolean Tallier_Node::Enter(
   float iNewValue )
{
   if ( m_End < P1TMP_TALLIER_NODE_SIZE )
   {
      m_Val[ m_End++ ] = iNewValue;
      return true;
   }
   else
      return false;
}

DABoolean Tallier_Node::Iterate(
   float& Value )
{
   if ( m_Pointer < m_End )
   {
      Value = m_Val[ m_Pointer++ ];
      return true;
   }
   else
      if ( m_Pointer == m_End  &&  m_Next != NULL )
      {
	 m_Pointer++;
	 m_Next->StartIterate();
	 return m_Next->Iterate( Value );
      }
      else
	 if ( m_Pointer > m_End )
	 {
	    return m_Next->Iterate( Value );
	 }
   return false;
}

void main()
{
   float datum;
    Tallier t;
    for ( int i = 1;
 	 i < 6280;
 	 i++ )
    {
       datum = sin(float(i)/100.);
       t.Enter( datum );
    }
    float mean = t.Mean();
    float stdev = t.StdDev();
    cout << "Mean is " << mean
 	<< " and Standard Deviation^2 is " << stdev*stdev
 	<< ".\n";
}
