// -*- C++ -*-
#if !defined(SIMOVEMEASURE_SIMOVEMEASURE_H)
#define SIMOVEMEASURE_SIMOVEMEASURE_H
//
// Package:     <SiMoveMeasure>
// Module:      SiMoveMeasure
//
/**\class SiMoveMeasure SiMoveMeasure.h SiMoveMeasure/SiMoveMeasure.h
 
 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Tue Sep 11 10:21:04 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "Processor/Processor.h"
#include "HistogramInterface/HistogramPackage.h"

#include "CommandPattern/Parameter.h"
#include <fstream>

// forward declarations

class SiMoveMeasure : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------

      // ------------ Constructors and destructor ----------------
      SiMoveMeasure( void );                      // anal1 
      virtual ~SiMoveMeasure();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( HIHistoManager& );                  

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      //virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      //virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      SiMoveMeasure( const SiMoveMeasure& );

      // ------------ assignment operator(s) ---------------------
      const SiMoveMeasure& operator=( const SiMoveMeasure& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (SiMoveMeasure::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      // ------------ private const member functions -------------

      // ------------ data members -------------------------------

      Parameter< string > m_directory;
      Parameter< string > m_placement;
      Parameter< DABoolean > m_suppressGlobal;
      Parameter< DABoolean > m_suppressLayer;
      Parameter< DABoolean > m_suppressLadder;

      ofstream m_ladderRphiFile[ 61 ];
      ofstream m_layerRphiFile[ 4 ];
      ofstream m_globalRphiFile;

      ofstream m_ladderZFile[ 61 ];
      ofstream m_layerZFile[ 4 ];
      ofstream m_globalZFile;

      unsigned int m_ladderRphiCount[ 61 ];
      unsigned int m_layerRphiCount[ 4 ];
      unsigned int m_globalRphiCount;

      unsigned int m_ladderZCount[ 61 ];
      unsigned int m_layerZCount[ 4 ];
      unsigned int m_globalZCount;
      

      // ------------ static data members ------------------------

};

// inline function definitions

#endif /* SIMOVEMEASURE_SIMOVEMEASURE_H */
