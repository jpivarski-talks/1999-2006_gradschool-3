// -*- C++ -*-
#if !defined(SIRUNOVERRAW_SIRUNOVERRAW_H)
#define SIRUNOVERRAW_SIRUNOVERRAW_H
//
// Package:     <SiRunOverRaw>
// Module:      SiRunOverRaw
//
/**\class SiRunOverRaw SiRunOverRaw.h SiRunOverRaw/SiRunOverRaw.h
 
 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Tue Aug 14 15:20:05 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "Processor/Processor.h"
#include "HistogramInterface/HistogramPackage.h"

// forward declarations

class SiRunOverRaw : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------

      // ------------ Constructors and destructor ----------------
      SiRunOverRaw( void );                      // anal1 
      virtual ~SiRunOverRaw();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( HIHistoManager& );                  

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      //virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      //virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      SiRunOverRaw( const SiRunOverRaw& );

      // ------------ assignment operator(s) ---------------------
      const SiRunOverRaw& operator=( const SiRunOverRaw& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (SiRunOverRaw::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      // ------------ private const member functions -------------

      // ------------ data members -------------------------------
      HIHist1D* m_rphi_clam_layer;
      HIHist1D* m_rphi_ladder;
      HIHist1D* m_rphi_sensor;

      HIHist2D* m_rphi_endview;
      HIHist2D* m_rphi_layer1_unwrapped;
      HIHist2D* m_rphi_layer2_unwrapped;
      HIHist2D* m_rphi_layer3_unwrapped;
      HIHist2D* m_rphi_layer4_unwrapped;

      HIHist1D* m_z_clam_layer;
      HIHist1D* m_z_ladder;
      HIHist1D* m_z_sensor;

      HIHist2D* m_z_endview;
      HIHist2D* m_z_layer1_unwrapped;
      HIHist2D* m_z_layer2_unwrapped;
      HIHist2D* m_z_layer3_unwrapped;
      HIHist2D* m_z_layer4_unwrapped;

      // ------------ static data members ------------------------

};

// inline function definitions

#endif /* SIRUNOVERRAW_SIRUNOVERRAW_H */
