// -*- C++ -*-
//
// Package:     SiRunOverRaw
// Module:      SiRunOverRaw
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Tue Aug 14 15:20:04 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "SiRunOverRaw/SiRunOverRaw.h"
#include "Experiment/report.h"
#include "Experiment/units.h"  // for converting to/from standard CLEO units

#include "DataHandler/Record.h"
#include "DataHandler/Frame.h"
#include "FrameAccess/extract.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"

#include "CleoDB/DBEventHeader.h"
#include "TrackRoot/TRSeedTrack.h"
#include "TrackFinder/SeedTrackSVRHitLattice.h"
#include "TrackFinder/SeedTrackSVZHitLattice.h"
#include "SiHits/CalibratedSVRphiHit.h"
#include "SiHits/CalibratedSVZHit.h"
#include "Lattice/Lattice.h"
#include "ASiStorePro/ASiStore.h"

// STL classes
// You may have to uncomment some of these or other stl headers 
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "Processor.SiRunOverRaw" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: processor.cc,v 1.18 2001/08/07 21:16:22 marsh Exp $";
static const char* const kTagString = "$Name: v03_07_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
SiRunOverRaw::SiRunOverRaw( void )               // anal1
   : Processor( "SiRunOverRaw" )
{
   report( DEBUG, kFacilityString ) << "here in ctor()" << endl;

   // ---- bind a method to a stream -----
   // These lines ARE VERY IMPORTANT! If you don't bind the 
   // code you've just written (the "action") to a stream, 
   // your code won't get executed!

   bind( &SiRunOverRaw::event,    Stream::kEvent );
   //bind( &SiRunOverRaw::beginRun, Stream::kBeginRun );
   //bind( &SiRunOverRaw::endRun,   Stream::kEndRun );

   // do anything here that needs to be done at creation time
   // (e.g. allocate resources etc.)

}

SiRunOverRaw::~SiRunOverRaw()                    // anal5
{
   report( DEBUG, kFacilityString ) << "here in dtor()" << endl;
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}

//
// member functions
//

// ------------ methods for beginning/end "Interactive" ------------
// --------------------------- init method -------------------------
void
SiRunOverRaw::init( void )          // anal1 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in init()" << endl;

   // do any initialization here based on Parameter Input by User
   // (e.g. run expensive algorithms that are based on parameters
   //  specified by user at run-time)

}

// -------------------- terminate method ----------------------------
void
SiRunOverRaw::terminate( void )     // anal5 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in terminate()" << endl;

   // do anything here BEFORE New Parameter Change
   // (e.g. write out result based on parameters from user-input)
 
}

// ---------------- standard place to book histograms ---------------
void
SiRunOverRaw::hist_book( HIHistoManager& iHistoManager )
{
   report( DEBUG, kFacilityString ) << "here in hist_book()" << endl;

   // book your histograms here

   m_rphi_clam_layer = iHistoManager.histogram(
      100, "RPHI -clamshell and layer", 7, -2.5, 4.5 );
   m_rphi_ladder = iHistoManager.histogram(
      110, "RPHI ladder", 61, 0.5, 61.5 );
   m_rphi_sensor = iHistoManager.histogram(
      120, "RPHI sensor (wafer)", 447, 0.5, 447.5 );

   m_rphi_endview = iHistoManager.histogram(
      130, "RPHI hits endview", 500, -0.12, 0.12, 500, -0.12, 0.12 );
   m_rphi_layer1_unwrapped = iHistoManager.histogram(
      140, "RPHI hits layer1 z VS phi", 157, -3.1415926, 3.1415926, 500, -0.1, 0.1 );
   m_rphi_layer2_unwrapped = iHistoManager.histogram(
      150, "RPHI hits layer2 z VS phi", 157, -3.1415926, 3.1415926, 500, -0.1, 0.1 );
   m_rphi_layer3_unwrapped = iHistoManager.histogram(
      160, "RPHI hits layer3 z VS phi", 157, -3.1415926, 3.1415926, 500, -0.1, 0.1 );
   m_rphi_layer4_unwrapped = iHistoManager.histogram(
      170, "RPHI hits layer4 z VS phi", 157, -3.1415926, 3.1415926, 500, -0.1, 0.1 );

   m_z_clam_layer = iHistoManager.histogram(
      200, "Z -clamshell and layer", 7, -2.5, 4.5 );
   m_z_ladder = iHistoManager.histogram(
      210, "Z ladder", 61, 0.5, 61.5 );
   m_z_sensor = iHistoManager.histogram(
      220, "Z sensor (wafer)", 447, 0.5, 447.5 );

   m_z_endview = iHistoManager.histogram(
      230, "Z hits endview", 500, -0.12, 0.12, 500, -0.12, 0.12 );
   m_z_layer1_unwrapped = iHistoManager.histogram(
      240, "Z hits layer1 z VS phi", 157, -3.1415926, 3.1415926, 500, -0.1, 0.1 );
   m_z_layer2_unwrapped = iHistoManager.histogram(
      250, "Z hits layer2 z VS phi", 157, -3.1415926, 3.1415926, 500, -0.1, 0.1 );
   m_z_layer3_unwrapped = iHistoManager.histogram(
      260, "Z hits layer3 z VS phi", 157, -3.1415926, 3.1415926, 500, -0.1, 0.1 );
   m_z_layer4_unwrapped = iHistoManager.histogram(
      270, "Z hits layer4 z VS phi", 157, -3.1415926, 3.1415926, 500, -0.1, 0.1 );
}

// --------------------- methods bound to streams -------------------
ActionBase::ActionResult
SiRunOverRaw::event( Frame& iFrame )          // anal3 equiv.
{
   report( DEBUG, kFacilityString ) << "here in event()" << endl;

   FAItem< DBEventHeader > header;
   extract( iFrame.record( Stream::kEvent ), header );
   report( DEBUG, kFacilityString ) << "using header" << endl;
   unsigned int run = header->run();
   unsigned int event = header->number();

   if ( run == 113347  ||
	run == 113455  ||
	run == 113560  ||
	run == 113668     )
      return ActionBase::kFailed;

//     if ( ( run == 113243  &&  event == 1489 ) )
//        return ActionBase::kFailed;

   cout << run << " " << event << endl;

   FATable< TRSeedTrack > seedtracks;
   extract( iFrame.record( Stream::kEvent ), seedtracks );
   FATable< TRSeedTrack >::const_iterator seedtrack_iterator;

   FATable< CalibratedSVRphiHit > svrhits;
   extract( iFrame.record( Stream::kEvent ), svrhits );
   FAItem< SeedTrackSVRHitLattice > svrhitlattice;
   extract( iFrame.record( Stream::kEvent ), svrhitlattice );

   FATable< CalibratedSVZHit > svzhits;
   extract( iFrame.record( Stream::kEvent ), svzhits );
   FAItem< SeedTrackSVZHitLattice > svzhitlattice;
   extract( iFrame.record( Stream::kEvent ), svzhitlattice );

   FAItem< ASiStore > siStore;
   extract( iFrame.record( Stream::kBaseGeometry ), siStore );
   report( DEBUG, kFacilityString ) << "using siStore" << endl;
   if ( ! siStore.valid() )
   {
      report( EMERGENCY, kFacilityString )
         << "ASiStore is not valid!!!" << endl;
      return ActionBase::kFailed;
   }

   for ( seedtrack_iterator = seedtracks.begin();
  	 seedtrack_iterator != seedtracks.end();
  	 seedtrack_iterator++ )
   {
      //// time for rphi /////////////////////////////////////////////////////////////

      report( DEBUG, kFacilityString ) << "using svrhitlattice" << endl;
      const SeedTrackSVRHitLattice::VectorRightID* rphi_ids =
	 svrhitlattice->vRightGivenLeft( seedtrack_iterator );
      if ( rphi_ids == NULL )
	 continue;

      SeedTrackSVRHitLattice::VectorRightID::const_iterator rphi_id_iter;
      SeedTrackSVRHitLattice::VectorRightID::const_iterator rphi_id_begin
	 = rphi_ids->begin();
      SeedTrackSVRHitLattice::VectorRightID::const_iterator rphi_id_end
	 = rphi_ids->end();
      
      for ( rphi_id_iter = rphi_id_begin;
	    rphi_id_iter != rphi_id_end;
	    rphi_id_iter++ )
      {
	 report( DEBUG, kFacilityString ) << "using rphi_hit" << endl;
	 const CalibratedSVRphiHit rphi_hit = svrhits[ (* rphi_id_iter) ];

	 // layer and clamshell histogram
	 m_rphi_clam_layer->fill( float( rphi_hit.layer() ) );
	 m_rphi_clam_layer->fill( -1. * float(
	    siStore->clamshellForHybrid( rphi_hit.hybrid() ) ) );

	 // ladders
	 m_rphi_ladder->fill( float( siStore->ladderForSensor( rphi_hit.sensor() ) ) );

	 // sensors
	 m_rphi_sensor->fill( float( rphi_hit.sensor() ) );

	 // 2d projections
	 HepPoint3D location = rphi_hit.worldcoord( *siStore );
	 m_rphi_endview->fill( location.x(), location.y() );
	 switch ( rphi_hit.layer() )
	 {
	    case 1: m_rphi_layer1_unwrapped->fill( location.phi(), location.z() ); break;
	    case 2: m_rphi_layer2_unwrapped->fill( location.phi(), location.z() ); break;
	    case 3: m_rphi_layer3_unwrapped->fill( location.phi(), location.z() ); break;
	    case 4: m_rphi_layer4_unwrapped->fill( location.phi(), location.z() ); break;
	 }
      } // end loop over rphi hits

      //// time for z ////////////////////////////////////////////////////////////////

      const SeedTrackSVZHitLattice::VectorRightID* z_ids =
	 svzhitlattice->vRightGivenLeft( seedtrack_iterator );
      if ( z_ids == NULL )
	 continue;

      SeedTrackSVZHitLattice::VectorRightID::const_iterator z_id_iter;
      SeedTrackSVZHitLattice::VectorRightID::const_iterator z_id_begin
	 = z_ids->begin();
      SeedTrackSVZHitLattice::VectorRightID::const_iterator z_id_end
	 = z_ids->end();
      
      for ( z_id_iter = z_id_begin;
	    z_id_iter != z_id_end;
	    z_id_iter++ )
      {
	 const CalibratedSVZHit z_hit = svzhits[ (* z_id_iter) ];

	 // layer and clamshell histogram
	 m_z_clam_layer->fill( float( z_hit.layer() ) );
	 m_z_clam_layer->fill( -1. * float(
	    siStore->clamshellForHybrid( z_hit.hybrid() ) ) );

	 // ladders
	 m_z_ladder->fill( float( siStore->ladderForSensor( z_hit.sensor() ) ) );

	 // sensors
	 m_z_sensor->fill( float( z_hit.sensor() ) );

	 // 2d projections
	 HepPoint3D location = z_hit.worldcoord( *siStore );
	 m_z_endview->fill( location.x(), location.y() );
	 switch ( z_hit.layer() )
	 {
	    case 1: m_z_layer1_unwrapped->fill( location.phi(), location.z() ); break;
	    case 2: m_z_layer2_unwrapped->fill( location.phi(), location.z() ); break;
	    case 3: m_z_layer3_unwrapped->fill( location.phi(), location.z() ); break;
	    case 4: m_z_layer4_unwrapped->fill( location.phi(), location.z() ); break;
	 }
      } // end loop over z hits

   } // end loop over seed tracks

   return ActionBase::kPassed;
}

/*
ActionBase::ActionResult
SiRunOverRaw::beginRun( Frame& iFrame )       // anal2 equiv.
{
   report( DEBUG, kFacilityString ) << "here in beginRun()" << endl;

   return ActionBase::kPassed;
}
*/

/*
ActionBase::ActionResult
SiRunOverRaw::endRun( Frame& iFrame )         // anal4 equiv.
{
   report( DEBUG, kFacilityString ) << "here in endRun()" << endl;

   return ActionBase::kPassed;
}
*/

//
// const member functions
//

//
// static member functions
//
