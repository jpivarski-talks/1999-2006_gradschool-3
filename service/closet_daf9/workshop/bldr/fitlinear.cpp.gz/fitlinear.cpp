Float_t x[ npoints ], y[ npoints ], sigx[ npoints ], sigy[ npoints ];
TRandom ran;

void init()
{
   for( int i = 0;  i < npoints;  i++ )
   {
      int offset = 4 * i;
      x[ i ]    = data[ offset + 0 ];
      sigx[ i ] = data[ offset + 1 ];
      y[ i ]    = data[ offset + 2 ];
      sigy[ i ] = data[ offset + 3 ];

      printf( "%3d: x = %g  sigx = %g  y = %g  sigy = %g\n",
	      ( i + 1 ), x[ i ], sigx[ i ], y[ i ], sigy[ i ] );
   }
}

void func( Int_t &npar, Double_t *deri, Double_t &val, Double_t *par, Int_t flag )
{
   // npar = number of parameters
   // deri = derivative of the function w.r.t each parameter???
   // val  = value of the function at the point given by parameters
   // par  = values of the parameters
   // flag = additional instructions, cryptically encoded

//    if ( npar < 2 )
//    {
//       printf( "Number of parameters = %d: ", npar );
//       for( int i = 0;  i < npar;  i++ )
// 	 printf( "%g ", par[ i ] );
//       printf( "\n" );
//       assert( 0 );
//    }

   float inter = par[ 0 ];
   float slope = par[ 1 ];

   float chi2 = 0.;
   for( int i = 0;  i < npoints;  i++ )
   {
//       // x is at the minimum-uncertainty distance
//       float sigx2_over_sigy2 = pow( sigx[ i ] / sigy[ i ], 2 );
//       float thx = ( ( slope * inter * sigx2_over_sigy2 -
// 		      slope * y[ i ] * sigx2_over_sigy2 + x[ i ] ) /
// 		    ( 1 - slope * slope * sigx2_over_sigy2 ) );	

//       // find the theoretical value of the function at this point
//       float thy = inter + slope * x;

//       // sigmas is the number of sigmas (in x-y) from x[i],y[i] to thx,thy
//       float sigmas = sqrt( ( pow( thx - x[ i ], 2 ) / sigx[ i ] / sigx[ i ] ) +
// 			   ( pow( thy - y[ i ], 2 ) / sigy[ i ] / sigy[ i ] )   );

      float thy = inter + slope * x[ i ];
      float sigmas = sigy[ i ];

      chi2 += pow( ( thy - y[ i ] ) / sigmas, 2 );
   }

   if ( flag == 3 )
      printf( "slope = %g, inter = %g;   chi2 = %g, dof = %d  ==>  chi2/dof = %g\n",
	      slope, inter, chi2, ( npoints - 1 ), ( chi2 / ( npoints - 1 ) ) );

   val = chi2;
}

bool fitlinear()
{
   const int npar = 2;
   if ( npoints < 2 )
      return false;

   init();
   double inter, inter_err, slope, slope_err;
   slope = ( y[ (npoints-1) ] - y[ 0 ] ) / ( x[ (npoints-1) ] - x[ 0 ] );
   inter = y[ 0 ] - slope * x[ 0 ];

   TMinuit mn( npar );
   Int_t ierflg;

   // parameter number, name, starting value, step size, low and high physical values, err
   mn.mnparm( 0, "Intercept", inter, inter / 10000, 0., 0., ierflg );
   if ( ierflg > 0 )
      return false;

   mn.mnparm( 1, "Slope", slope, slope / 10000, 0., 0., ierflg );
   if ( ierflg > 0 )
      return false;

   mn.SetFCN( func );

   const int ncommands = 3;
   const char* command[] = { "SET STRATEGY 1",
			     "SEEK",
			     "MINIMIZE" };
   int e;
   for( int c = 0;  c < ncommands;  c++ )
      if ( ( e = mn.Command( command[ c ] ) ) != 0 )
      {
	 printf( "Command \"%s\" failed with error %d: ", command[ c ], e );
	 switch( e )
	 {
	    case 1: printf( "Command is blank" ); break;
	    case 2: printf( "Command is unreadable, ignored" ); break;
	    case 3: printf( "Unknown command, ignored" ); break;
	    case 4: printf( "Abnormal termination (e.g. failed convergence)" ); break;
	    case 5: printf( "Command is a request to read PARAMETER definitions" ); break;
	    case 6: printf( "SET INPUT command" ); break;
	    case 7: printf( "SET TITLE command" ); break;
	    case 8: printf( "SET COVAR command" ); break;
	    case 9: printf( "(reserved)" ); break;
	    case 10: printf( "END command" ); break;
	    case 11: printf( "EXIT or STOP command" ); break;
	    case 12: printf( "RETURN command" ); break;
	 }
	 printf( "\n" );
//	 return false;
      }

   // make a canvas to display the results on
   c1 = new TCanvas( "indicator_v_weight", title, 800, 600 );
   c1.SetGrid();

   // extract the fit results
   mn.GetParameter( 0, inter, inter_err );
   mn.GetParameter( 1, slope, slope_err );

   // find a nice range to plot the fitted line on
   Float_t fitx[ 2 ], fity[ 2 ];
   fitx[ 0 ] = fitx[ 1 ] = x[ 0 ];
   for( int i = 0;  i < npoints;  i++ )
   {
      if ( x[ i ] < fitx[ 0 ] )
	 fitx[ 0 ] = x[ i ];

      if ( x[ i ] > fitx[ 1 ] )
	 fitx[ 1 ] = x[ i ];
   }
   Float_t edge = 0.1 * ( fitx[ 1 ] - fitx[ 0 ] );
   fitx[ 0 ] -= edge;
   fitx[ 1 ] += edge;

   fity[ 0 ] = inter + slope * x[ 0 ];
   fity[ 1 ] = inter + slope * fitx[ 1 ];

   // Draw the fitted line
   fit = new TGraph( 2, fitx, fity );
   fit->SetTitle( title );
   fit->Draw( "AL" );

   // Draw the points of the graph
   graph = new TGraphErrors( npoints, x, y, sigx, sigy );
   graph->Draw( "*P" );

   Int_t tmp_npar = 2;
   Double_t chi2;
   Double_t par[2];
   par[ 0 ] = inter;
   par[ 1 ] = slope;
   func( tmp_npar, NULL, chi2, par, 0 );

   Double_t lower = fity[ 0 ];
   Double_t higher = fity[ 1 ];
   if ( lower > higher )
   {
      lower = fity[ 1 ];
      higher = fity[ 0 ];
   }

   label = new TPaveText( fitx[ 1 ], higher, fitx[ 0 ], lower );
   char line[ 100 ];
   sprintf( line, "#chi^{2}/ndf = #frac{%g}{%d} = %g",
	    chi2, npoints - 2, chi2 / ( npoints - 2 ) );
   label->AddText( line );

   int digits = int( ceil( -1 * log10( inter_err ) + 1 ) );
   char format[ 100 ];
   char percent[ 2 ];
   percent[ 0 ] = '%';
   percent[ 1 ] = 0;

   if ( digits <= 0 )
      sprintf( format, "intercept = %s.0f #pm %s.0f", percent, percent );
   else
      sprintf( format, "intercept = %s%d.%df #pm %s%d.%df",
	       percent, digits + 2, digits, percent, digits + 2, digits );

   sprintf( line, format, inter, inter_err );
   label->AddText( line );

   digits = int( ceil( -1 * log10( slope_err ) + 1 ) );
   if ( digits <= 0 )
      sprintf( format, "slope = %s.0f #pm %s.0f", percent, percent );
   else
      sprintf( format, "slope = %s%d.%df #pm %s%d.%df",
	       percent, digits + 2, digits, percent, digits + 2, digits );

   sprintf( line, format, slope, slope_err );
   label->AddText( line );

   label->Draw();

   c1->Update();
   return true;
}
