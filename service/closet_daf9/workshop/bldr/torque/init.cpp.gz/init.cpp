Float_t x[ npoints ], y[ npoints ], sigx[ npoints ], sigy[ npoints ];
TRandom ran;

void init()
{
   for( int i = 0;  i < npoints;  i++ )
   {
      int offset = 4 * i;
      x[ i ]    = data[ offset + 0 ];
      sigx[ i ] = data[ offset + 1 ];
      y[ i ]    = data[ offset + 2 ];
      sigy[ i ] = data[ offset + 3 ];

      printf( "%3d: x = %g  sigx = %g  y = %g  sigy = %g\n",
	      ( i + 1 ), x[ i ], sigx[ i ], y[ i ], sigy[ i ] );
   }
}
