TString title( "Deflection VS. ( Weight - W_0 )" );
const int npoints = 5;
const double data[] = { 0.00, 0.01, 5.251, 0.003, 0.51, 0.01, 5.255, 0.003, 1.02, 0.01, 5.258, 0.003, 1.53, 0.01, 5.259, 0.003, 2.04, 0.01, 5.260, 0.003 };


