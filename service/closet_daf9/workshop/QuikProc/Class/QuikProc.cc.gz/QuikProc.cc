// -*- C++ -*-
//
// Package:     QuikProc
// Module:      QuikProc
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Wed Jul 11 17:29:26 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "QuikProc/QuikProc.h"
#include "Experiment/report.h"
#include "Experiment/units.h"  // for converting to/from standard CLEO units

#include "DataHandler/Record.h"
#include "DataHandler/Frame.h"
#include "FrameAccess/extract.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"

#include "Navigation/NavTrack.h"
#include "TrackRoot/TRSeedTrack.h"

#include "CLHEP/Vector/ThreeVector.h"

// STL classes
// You may have to uncomment some of these or other stl headers 
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "Processor.QuikProc" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: processor.cc,v 1.17 2000/12/04 19:11:11 cdj Exp $";
static const char* const kTagString = "$Name: v03_06_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
QuikProc::QuikProc( void )               // anal1
   : Processor( "QuikProc" )
{
   report( DEBUG, kFacilityString ) << "here in ctor()" << endl;

   // ---- bind a method to a stream -----
   // These lines ARE VERY IMPORTANT! If you don't bind the 
   // code you've just written (the "action") to a stream, 
   // your code won't get executed!

   bind( &QuikProc::event,    Stream::kEvent );
   //bind( &QuikProc::beginRun, Stream::kBeginRun );
   //bind( &QuikProc::endRun,   Stream::kEndRun );

   // do anything here that needs to be done at creation time
   // (e.g. allocate resources etc.)

}

QuikProc::~QuikProc()                    // anal5
{
   report( DEBUG, kFacilityString ) << "here in dtor()" << endl;
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}

//
// member functions
//

// ------------ methods for beginning/end "Interactive" ------------
// --------------------------- init method -------------------------
void
QuikProc::init( void )          // anal1 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in init()" << endl;

   // do any initialization here based on Parameter Input by User
   // (e.g. run expensive algorithms that are based on parameters
   //  specified by user at run-time)

}

// -------------------- terminate method ----------------------------
void
QuikProc::terminate( void )     // anal5 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in terminate()" << endl;

   // do anything here BEFORE New Parameter Change
   // (e.g. write out result based on parameters from user-input)
 
}

// ---------------- standard place to book histograms ---------------
void
QuikProc::hist_book( HIHistoManager& iHistoManager )
{
   report( DEBUG, kFacilityString ) << "here in hist_book()" << endl;

   // book your histograms here

   m_curvature = iHistoManager.histogram(
      100, "curvature", 100, -0.1, 0.1 );

   m_cottheta = iHistoManager.histogram(
      200, "cot theta", 100, -2., 2. );

   m_hitsperlayer = iHistoManager.histogram(
      300, "hits per layer", 47, 0.5, 47.5 );

   m_pos_mom_v_phi0_fore = iHistoManager.histogram(
      400, "forward positive track momentum vs. phi0",
      157, 0., 2*3.1415926, 100, 3., 6. );

   m_neg_mom_v_phi0_fore = iHistoManager.histogram(
      410, "foreward negative track momentum vs. phi0",
      157, 0., 2*3.1415926, 100, 3., 6. );

   m_pos_mom_v_phi0_back = iHistoManager.histogram(
      420, "backward positive track momentum vs. phi0",
      157, 0., 2*3.1415926, 100, 3., 6. );

   m_neg_mom_v_phi0_back = iHistoManager.histogram(
      430, "backward negative track momentum vs. phi0",
      157, 0., 2*3.1415926, 100, 3., 6. );

   m_pos_mom_v_phi0_fore_prof = iHistoManager.profile(
      440, "forward positive track momentum vs. phi0",
      157, 0., 2*3.1415926, 3., 6., HIHistProf::kErrorOnMean );

   m_neg_mom_v_phi0_fore_prof = iHistoManager.profile(
      450, "forward negative track momentum vs. phi0",
      157, 0., 2*3.1415926, 3., 6., HIHistProf::kErrorOnMean );

   m_pos_mom_v_phi0_back_prof = iHistoManager.profile(
      460, "backward positive track momentum vs. phi0",
      157, 0., 2*3.1415926, 3., 6., HIHistProf::kErrorOnMean );

   m_neg_mom_v_phi0_back_prof = iHistoManager.profile(
      470, "backward negative track momentum vs. phi0",
      157, 0., 2*3.1415926, 3., 6., HIHistProf::kErrorOnMean );

   m_pty_vs_ptx = iHistoManager.histogram(
      500, "pty VS ptx (transverse momentum plot)",
      100, -0.2, 0.2, 100, -0.2, 0.2 );

   m_absphi0sum_v_phi0p = iHistoManager.histogram(
      510, "abs( phi0p - phi0n ) - pi  VS  phi0p",
      157, 0., 2*3.1415926, 100, -0.04, 0.04 );

   m_absphi0sum_v_phi0p_prof = iHistoManager.profile(
      520, "abs( phi0p - phi0n ) - pi  VS  phi0p",
      157, 0., 2*3.1415926, -0.04, 0.04, HIHistProf::kErrorOnMean );

}

// --------------------- methods bound to streams -------------------
ActionBase::ActionResult
QuikProc::event( Frame& iFrame )          // anal3 equiv.
{
   report( DEBUG, kFacilityString ) << "here in event()" << endl;

   FATable< NavTrack > navtracks;
   extract( iFrame.record( Stream::kEvent ), navtracks );
   FATable< NavTrack >::const_iterator navtracks_iter;
   FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
   FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();

   DABoolean filled[ 2 ]; filled[ 0 ] = filled[ 1 ] = false;
   HepVector3D event_momentum( 0., 0., 0. );
   double event_phi0 = 0.;
   double pos_phi0 = 0.;

   for ( navtracks_iter = navtracks_begin;
	 navtracks_iter != navtracks_end;
	 navtracks_iter++ )
   {
      m_curvature->fill( navtracks_iter->seedTrack()->curvature() );
      m_cottheta->fill( navtracks_iter->seedTrack()->cotTheta() );

      report( INFO, kFacilityString )
	 << "track curvature = " << navtracks_iter->seedTrack()->curvature()
	 << ", cotTheta = " << navtracks_iter->seedTrack()->cotTheta() << endl;

      report( INFO, kFacilityString )
	 << "layer hits: ";
      const NavTrack::DRHitTable* seedtrack_hits
	 = navtracks_iter->seedDRHits();
      NavTrack::DRHitTable::const_iterator seedtrack_hits_iter;
      NavTrack::DRHitTable::const_iterator seedtrack_hits_begin
	 = seedtrack_hits->begin();
      NavTrack::DRHitTable::const_iterator seedtrack_hits_end
	 = seedtrack_hits->end();
      for ( seedtrack_hits_iter = seedtrack_hits_begin;
	    seedtrack_hits_iter != seedtrack_hits_end;
	    seedtrack_hits_iter++ )
      {
	 m_hitsperlayer->fill( (* seedtrack_hits_iter)->layer() );
	 report( INFO, kFacilityString )
	    << (* seedtrack_hits_iter)->layer() << " ";
      } // loop over seedtrack_hits
      report( INFO, kFacilityString ) << endl;

      DABoolean positive =
	 ( navtracks_iter->muonHelix()->curvature() > 0. );
      DABoolean foreward =
	 ( navtracks_iter->muonHelix()->cotTheta() > 0. );
      double phi0 = navtracks_iter->muonHelix()->phi0();
      double momentum = navtracks_iter->muonFit()->momentum().perp();

      if ( positive )
      {
	 if ( foreward )
	 {
	    m_pos_mom_v_phi0_fore->fill( phi0, momentum );
	    m_pos_mom_v_phi0_fore_prof->fill( phi0, momentum );
	 }
	 else
	 {
	    m_pos_mom_v_phi0_back->fill( phi0, momentum );
	    m_pos_mom_v_phi0_back_prof->fill( phi0, momentum );
	 }

	 filled[ 0 ] = true;
	 event_momentum += navtracks_iter->muonFit()->momentum();
	 event_phi0 += phi0;
	 pos_phi0 = phi0;
      }
      else
      {
	 if ( foreward )
	 {
	    m_neg_mom_v_phi0_fore->fill( phi0, momentum );
	    m_neg_mom_v_phi0_fore_prof->fill( phi0, momentum );
	 }
	 else
	 {
	    m_neg_mom_v_phi0_back->fill( phi0, momentum );
	    m_neg_mom_v_phi0_back_prof->fill( phi0, momentum );
	 }

	 filled[ 1 ] = true;
	 event_momentum += navtracks_iter->muonFit()->momentum();
	 event_phi0 -= phi0;
      }
      report( INFO, kFacilityString )
	 << "phi0 = " << phi0 << ", momentum = " << momentum;
      if ( positive )
	 report( INFO, kFacilityString )
	    << ", POSITIVE";
      else
	 report( INFO, kFacilityString )
	    << ", NEGATIVE";
      if ( foreward )
	 report( INFO, kFacilityString )
	    << ", FOREWARD" << endl;
      else
	 report( INFO, kFacilityString )
	    << ", BACKWARD" << endl;

   } // loop over navtracks

   if ( navtracks.size() == 2  &&  filled[ 0 ]  &&  filled[ 1 ] )
   {
      event_phi0 = abs( event_phi0 ) - 3.1415926;

      m_pty_vs_ptx->fill( event_momentum.x(), event_momentum.y() );
      report( INFO, kFacilityString )
	 << "event momentum = ( " << event_momentum.x() << ", "
	 << event_momentum.y() << ", " << event_momentum.z() << " )" << endl;
      m_absphi0sum_v_phi0p->fill( pos_phi0, event_phi0 );
      m_absphi0sum_v_phi0p_prof->fill( pos_phi0, event_phi0 );
   }

   return ActionBase::kPassed;
}

/*
ActionBase::ActionResult
QuikProc::beginRun( Frame& iFrame )       // anal2 equiv.
{
   report( DEBUG, kFacilityString ) << "here in beginRun()" << endl;

   return ActionBase::kPassed;
}
*/

/*
ActionBase::ActionResult
QuikProc::endRun( Frame& iFrame )         // anal4 equiv.
{
   report( DEBUG, kFacilityString ) << "here in endRun()" << endl;

   return ActionBase::kPassed;
}
*/

//
// const member functions
//

//
// static member functions
//
