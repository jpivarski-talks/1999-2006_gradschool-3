// -*- C++ -*-
#if !defined(QUIKPROC_QUIKPROC_H)
#define QUIKPROC_QUIKPROC_H
//
// Package:     <QuikProc>
// Module:      QuikProc
//
/**\class QuikProc QuikProc.h QuikProc/QuikProc.h
 
 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Wed Jul 11 17:29:25 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "Processor/Processor.h"
#include "HistogramInterface/HistogramPackage.h"

// forward declarations

class QuikProc : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------

      // ------------ Constructors and destructor ----------------
      QuikProc( void );                      // anal1 
      virtual ~QuikProc();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( HIHistoManager& );                  

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      //virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      //virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      QuikProc( const QuikProc& );

      // ------------ assignment operator(s) ---------------------
      const QuikProc& operator=( const QuikProc& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (QuikProc::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      // ------------ private const member functions -------------

      // ------------ data members -------------------------------

      HIHist1D* m_curvature;
      HIHist1D* m_cottheta;
      HIHist1D* m_hitsperlayer;


      HIHist2D* m_pos_mom_v_phi0_fore;
      HIHist2D* m_neg_mom_v_phi0_fore;
      HIHist2D* m_pos_mom_v_phi0_back;
      HIHist2D* m_neg_mom_v_phi0_back;
      HIHistProf* m_pos_mom_v_phi0_fore_prof;
      HIHistProf* m_neg_mom_v_phi0_fore_prof;
      HIHistProf* m_pos_mom_v_phi0_back_prof;
      HIHistProf* m_neg_mom_v_phi0_back_prof;

      HIHist2D* m_pty_vs_ptx;
      HIHist2D* m_absphi0sum_v_phi0p;
      HIHistProf* m_absphi0sum_v_phi0p_prof;

      // ------------ static data members ------------------------

};

// inline function definitions

#endif /* QUIKPROC_QUIKPROC_H */
