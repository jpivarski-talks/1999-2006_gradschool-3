// -*- C++ -*-
#if !defined(QUIKPROC3_QUIKPROC3_H)
#define QUIKPROC3_QUIKPROC3_H
//
// Package:     <QuikProc3>
// Module:      QuikProc3
//
/**\class QuikProc3 QuikProc3.h QuikProc3/QuikProc3.h
 
 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Tue Aug 28 10:42:25 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "Processor/Processor.h"
#include "HistogramInterface/HistogramPackage.h"
#include "CLHEP/Vector/ThreeVector.h"
#include "CLHEP/Matrix/Vector.h"
#include "CLHEP/Matrix/SymMatrix.h"
#include <iostream.h>

// external functions
extern "C" float prob_( const float&, const int& );

// forward declarations

class QuikProc3 : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------

      // ------------ Constructors and destructor ----------------
      QuikProc3( void );                      // anal1 
      virtual ~QuikProc3();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( HIHistoManager& );                  

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      //virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      //virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      QuikProc3( const QuikProc3& );

      // ------------ assignment operator(s) ---------------------
      const QuikProc3& operator=( const QuikProc3& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (QuikProc3::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      // ------------ private const member functions -------------

      // ------------ data members -------------------------------

      // ------------ static data members ------------------------

      // ------------ nested classes -----------------------------

   public:
      class M_HitInfo
      {
	 public:
	    M_HitInfo( int ilayer, Meters iradius,
		       Meters idca, Meters idrift, Meters ie_dca2, Meters ie_drift2,
		       HepVector iderivs, HepSymMatrix ierrorMatrix );
	    void print( ostream& os ) const;

	 private:
	    int layer;
	    Meters radius;
	    Meters dca;
	    Meters drift;
	    Meters e_dca2;
	    Meters e_drift2;
	    HepVector derivs;
	    HepSymMatrix errorMatrix;
      };

};

// inline function definitions

#endif /* QUIKPROC3_QUIKPROC3_H */
