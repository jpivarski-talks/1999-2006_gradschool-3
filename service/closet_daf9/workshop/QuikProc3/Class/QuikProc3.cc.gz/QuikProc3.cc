// -*- C++ -*-
//
// Package:     QuikProc3
// Module:      QuikProc3
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Tue Aug 28 10:42:26 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "QuikProc3/QuikProc3.h"
#include "Experiment/report.h"
#include "Experiment/units.h"  // for converting to/from standard CLEO units

#include "DataHandler/Record.h"
#include "DataHandler/Frame.h"
#include "FrameAccess/extract.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"

#include "ADRGeom/ADRSenseWireStore.h"
#include "HelixIntersection/HIDRSurfaceFactory.h"
#include "HelixIntersection/HIIntersectionSurface.h"
#include "HelixIntersection/HIHelixIntersector.h"
#include "CalibratedData/CalibratedDRHit.h"

#include "Navigation/NavTrack.h"
#include "/home/mccann/workshop/DualTrackHelices/DualTrackHelices/DualTrackHelices.h"

#include <ostream>

//RICH example 
//Dedx example
//Event Shape example


// STL classes
// You may have to uncomment some of these or other stl headers 
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "Processor.QuikProc3" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: processor.cc,v 1.19 2001/08/23 21:41:55 llh14 Exp $";
static const char* const kTagString = "$Name: v04_00_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
QuikProc3::QuikProc3( void )               // anal1
   : Processor( "QuikProc3" )
{
   report( DEBUG, kFacilityString ) << "here in ctor()" << endl;

   // ---- bind a method to a stream -----
   // These lines ARE VERY IMPORTANT! If you don't bind the 
   // code you've just written (the "action") to a stream, 
   // your code won't get executed!

   bind( &QuikProc3::event,    Stream::kEvent );
   //bind( &QuikProc3::beginRun, Stream::kBeginRun );
   //bind( &QuikProc3::endRun,   Stream::kEndRun );

   // do anything here that needs to be done at creation time
   // (e.g. allocate resources etc.)

}

QuikProc3::~QuikProc3()                    // anal5
{
   report( DEBUG, kFacilityString ) << "here in dtor()" << endl;
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}

//
// member functions
//

// ------------ methods for beginning/end "Interactive" ------------
// --------------------------- init method -------------------------
void
QuikProc3::init( void )          // anal1 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in init()" << endl;

   // do any initialization here based on Parameter Input by User
   // (e.g. run expensive algorithms that are based on parameters
   //  specified by user at run-time)

}

// -------------------- terminate method ----------------------------
void
QuikProc3::terminate( void )     // anal5 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in terminate()" << endl;

   // do anything here BEFORE New Parameter Change
   // (e.g. write out result based on parameters from user-input)
 
}

// ---------------- standard place to book histograms ---------------
void
QuikProc3::hist_book( HIHistoManager& iHistoManager )
{
   report( DEBUG, kFacilityString ) << "here in hist_book()" << endl;

   // book your histograms here

}

// --------------------- methods bound to streams -------------------
ActionBase::ActionResult
QuikProc3::event( Frame& iFrame )          // anal3 equiv.
{
   report( DEBUG, kFacilityString ) << "here in event()" << endl;

//   report( INFO, kFacilityString ).precision(20);

   FAItem< ADRSenseWireStore > aStore;
   extract( iFrame.record( Stream::kDRAlignment ), aStore );

//     // a surface factory turns HitAndDriftDistance objects into surfaces
//     HIDRSurfaceFactory drFactory( iFrame, true, true, true, true, &(* aStore) );
//     STL_VECTOR( HIIntersectionSurface* ) surfaces;
//     STL_VECTOR( HIDRSurfaceFactory::DRHitAndDriftDistance ) drhitinfos;

   DABoolean some_track_has_neg_errs = false;

   // loop over tracks
   FATable< NavTrack > navtracks;
   extract( iFrame.record( Stream::kEvent ), navtracks );
   if ( navtracks.size() != 2 )
      return ActionBase::kFailed;
   FATable< NavTrack >::const_iterator navtracks_iter;
   FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
   FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
   
   FATable< DualTrackHelices > dualtracks;
   extract( iFrame.record( Stream::kEvent ), dualtracks );
   FATable< DualTrackHelices >::const_iterator dualtracks_iter;

   for ( navtracks_iter = navtracks_begin;
	 navtracks_iter != navtracks_end;
	 navtracks_iter++ )
   {
      // we don't want to use bad fits...
      if ( navtracks_iter->muonQuality()->fitAbort() )
	 return ActionBase::kFailed;

      dualtracks_iter = dualtracks.find( navtracks_iter->identifier() );

      HIHelix singleHelix( (* navtracks_iter->muonHelix() ),
			   DBCandidate::mass( DBCandidate::Hypo( DBCandidate::kMuon ) ) );

      HIHelix dualHelix( dualtracks_iter->helix() );

//        // ...or tracks with final state radiation
//        if ( prob_( dualtracks_iter->chisq(), dualtracks_iter->ndof() ) < 0.11  ||
//  	   prob_( dualtracks_iter->chisq(), dualtracks_iter->ndof() ) > 1. )
//  	 return ActionBase::kFailed;

      // print out some information about the tracks
//        ostream* output_stream;
//        if ( track_has_neg_errs )
//  	 output_stream = &( report( NOTICE, kFacilityString ) );
//        else
//  	 output_stream = &( report( INFO, kFacilityString ) );
      ostream* output_stream = &( report( NOTICE, kFacilityString ) );

      (* output_stream )
	 << "=====================================================================" << endl
	 << "Single-track parameters:" << endl
	 << "    curvature = " << singleHelix.curvature() << endl
	 << "         phi0 = " << singleHelix.phi0() << endl
	 << "           d0 = " << singleHelix.d0() << endl
	 << "     cotTheta = " << singleHelix.cotTheta() << endl
	 << "           z0 = " << singleHelix.z0() << endl
	 << "        chi^2 = " << navtracks_iter->muonQuality()->chiSquare() << endl
	 << "          ndf = " <<
	 navtracks_iter->muonQuality()->degreesOfFreedom() << endl;
//  	 (* output_stream )
//  	    << "   confidence = " <<
//  	    prob_( navtracks_iter->muonQuality()->chiSquare(),
//  		   navtracks_iter->muonQuality()->degreesOfFreedom() ) << endl;

      if ( singleHelix.errorMatrix()( KTHelix::kCurvature, KTHelix::kCurvature ) > 0.  &&
	   singleHelix.errorMatrix()( KTHelix::kPhi0, KTHelix::kPhi0 ) > 0.            &&
	   singleHelix.errorMatrix()( KTHelix::kD0, KTHelix::kD0 ) > 0.                &&
	   singleHelix.errorMatrix()( KTHelix::kCotTheta, KTHelix::kCotTheta ) > 0.    &&
	   singleHelix.errorMatrix()( KTHelix::kZ0, KTHelix::kZ0 ) > 0.                   )
	 (* output_stream )
	    << " error matrix : " << endl << singleHelix.errorMatrix() << endl;
      else
	 report( ERROR, kFacilityString )
	    << " error matrix : " << endl << singleHelix.errorMatrix() << endl;

      (* output_stream )
	 << "Dual-track parameters:" << endl
	 << "    curvature = " << dualHelix.curvature() << endl
	 << "         phi0 = " << dualHelix.phi0() << endl
	 << "           d0 = " << dualHelix.d0() << endl
	 << "     cotTheta = " << dualHelix.cotTheta() << endl
	 << "           z0 = " << dualHelix.z0() << endl;

      (* output_stream )
	 << "Dual-track constraints:" << endl
	 << "        chi^2 = " << dualtracks_iter->chisq() << endl
	 << "          ndf = " << dualtracks_iter->ndof() << endl;
//    	 (* output_stream )
//    	    << "   confidence = " << prob_( dualtracks_iter->chisq(),
//  					    dualtracks_iter->ndof() ) << endl;

      if ( dualtracks_iter->errMatrix()( KTHelix::kCurvature, KTHelix::kCurvature ) > 0.  &&
	   dualtracks_iter->errMatrix()( KTHelix::kPhi0, KTHelix::kPhi0 ) > 0.            &&
	   dualtracks_iter->errMatrix()( KTHelix::kD0, KTHelix::kD0 ) > 0.                &&
	   dualtracks_iter->errMatrix()( KTHelix::kCotTheta, KTHelix::kCotTheta ) > 0.    &&
	   dualtracks_iter->errMatrix()( KTHelix::kZ0, KTHelix::kZ0 ) > 0.                   )
	 (* output_stream )
	    << " error matrix : " << endl << dualtracks_iter->errMatrix() << endl;
      else
	 report( ERROR, kFacilityString )
	    << " error matrix : " << endl << dualtracks_iter->errMatrix() << endl;

//        // loop over hits
//        const NavTrack::DRHitTable* hittable = navtracks_iter->seedDRHits();
//        NavTrack::DRHitTable::const_iterator hit_iter;
//        NavTrack::DRHitTable::const_iterator hit_begin = hittable->begin();
//        NavTrack::DRHitTable::const_iterator hit_end = hittable->end();
//        for ( hit_iter = hit_begin;
//  	    hit_iter != hit_end;
//  	    hit_iter++ )
//        {
//  	 const CalibratedDRHit* drhit = (* hit_iter);
//  	 // only interested in axial hits...
//  	 if ( drhit->layer() < 17 )
//  	 {
//  	    // ...which are in the integration (symmetric) region of the drift cell
//  	    if ( abs( drhit->distance() ) < 0.0035 )
//  	    {
//  	       drhitinfos.push_back(
//  		  HIDRSurfaceFactory::DRHitAndDriftDistance(
//  		     drhit, drhit->distance() ) );
//  	    } // end if this is in the integration region
//  	 } // end if this is an axial hit
//        } // end loop over hits
  
//        drFactory.generateMultiWireSurfaces( surfaces, drhitinfos, NULL );
//        // we don't want to work on an empty surface, but it is ok if
//        // one out of the two tracks has no hits of interest (though rare)
//        if ( surfaces.empty() )
//  	 continue;

//        DABoolean track_has_neg_errs = false;
//        vector< M_HitInfo* > track_info;

//        HIHelixIntersector intersector(
//  	 surfaces, HIHelixIntersector::kIncreasingRadius, &dualHelix );
//        HIHelixIntersector::IntersectionStatus status =
//  	 intersector.swimToCurrentSurface( KTMoveControl::kDirectionForward );
//        do {
//  	 HIIntersectionSurface* surface = intersector.currentSurface();
//  	 do {
//                 Meters dca = surface->dca( dualHelix );
//                 Meters drift = surface->measuredDca();
//                 if ( dca < 0. ) drift *= -1.;

//  	       // skip a hit if it has an extreme value of dca, drift or residual
//                 if ( dca == 0.  ||  drift == 0. )
//                    continue;
//                 if ( abs( dca - drift ) > 0.001 )
//                    continue;

//                 HepVector derivs( HIHelix::kNTrackParameters );
//                 surface->derivatives( dualHelix, derivs );
//                 double e_dca2 = dualHelix.errorMatrix().similarity( derivs );

//                 double e_drift2 = 1. / surface->fittingWeight();

//  	       assert( surface->calibratedHit()->deviceType() == CalibratedHit::DR );
//  	       int layer = ( ( CalibratedDRHit* )( surface->calibratedHit() ) )->layer();
//  	       double radius = surface->radius();

//  	       M_HitInfo* info =
//  		  new M_HitInfo( layer, radius, dca, drift, e_dca2, e_drift2,
//  				 derivs, dualHelix.errorMatrix() );
//  	       track_info.push_back( info );

//  	       if ( e_dca2 <= 0.  ||  e_drift2 <= 0. )
//  		  some_track_has_neg_errs = track_has_neg_errs = true;

//  	 } while ( surface->advanceToNextCalibratedHit( dualHelix ) );
//        } while ( intersector.swimToNextIntersection( KTMoveControl::kDirectionForward )
//  		== HIHelixIntersector::kIntersectionOK );

//        if ( track_has_neg_errs )
//        {
//  	 report( ERROR, kFacilityString ) << "Track has negative errors!" << endl;

//  	 // now we also have the hit information
//  	 (* output_stream )
//  	    << "Hit information:" << endl;

//  	 vector< M_HitInfo* >::const_iterator track_info_iter;
//  	 vector< M_HitInfo* >::const_iterator track_info_begin = track_info.begin();
//  	 vector< M_HitInfo* >::const_iterator track_info_end = track_info.end();
//  	 for ( track_info_iter = track_info_begin;
//  	       track_info_iter != track_info_end;
//  	       track_info_iter++ )
//  	    (* track_info_iter)->print( (* output_stream ) );

//  	 (* output_stream ) << endl;
//        }

//        // this was my memory leak, a while back...
//        drhitinfos.clear();
//        for ( int i = 0;  i < surfaces.size();  i++ )
//  	 delete surfaces[ i ];
//        surfaces.clear();

//        for ( int j = 0;  j < track_info.size();  j++ )
//  	 delete track_info[ j ];

   } // end loop over tracks

   // in case you want to chain something
//     return ( some_track_has_neg_errs ? ActionBase::kPassed : ActionBase::kFailed );
   return ActionBase::kPassed;
}

/*
ActionBase::ActionResult
QuikProc3::beginRun( Frame& iFrame )       // anal2 equiv.
{
   report( DEBUG, kFacilityString ) << "here in beginRun()" << endl;

   return ActionBase::kPassed;
}
*/

/*
ActionBase::ActionResult
QuikProc3::endRun( Frame& iFrame )         // anal4 equiv.
{
   report( DEBUG, kFacilityString ) << "here in endRun()" << endl;

   return ActionBase::kPassed;
}
*/

//
// const member functions
//

//
// static member functions
//

//
// nested classes
//

QuikProc3::M_HitInfo::M_HitInfo( int ilayer, Meters iradius,
				 Meters idca, Meters idrift, Meters ie_dca2, Meters ie_drift2,
				 HepVector iderivs, HepSymMatrix ierrorMatrix ) :
   layer( ilayer ),
   radius( iradius ),
   dca( idca ),
   drift( idrift ),
   e_dca2( ie_dca2 ),
   e_drift2( ie_drift2 ),
   derivs( iderivs ),
   errorMatrix( ierrorMatrix )
{ }

void
QuikProc3::M_HitInfo::print( ostream& os ) const
{
   os << "        layer = " << layer << endl
      << "       radius = " << radius << endl
      << "          dca = " << dca << endl
      << "        drift = " << drift << endl
      << "       e_dca2 = " << e_dca2 << endl
      << "     e_drift2 = " << e_drift2 << endl
      << "       derivs = { " << derivs[0] << ", " << derivs[1] << ", "
      << derivs[2] << ", " << derivs[3] << ", " << derivs[4] << " }" << endl
      << " error matrix : " << endl << errorMatrix << endl;
}
