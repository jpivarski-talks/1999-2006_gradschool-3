// -*- C++ -*-
//
// Package:     QuikProc2
// Module:      QuikProc2
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Tue Aug 28 09:32:42 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "QuikProc2/QuikProc2.h"
#include "Experiment/report.h"
#include "Experiment/units.h"  // for converting to/from standard CLEO units

#include "DataHandler/Record.h"
#include "DataHandler/Frame.h"
#include "FrameAccess/extract.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"

#include "Navigation/NavTrack.h"

//RICH example 
//Dedx example
//Event Shape example


// STL classes
// You may have to uncomment some of these or other stl headers 
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "Processor.QuikProc2" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: processor.cc,v 1.19 2001/08/23 21:41:55 llh14 Exp $";
static const char* const kTagString = "$Name: v04_00_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
QuikProc2::QuikProc2( void )               // anal1
   : Processor( "QuikProc2" )
{
   report( DEBUG, kFacilityString ) << "here in ctor()" << endl;

   // ---- bind a method to a stream -----
   // These lines ARE VERY IMPORTANT! If you don't bind the 
   // code you've just written (the "action") to a stream, 
   // your code won't get executed!

   bind( &QuikProc2::event,    Stream::kEvent );
   //bind( &QuikProc2::beginRun, Stream::kBeginRun );
   //bind( &QuikProc2::endRun,   Stream::kEndRun );

   // do anything here that needs to be done at creation time
   // (e.g. allocate resources etc.)

}

QuikProc2::~QuikProc2()                    // anal5
{
   report( DEBUG, kFacilityString ) << "here in dtor()" << endl;
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}

//
// member functions
//

// ------------ methods for beginning/end "Interactive" ------------
// --------------------------- init method -------------------------
void
QuikProc2::init( void )          // anal1 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in init()" << endl;

   // do any initialization here based on Parameter Input by User
   // (e.g. run expensive algorithms that are based on parameters
   //  specified by user at run-time)

}

// -------------------- terminate method ----------------------------
void
QuikProc2::terminate( void )     // anal5 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in terminate()" << endl;

   // do anything here BEFORE New Parameter Change
   // (e.g. write out result based on parameters from user-input)
 
}

// ---------------- standard place to book histograms ---------------
void
QuikProc2::hist_book( HIHistoManager& iHistoManager )
{
   report( DEBUG, kFacilityString ) << "here in hist_book()" << endl;

   // book your histograms here

   const char* labels[ 2 ] = { "phi01", "phi02" };
   m_ntuple = iHistoManager.ntuple( 1, "phintuple", 2, 262144, labels );
}

// --------------------- methods bound to streams -------------------
ActionBase::ActionResult
QuikProc2::event( Frame& iFrame )          // anal3 equiv.
{
   report( DEBUG, kFacilityString ) << "here in event()" << endl;

   FATable< NavTrack > navtracks;
   extract( iFrame.record( Stream::kEvent ), navtracks );
   FATable< NavTrack >::const_iterator navtracks_iterator;
   FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
   FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
   report( DEBUG, kFacilityString ) << "event: got NavTracks" << endl;

   static unsigned int events, pairs, tracked, backtoback;

   events++;

   if ( navtracks.size() != 2 )
      return ActionBase::kFailed;

   pairs++;

   float phi0s[ 2 ];
   bool filled[ 2 ] = { false, false };

   for ( navtracks_iterator = navtracks_begin;
	 navtracks_iterator != navtracks_end;
	 navtracks_iterator++ )
   {
      if ( navtracks_iterator->muonQuality()->fitAbort() )
	 return ActionBase::kFailed;

      double phi0 = navtracks_iterator->muonHelix()->phi0();
      if ( phi0 > PI ) phi0 -= 2. * PI;
      
      if ( phi0 > -PI / 2.  &&  phi0 < PI / 2. )
      {
	 phi0s[ 0 ] = phi0;
	 filled[ 0 ] = true;
      }
      else
      {
	 phi0s[ 1 ] = phi0;
	 filled[ 1 ] = true;
      }
   }

   tracked++;

   if ( filled[ 0 ]  &&  filled[ 1 ] )
   {
      backtoback++;

      report( INFO, kFacilityString )
	 << "phi0 = { " << phi0s[ 0 ] << ", " << phi0s[ 1 ] << " }" << endl;

      report( INFO, kFacilityString )
	 << "events: " << events << ", pairs: " << pairs
	 << ", tracked: " << tracked
	 << ", back-to-back: " << backtoback << endl;

      cout << "QQQ: " << phi0s[ 0 ] << " " << phi0s[ 1 ] << endl;

      m_ntuple->fill( phi0s );
   }

   return ActionBase::kPassed;
}

/*
ActionBase::ActionResult
QuikProc2::beginRun( Frame& iFrame )       // anal2 equiv.
{
   report( DEBUG, kFacilityString ) << "here in beginRun()" << endl;

   return ActionBase::kPassed;
}
*/

/*
ActionBase::ActionResult
QuikProc2::endRun( Frame& iFrame )         // anal4 equiv.
{
   report( DEBUG, kFacilityString ) << "here in endRun()" << endl;

   return ActionBase::kPassed;
}
*/

//
// const member functions
//

//
// static member functions
//
