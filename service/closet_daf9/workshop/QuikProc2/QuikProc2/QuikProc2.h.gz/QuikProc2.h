// -*- C++ -*-
#if !defined(QUIKPROC2_QUIKPROC2_H)
#define QUIKPROC2_QUIKPROC2_H
//
// Package:     <QuikProc2>
// Module:      QuikProc2
//
/**\class QuikProc2 QuikProc2.h QuikProc2/QuikProc2.h
 
 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Tue Aug 28 09:32:41 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "Processor/Processor.h"
#include "HistogramInterface/HistogramPackage.h"

// macro definitions
#define PI 3.1415926

// forward declarations

class QuikProc2 : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------

      // ------------ Constructors and destructor ----------------
      QuikProc2( void );                      // anal1 
      virtual ~QuikProc2();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( HIHistoManager& );                  

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      //virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      //virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      QuikProc2( const QuikProc2& );

      // ------------ assignment operator(s) ---------------------
      const QuikProc2& operator=( const QuikProc2& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (QuikProc2::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      // ------------ private const member functions -------------

      // ------------ data members -------------------------------

      HINtuple* m_ntuple;

      // ------------ static data members ------------------------

};

// inline function definitions

#endif /* QUIKPROC2_QUIKPROC2_H */
