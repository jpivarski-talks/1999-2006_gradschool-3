#!/usr/bin/perl

$runstart = $ARGV[0];
die "usage: better_page.pl ######[keep]\n" if ( $runstart !~ /^[0-9]{6}$/  &&
						$runstart !~ /^[0-9]{6}keep$/i );

chdir( "/home/mccann/workshop/MP2Scripts/tmp" );
system( "/usr/local/bin/wget http://www.lns.cornell.edu/~pass2/private/$runstart.html" );
open( RUNLIST, "$runstart.html" ) || die;
@runs = ();
while( <RUNLIST> )
{
    push( @runs, $1 ) if ( $_ =~ /([0-9]{6})/ );
}
close( RUNLIST );
unlink( "$runstart.html" );
@runs = sort @runs;

warn "Runs are: " . join( " ", @runs ) . "\n";

%info = ();
foreach $run ( @runs )
{
    system( "/usr/local/bin/wget 'http://lnson3.lns.cornell.edu/rbin/runsheet/getRun.pl?Number=$run&Submit=Submit'" );
    
    open( RUNINFO, "getRun.pl?Number=$run&Submit=Submit" );
#    $trs = $tds = 0;
    my ( $sequence, $events, $live, $lumi ) = ( "", "", "", "" );
    for( my $l = 1;  $t = <RUNINFO>;  $l++ )
    {
# 	$tds++ if ( $tr == 2  &&  ( $_ =~ /<td>/ || $_ =~ /<td ALIGN="right">/ ) );
# 	$trs++ if ( $_ =~ /<tr>/ );
#
# 	$sequence .= $_ if ( $trs == 2  &&  $tds == 3 );
# 	$events   .= $_ if ( $trs == 2  &&  $tds == 6 );
# 	$live     .= $_ if ( $trs == 2  &&  $tds == 7 );
# 	$lumi     .= $_ if ( $trs == 2  &&  $tds == 8 );

	chop( $t );
	if ( $l == 28 )
	{ $sequence = $t }
	else
	{
	    $t =~ /^([0-9\.]+)</;
	    $events = $1 if ( $l == 32 );
	    $live   = $1 if ( $l == 33 );
	    $lumi   = $1 if ( $l == 34 );
	}
    }
    close( RUNINFO );

    $info{$run}{"sequence"} = $sequence;
    $info{$run}{"events"} = $events;
    $info{$run}{"live"} = $live;
    $info{$run}{"lumi"} = $lumi;

    unlink( "getRun.pl?Number=$run&Submit=Submit" );
}

print "

Run information for the week starting with $runstart
=========================================================================
  RUN  |  EVENTS  |  LIVE |   LUMI  | SEQUENCE 
-------+----------+-------+---------+------------------------------------
";

foreach $run ( @runs )
{
    printf( "%6d | %8d | %5.2f | %7.2f | %s\n",
	    $run, $info{$run}{"events"}, $info{$run}{"live"},
	    $info{$run}{"lumi"}, $info{$run}{"sequence"} );
}
