{
   // by this point in the code, I have changed my geometry constants
   // I am in a function that will be called repeatedly by MINUIT
   
   // assignment calls resetToBeginning() which clears the proxies and
   // forces the ADRSenseWireStore object to be recalculated using the
   // new constants
   FIFrameIterator itFrame = m_frame_begin;

   FAItem< ADRSenseWireStore > aStore;
   extract( itFrame.record( Stream::kDRAlignment ), aStore );

   HIDRSurfaceFactory drFactory( itFrame, true, true, true, true, aStore );
   STL_VECTOR( HIIntersectionSurface* ) surfaces;
   STL_VECTOR( HIDRSurfaceFactory::DRHitAndDriftDistance ) drhitinfos;

   double chi2 = 0.;
   for( ; itFrame != m_frame_end; ++itFrame )
   {
      // These tracks come straight from the pds file--- they are
      // untouched by the changes to CLEOConstantsModifiable
      FATable< NavTrack > navtracks;
      extract( itFrame->record( Stream::kEvent ), navtracks );
      FATable< NavTrack >::const_iterator navtracks_iter;
      FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
      FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
      
      for ( navtracks_iter = navtracks_begin;
            navtracks_iter != navtracks_end;
            navtracks_iter++ )
      {
	 HIHelix helix = navtracks_iter->muonHelix();

	 const NavTrack::DRHitTable* seedtrack_hits
	    = navtracks_iter->seedDRHits();
	 NavTrack::DRHitTable::const_iterator seedtrack_hits_iter;
	 NavTrack::DRHitTable::const_iterator seedtrack_hits_begin
	    = seedtrack_hits->begin();
	 NavTrack::DRHitTable::const_iterator seedtrack_hits_end
	    = seedtrack_hits->end();
	 for ( seedtrack_hits_iter = seedtrack_hits_begin;
	       seedtrack_hits_iter != seedtrack_hits_end;
	       seedtrack_hits_iter++ )
	 {
	    CalibratedDRHit* drhit = (* seedtrack_hits_iter);
            if ( this is a hit I want to use )
            {
	       num_hits++;
	       drhitinfos.push_back(
		  HIDRSurfaceFactory::DRHitAndDriftDistance( drhit, drhit->distance() ) );
            } // end if interesting
         } // end loop over hits

	 drFactory.generateMultiWireSurfaces( surfaces, drhitinfos, NULL );

	 HIHelixIntersector intersector(
	    surfaces, HIHelixIntersector::kIncreasingRadius, helix );
	 HIHelixIntersector::IntersectionStatus status =
	    intersector.swimToCurrentSurface( KTMoveControl::kDirectionForward );
	 do { 
	    do {
	       HIIntersectionSurface* surface = currentSurface();

	       Meters dca = surface->dca( helix );
	       Meters drift = surface->measuredDca();
	       Meters residual = dca - drift;
	       
	       double e_drift2 = 1. / surface->fittingWeight();

	       HepVector derivs( HIHelix::kNTrackParameters );
	       surface->derivatives( trackHelix, derivs );
	       double e_dca2 = helix.errorMatrix().similarity( derivs );

	       chi2 += sqr( residual ) / ( e_drift2 + e_dca2 );
	    } while ( surface->advanceToNextCalibratedHit( helix ) );
	 } while ( intersector.swimToNextIntersection( ) == HIHelixIntersector::kIntersectionOK )

	 drhitinfos.clear();
	 surfaces.clear();
      } // end loop over tracks
   } // end loop over frames (events)

   // now I have my chi^2, calculated as a quadrature sum over residuals
}
