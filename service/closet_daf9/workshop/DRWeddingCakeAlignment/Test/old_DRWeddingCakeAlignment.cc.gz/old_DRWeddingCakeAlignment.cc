// -*- C++ -*-
//
// Package:     <DRWeddingCakeAlignment>
// Module:      DRWeddingCakeAlignment
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Tue Jul 17 10:31:50 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "Experiment/report.h"
#include "DRWeddingCakeAlignment/DRWeddingCakeAlignment.h"
#include "DataHandler/Stream.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"
#include "FrameAccess/extract.h"
#include "DataHandler/Frame.h"
#include "DAException/DAException.h"
#include "CleoDB/DBEventHeader.h"

#include "Navigation/NavTrack.h"
#include "JobControl/JobControl.h"
#include "ToolBox/HistogramPackage.h"

// STL classes
// You may have to uncomment some of these or other stl headers
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "DRWeddingCakeAlignment.DRWeddingCakeAlignment" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: fimodule.cc,v 1.2 2000/12/04 19:11:05 cdj Exp $";
static const char* const kTagString = "$Name: v03_06_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
DRWeddingCakeAlignment::DRWeddingCakeAlignment()
   : FrameIteratorModuleBase( "DRWeddingCakeAlignment",
			      "For aligning the wedding cake with MINUIT" )
{
   //You must set what streams you which to iterate over
   //  that is, what events should the Frames be stopped on
//   iterateOver( Stream::kBeginRun );
   iterateOver( Stream::kEvent );
}

// DRWeddingCakeAlignment::DRWeddingCakeAlignment( const DRWeddingCakeAlignment& rhs )
// {
//    // do actual copying here; if you implemented
//    // operator= correctly, you may be able to use just say      
//    *this = rhs;
// }

DRWeddingCakeAlignment::~DRWeddingCakeAlignment()
{
}

//
// assignment operators
//
// const DRWeddingCakeAlignment& DRWeddingCakeAlignment::operator=( const DRWeddingCakeAlignment& rhs )
// {
//   if( this != &rhs ) {
//      // do actual copying here, plus:
//      // "SuperClass"::operator=( rhs );
//   }
//
//   return *this;
// }

//
// member functions
//

//
// const member functions
//
void
DRWeddingCakeAlignment::iterate( const FIFrameIterator& iBegin,
				 const FIFrameIterator& iEnd )
{
   report( DEBUG, kFacilityString )
      << "enter DRWeddingCakeAlignment::iterate " << endl;

   JobControl* jc = JobControl::instance();
   HIHistoManager* hm = jc->histogramManagerP();

   // what are we varying?
   DABoolean vary_fore = ( strncmp( m_cake.value().c_str(), "fore", 4 ) == 0 );
   DABoolean vary_back = ( strncmp( m_cake.value().c_str(), "back", 4 ) == 0 );
   assert( ( vary_fore && !vary_back )  ||  ( !vary_fore && vary_back ) );
   int cake1 = m_cake.value()[ 4 ] - '0';
   assert( cake1 > 0  &&  cake1 < 9 );
   int cake2 = m_cake.value()[ 5 ] - '0';
   assert( cake2 > 0  &&  cake1 < 9 );
   
   // make DRWeightTheta with only stereo layers on the reference side
   // and axial layers of interest on the variable side

   // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   for( unsigned int timesIterated = 1;
	timesIterated <= 1;
	timesIterated++ )
   {
      report( DEBUG, kFacilityString )
	 << "start iteration" << timesIterated << endl;

      // make a histograms of phi0_ref, phi0_var, phi0diff,
      // sigma_phi0ref and sigma_phi0var for this iteration
      string suffix( " (" );
      suffix += m_cake;
      suffix += ") iter ";
      char iternum[3];
      sprintf( iternum, "%02d", timesIterated );
      suffix += iternum;

      int baseid = timesIterated * 10;
      string name_phi0diff( "phi0diff" );
      
      HIHist1D* h_phi0_ref = hm->histogram(
	 baseid + 1, name_phi0_ref + suffix, 79, 0., 2. * 3.1415926 );
      HIHist1D* h_phi0_var = hm->histogram(
	 baseid + 2, name_phi0_var + suffix, 79, 0., 2. * 3.1415926 );
      HIHist1D* h_phi0diff = hm->histogram(
	 baseid + 3, name_phi0diff + suffix, 50, -0.07, 0.07 );
      HIHist1D* h_sigma_phi0ref = hm->histogram(
	 baseid + 4, name_sigma_phi0ref + suffix, 100, 0., 0.00001 );
      HIHist1D* h_sigma_phi0var = hm->histogram(
	 baseid + 5, name_sigma_phi0var + suffix, 100, 0., 0.00001 );

      int prevrun = 0;
      for( FIFrameIterator itFrame = iBegin;
	   itFrame != iEnd;
	   ++itFrame )
      {
	 FAItem< DBEventHeader > header;
	 extract( itFrame->record( Stream::kEvent ), header );
	 unsigned int run = header->run();
	 unsigned int event = header->number();

	 if ( run != prevrun )
	 {  prevrun = run;
	    report( INFO, kFacilityString )
	       << "New run: " << run << endl; }
	 // pds-making job crashed around here
	 if ( run == 119498 && event >= 106446 )
	    continue;

 	 FATable< NavTrack > navtracks;
 	 extract( itFrame->record( Stream::kEvent ), navtracks );
 	 FATable< NavTrack >::const_iterator navtracks_iter;
 	 FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
 	 FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
	 if ( navtracks.size() != 2 )
	    continue;

	 double phi0_ref, phi0_var; phi0_ref = phi0_var = 0;
	 int num_ref, num_var; num_ref = num_var = 0;

 	 for ( navtracks_iter = navtracks_begin;
 	       navtracks_iter != navtracks_end;
 	       navtracks_iter++ )
 	 {
	    double cotTheta = navtracks_iter->seedTrack()->cotTheta();
	    DABoolean fore = ( cotTheta > 0.42  &&  cotTheta < 0.83 );
	    DABoolean back = ( cotTheta < -0.42  &&  cotTheta > -0.83 );
	    if ( ! fore  &&  ! back )
	       continue;

	    if ( fore )
	    {
	       phi0_f = navtracks_iter->seedTrack()->phi0();
	       num_fore++;
	    }
	    if ( back )
	    {
	       phi0_b = navtracks_iter->seedTrack()->phi0();
	       num_back++;
	    }

 	    const NavTrack::DRHitTable* seedtrack_hits
 	       = navtracks_iter->seedDRHits();
 	    NavTrack::DRHitTable::const_iterator seedtrack_hits_iter;
 	    NavTrack::DRHitTable::const_iterator seedtrack_hits_begin
 	       = seedtrack_hits->begin();
 	    NavTrack::DRHitTable::const_iterator seedtrack_hits_end
 	       = seedtrack_hits->end();
 	    for ( seedtrack_hits_iter = seedtrack_hits_begin;
 		  seedtrack_hits_iter != seedtrack_hits_end;
 		  seedtrack_hits_iter++ )
 	    {
 	       int layer = (* seedtrack_hits_iter)->layer();

	       if ( fore )
		  switch ( layer )
		  {
		     case 1: case 2: cake_hit_fore[ 0 ] = true; break;
		     case 3: case 4: cake_hit_fore[ 1 ] = true; break;
		     case 5: case 6: cake_hit_fore[ 2 ] = true; break;
		     case 7: case 8: cake_hit_fore[ 3 ] = true; break;
		     case 9: case 10: cake_hit_fore[ 4 ] = true; break;
		     case 11: case 12: cake_hit_fore[ 5 ] = true; break;
		     case 13: case 14: cake_hit_fore[ 6 ] = true; break;
		     case 15: case 16: cake_hit_fore[ 7 ] = true; break;
		     default: break;
		  } // end switch layer

	       if ( back )
		  switch ( layer )
		  {
		     case 1: case 2: cake_hit_back[ 0 ] = true; break;
		     case 3: case 4: cake_hit_back[ 1 ] = true; break;
		     case 5: case 6: cake_hit_back[ 2 ] = true; break;
		     case 7: case 8: cake_hit_back[ 3 ] = true; break;
		     case 9: case 10: cake_hit_back[ 4 ] = true; break;
		     case 11: case 12: cake_hit_back[ 5 ] = true; break;
		     case 13: case 14: cake_hit_back[ 6 ] = true; break;
		     case 15: case 16: cake_hit_back[ 7 ] = true; break;
		     default: break;
		  } // end switch layer

 	    } // loop over seedtrack_hits

 	 } // loop over navtracks

	 if ( num_fore == 1  &&  num_back == 1 )
	 {
	    double phi0diff = abs( phi0_f - phi0_b );

	    // this is a crossing angle correction
	    phi0diff += abs( 0.0059095 * sin( phi0_f );

	    h2_phi0diff_v_phi0f->fill( phi0_f, phi0diff );
	    hp_phi0diff_v_phi0f->fill( phi0_f, phi0diff );
	    for ( int i = 0;  i < 8;  i++ )
	       if ( cake_hit_fore[ i ]  &&  cake_hit_back[ i ] )
		  h_phi0diff[ i ]->fill( phi0diff );
	 } // end if one forward-going track and one backward-going track

      } // loop over frames

   } // majora iterations
}

//
// static member functions
//

//  	 try {
//  	    FAItem< SeedTrackDRHitLattice > seedtrack_hit_lattice;
//  	    extract( itFrame->record( Stream::kEvent ), seedtrack_hit_lattice );
//  	 } catch( DAExceptionBase& iException ) {
//  	    report( WARNING, kFacilityString) << iException.what() << endl;
//          continue;
//  	 } // end try-catch block

//  	    report( INFO, kFacilityString )
//  	       << "  curvature = "
//  	       << navtracks_iter->seedTrack()->curvature() << endl;

//  	    const NavTrack::DRHitTable* seedtrack_hits
//  	       = navtracks_iter->seedDRHits();
//  	    NavTrack::DRHitTable::const_iterator seedtrack_hits_iter;
//  	    NavTrack::DRHitTable::const_iterator seedtrack_hits_begin
//  	       = seedtrack_hits->begin();
//  	    NavTrack::DRHitTable::const_iterator seedtrack_hits_end
//  	       = seedtrack_hits->end();
//  	    report( INFO, kFacilityString ) << "track" << endl;
//  	    for ( seedtrack_hits_iter = seedtrack_hits_begin;
//  		  seedtrack_hits_iter != seedtrack_hits_end;
//  		  seedtrack_hits_iter++ )
//  	    {
//  	       int layer = (* seedtrack_hits_iter)->layer();
//  	       if ( layer < 15 )
//  		  report( INFO, kFacilityString )
//  		     << "    layer " << layer << endl;
//  	    } // loop over seedtrack_hits


