class theclass // : public MiFCN
{
      CLEOConstantsModifiable< DBDRGeomAlignment >& m_alignment;
      int m_cake;
      FIFrameIterator m_frame_begin;
      FIFrameIterator m_frame_end;
      int m_max_frames;
};

theclass::constructor( CLEOConstantsModifiable< DBDRGeomAlignment > startingAlignment,
		       int which_cake,
		       const FIFrameIterator& iBegin,
		       const FIFrameIterator& iEnd,
		       int m_max_frames
   ) :
   m_alignment( startingAlignment ),
   m_cake( which_cake ),
   m_frame_begin( iBegin ),
   m_frame_end( iEnd ),
   m_max_frames( max_frames )
{
   // when this is a MiFCN-derived class:
   addInitialParameter( "cake m_cake east X", m_alignment[ m_cake east ].getX_or_whatever() );
   addInitialParameter( "cake m_cake west X", m_alignment[ m_cake west ].getX_or_whatever() );
   addInitialParameter( "cake m_cake east Y", m_alignment[ m_cake east ].getY_or_whatever() );
   addInitialParameter( "cake m_cake west Y", m_alignment[ m_cake west ].getY_or_whatever() );
   addInitialParameter( "cake m_cake east PHIZ", m_alignment[ m_cake east ].getPHIZ_or_whatever() );
   addInitialParameter( "cake m_cake west PHIZ", m_alignment[ m_cake west ].getPHIZ_or_whatever() );
}

void theclass::calculateresiduals( double* values )
{
   // when this si a MiFCN-derived class, minuit will be calling this
   // function, and it will be named iterate( double* values )
   m_alignment[ m_cake east ].set_X_or_whatever( values[ 0 ] );
   m_alignment[ m_cake west ].set_X_or_whatever( values[ 1 ] );
   m_alignment[ m_cake east ].set_Y_or_whatever( values[ 2 ] );
   m_alignment[ m_cake west ].set_Y_or_whatever( values[ 3 ] );
   m_alignment[ m_cake east ].set_PHIZ_or_whatever( values[ 4 ] );
   m_alignment[ m_cake west ].set_PHIZ_or_whatever( values[ 5 ] );

   report( INFO, kFacilityString )
      << "Calculating residuals (and chi^2) with alignment:" << endl;
   report( INFO, kFacilityString )
      << "    east = ( X, Y, PHIZ ) = ( "
      << m_alignment[ m_cake east ].getX_or_whatever() << ", "
      << m_alignment[ m_cake east ].getY_or_whatever() << ", "
      << m_alignment[ m_cake east ].getPHIZ_or_whatever() << " )" << endl;
   report( INFO, kFacilityString )
      << "    west = ( X, Y, PHIZ ) = ( "
      << m_alignment[ m_cake west ].getX_or_whatever() << ", "
      << m_alignment[ m_cake west ].getY_or_whatever() << ", "
      << m_alignment[ m_cake west ].getPHIZ_or_whatever() << " )" << endl;

   // assignment calls resetToBeginning() which clears the proxies and
   // forces the ADRSenseWireStore object to be recalculated using the
   // new constants
   FIFrameIterator itFrame = m_frame_begin;

   FAItem< ADRSenseWireStore > aStore;
   extract( itFrame.record( Stream::kDRAlignment ), aStore );

   HIDRSurfaceFactory drFactory( itFrame, true, true, true, true, aStore );
   STL_VECTOR( HIIntersectionSurface* ) surfaces;
   STL_VECTOR( HIDRSurfaceFactory::DRHitAndDriftDistance ) drhitinfos;

   double chi2 = 0.;
   int num_hits = 0;
   int num_frames = 0;
   for( ; itFrame != m_frame_end; ++itFrame )
   {
      if ( num_frames >= m_max_frames )
	 break;
      num_frames++;

      FAItem< DBEventHeader > header;
      extract( itFrame->record( Stream::kEvent ), header );
      unsigned int run = header->run();
      unsigned int event = header->number();

      if ( run != prevrun )
      {  prevrun = run;
      report( INFO, kFacilityString )
	 << "New run: " << run << endl; }
      // skip bad runs/events here
      // if ( run == ######  &&  event >= ###### )
      //    continue;

      // These tracks come straight from the pds file--- they are
      // untouched by the changes to CLEOConstantsModifiable
      FATable< NavTrack > navtracks;
      extract( itFrame->record( Stream::kEvent ), navtracks );
      FATable< NavTrack >::const_iterator navtracks_iter;
      FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
      FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
      
      for ( navtracks_iter = navtracks_begin;
	    navtracks_iter != navtracks_end;
	    navtracks_iter++ )
      {
	 // temporary code
	 NavTrack::DRHitLinkTable drhitlinktable = navtracks_iter->muonDRHitLinks();
	 report( INFO, kFacilityString )
	    << "Original residuals: (dca, dcaerr, drift, drifterr, residual, residualError)"
	    << endl;
	 for( drhitlink_iter = drhitlinktable.begin();
	      drhitlink_iter != drhitlinktable.end();
	      drhitlink_iter++ )
	 {
	    report( INFO, kFacilityString )
	       << "    ( " << drhitlink_iter->signedDcaToWire()
	       << ", " << drhitlink_iter->signedDcaError()
	       << ", " << drhitlink_iter->signedDriftDistance()
	       << ", " << drhitlink_iter->signedDriftError()
	       << ", " << ( drhitlink_iter->signedDcaToWire() -
			    drhitlink_iter->signedDriftDistance() )
	       << ", " << sqrt( sqr( drhitlink_iter->signedDcaError() ) +
				sqr( drhitlink_iter->signedDriftError() ) )
	       << " )" << endl;
	 } // end loop over DR hit links
	 // end temp

	 const NavTrack::DRHitTable* seedtrack_hits
	    = navtracks_iter->seedDRHits();
	 NavTrack::DRHitTable::const_iterator seedtrack_hits_iter;
	 NavTrack::DRHitTable::const_iterator seedtrack_hits_begin
	    = seedtrack_hits->begin();
	 NavTrack::DRHitTable::const_iterator seedtrack_hits_end
	    = seedtrack_hits->end();
	 for ( seedtrack_hits_iter = seedtrack_hits_begin;
	       seedtrack_hits_iter != seedtrack_hits_end;
	       seedtrack_hits_iter++ )
	 {
	    CalibratedDRHit* drhit = (* seedtrack_hits_iter);
	    int layer = drhit->layer();
	    int cake = 0;
	    switch ( layer )
	    {
	       case 1: case 2: cake = 1;
	       case 3: case 4: cake = 2;
	       case 5: case 6: cake = 3;
	       case 7: case 8: cake = 4;
	       case 9: case 10: cake = 5;
	       case 11: case 12: cake = 6;
	       case 13: case 14: cake = 7;
	       case 15: case 16: cake = 8;
	       default: break;
	    }
	    if ( cake == m_cake )
	    {
	       num_hits++;
	       drhitinfos.push_back(
		  HIDRSurfaceFactory::DRHitAndDriftDistance( drhit, drhit->distance() ) );
	    } // end if this is the right cake
	 } // end loop over seedtrack hits

	 // temporary code
	 report( INFO, kFacilityString )
	    << "Recalculated parameters: (dca, dcaerr, drift, drifterr, residual, residualErr)"
	    << endl;
	 // end temp

	 drFactory.generateSingleWireSurfaces( surfaces, drhitinfos, NULL );
	 STL_VECTOR( HIIntersectionSurface* )::const_iterator surfaces_iter;
	 STL_VECTOR( HIIntersectionSurface* )::const_iterator surfaces_begin
	    = surfaces.begin();
	 STL_VECTOR( HIIntersectionSurface* )::const_iterator surfaces_end
	    = surfaces.end();
	 for ( surfaces_iter = surfaces_begin;
	       surfaces_iter != surfaces_end;
	       surfaces_iter++ )
	 {
	    Meters dca = surfaces_iter->dca( navtracks_iter->muonHelix() );
	    Meters drift = surfaces_iter->measuredDca();
	    Meters residual = dca - drift;

	    // look at notes to see how to calculate residual error
	    // actually, look in letter_to_wsun.cc
	    // Meters residErr2 = ...;

	    // temporary code
	    report( INFO, kFacilityString )
	       << "    ( " << dca
	       << ", ---" // << sqrt( dcaError2 )
	       << ", " << drift
	       << ", ---" // I won't be calculating drifterr
	       << ", " << residual
	       << ", ---" // << residualError
	       << " )" << endl;
	    // end temp
	    
	    // if ( residErr2 > 0. )
	    chi2 += sqr( residual ); //  / residErr2;
	 } // end loop over surfaces

	 drhitinfos.clear();
	 surfaces.clear();
      } // end loop over tracks

      report( INFO, kFacilityString )
	 << "chi^2 / dof = " << chi2 << " / " << ( num_hits - 6 )
	 << " = " << ( chi2 / ( num_hits - 6 ) ) << endl;
      
   } // end loop over frames

}
