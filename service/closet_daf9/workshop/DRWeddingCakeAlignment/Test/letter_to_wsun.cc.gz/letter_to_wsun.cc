//  From: Jim McCann <mccann@watson.org>
//  To: Werner Sun <wsun@mail.lns.cornell.edu>
//  Cc: 
//  Bcc: 
//  Subject: calculating residuals by hand
//  Reply-To: 

//  Hi! I will be minimizing residuals in an iterator but don't have the
//  time to run the track fitter repeatedly between iterations. So I will
//  need to calculate residuals (and probably residual errors) on my own
//  given a set of hits and a track. This is how I expect to be able to do
//  it: I have been advised to run this past you first.

{
   // by this point in the code, I have changed my geometry constants
   // I am in a function that will be called repeatedly by MINUIT
   
   // assignment calls resetToBeginning() which clears the proxies and
   // forces the ADRSenseWireStore object to be recalculated using the
   // new constants
   FIFrameIterator itFrame = m_frame_begin;

   FAItem< ADRSenseWireStore > aStore;
   extract( itFrame.record( Stream::kDRAlignment ), aStore );

   HIDRSurfaceFactory drFactory( itFrame, true, true, true, true, aStore );
   STL_VECTOR( HIIntersectionSurface* ) surfaces;
   STL_VECTOR( HIDRSurfaceFactory::DRHitAndDriftDistance ) drhitinfos;

   double chi2 = 0.;
   for( ; itFrame != m_frame_end; ++itFrame )
   {
      // These tracks come straight from the pds file--- they are
      // untouched by the changes to CLEOConstantsModifiable
      FATable< NavTrack > navtracks;
      extract( itFrame->record( Stream::kEvent ), navtracks );
      FATable< NavTrack >::const_iterator navtracks_iter;
      FATable< NavTrack >::const_iterator navtracks_begin = navtracks.begin();
      FATable< NavTrack >::const_iterator navtracks_end = navtracks.end();
      
      for ( navtracks_iter = navtracks_begin;
            navtracks_iter != navtracks_end;
            navtracks_iter++ )
      {
	 HIHelix helix = navtracks_iter->muonHelix();

	 const NavTrack::DRHitTable* seedtrack_hits
	    = navtracks_iter->seedDRHits();
	 NavTrack::DRHitTable::const_iterator seedtrack_hits_iter;
	 NavTrack::DRHitTable::const_iterator seedtrack_hits_begin
	    = seedtrack_hits->begin();
	 NavTrack::DRHitTable::const_iterator seedtrack_hits_end
	    = seedtrack_hits->end();
	 for ( seedtrack_hits_iter = seedtrack_hits_begin;
	       seedtrack_hits_iter != seedtrack_hits_end;
	       seedtrack_hits_iter++ )
	 {
	    CalibratedDRHit* drhit = (* seedtrack_hits_iter);
            if ( this is a hit I want to use )
            {
	       num_hits++;
	       drhitinfos.push_back(
		  HIDRSurfaceFactory::DRHitAndDriftDistance( drhit, drhit->distance() ) );
            } // end if interesting
         } // end loop over hits

	 drFactory.generateMultiWireSurfaces( surfaces, drhitinfos, NULL );

	 HIHelixIntersector intersector(
	    surfaces, HIHelixIntersector::kIncreasingRadius, helix );
	 HIHelixIntersector::IntersectionStatus status =
	    intersector.swimToCurrentSurface( KTMoveControl::kDirectionForward );
	 do { 
	    do {
	       HIIntersectionSurface* surface = currentSurface();

	       Meters dca = surface->dca( helix );
	       Meters drift = surface->measuredDca();
	       Meters residual = dca - drift;
	       
	       double e_drift2 = 1. / surface->fittingWeight();

	       HepVector derivs( HIHelix::kNTrackParameters );
	       surface->derivatives( trackHelix, derivs );
	       double e_dca2 = helix.errorMatrix().similarity( derivs );

	       chi2 += sqr( residual ) / ( e_drift2 + e_dca2 );
	    } while ( surface->advanceToNextCalibratedHit( helix ) );
	 } while ( intersector.swimToNextIntersection( ) == HIHelixIntersector::kIntersectionOK )

	 drhitinfos.clear();
	 surfaces.clear();
      } // end loop over tracks
   } // end loop over frames (events)

   // now I have my chi^2, calculated as a quadrature sum over residuals
}

//  //  ======================================================================

//  //  If I want chi^2 to be a sum over normalized residuals, I would do
//  //  something like this:

//  {
//     // in a track loop, but not a hit or surface loop yet
   
//     if ( trackHelix.hasNullErrorMatrix() )
//        give up;

//     HepVector dParams = trackHelix->trackParameterCorrections();
//     HepSymMatrix transportedError = trackHelix->errorMatrix();

//     // this replaces the loop over surfaces given above:
//     drFactory.generateSingleWireSurfaces( surfaces, drhitinfos, NULL );
//     STL_VECTOR( HIIntersectionSurface* )::const_iterator surfaces_iter;
//     STL_VECTOR( HIIntersectionSurface* )::const_iterator surfaces_begin
//        = surfaces.begin();
//     STL_VECTOR( HIIntersectionSurface* )::const_iterator surfaces_end
//        = surfaces.end();
//     for ( surfaces_iter = surfaces_begin;
//  	 surfaces_iter != surfaces_end;
//  	 surfaces_iter++ )
//     {
//        if ( surfaces_iter->hiCalibratedHit() == 0  ||
//  	   surfaces_iter->hiCalibratedHit()->infoOnTrack() )
//  	 continue;

//        HepVector derivs( HIHelix::kNTrackParameters );
//        surfaces_iter->derivatives( trackHelix, derivs );

//        HepVector VD( HIHelix::kNTrackParameters, 0 );
//        for ( int m = 0;  m <= HIHelix::kNTrackParameters;  m++ )
//  	 for ( int n = 0;  n <= HIHelix::kNTrackParameters;  n++ )
//  	    VD( m ) += transportedError( m, n ) * derivs( n );

//        sigma2 = 1. / surfaces_iter->fittingWeight();
//        HepSymMatrix VDDtV( HIHelix::kNTrackParameters );
	    
//        Meters dPredicted = surfaces_iter->dca( trackHelix );
//        double dPredError2 = 0.;
//        for ( int i = 0;  i <= HIHelix::kNTrackParameters;  i++ )
//        {
//  	 double derivi = derivs( i );
//  	 dPredicted += derivi * dParams( i );
//  	 dPredError2 += sqr( derivi ) * transportedError.fast( i, i );
//  	 VDDtV.fast( i, i ) = sqr( VD( i ) );
//  	 for ( int j = i + 1;  j <= HIHelix::kNTrackParameters;  j++ )
//  	 {
//  	    VDDtV.fast( j, i ) = VD( j ) * VD( i );
//  	    dPredError2 += 2 * derivi * derivs( j ) * transportedError.fast( j, i );
//  	 }
//        }
      
//        double residualError2 = sigma2 + dPredError2;
//        Meters dMeasured = surfaces_iter->measuredDca();
//        Meters residual = dMeasured - dPredicted;

//        // Now this is where I use what was calculated
//        chi2 += sqr( residual ) / residualError2;

//     } // end loop over surfaces

//  // now I have my chi^2, calculated as a quadrature sum over normalized
//  // residuals
//  }

//  //  ======================================================================

//  //  Is this right? I have tried to stick close to your code, taking only
//  //  what I need, even preserving the variable names. The algorithm I'll be
//  //  sure to double-check and triple-check, but what I wanted to run by you
//  //  is the appropriateness of this code segment. Is it the right one? Will
//  //  this use of looping over a vector of surfaces work as well as your
//  //  aSurface.advanceToNextCalibratedHit( trackHelix ) over a multi-wire
//  //  surface?

//  //  Thanks!

//  //  ===================================================
//  //     Jim McCann
//  //     Physics graduate student, Cornell University
//  //     mailto:mccann@watson.org
//  //     http://www.watson.org/~mccann/home/page.cgi

