// -*- C++ -*-
//
// Package:     EnderSiAlignment
// Module:      EnderSiAlignment
// 
// Description: <one line class summary>
//
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim McCann
// Created:     Thu Sep 13 11:19:02 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

#include "Experiment/Experiment.h"

// system include files

// user include files
#include "EnderSiAlignment/EnderSiAlignment.h"
#include "Experiment/report.h"
#include "Experiment/units.h"  // for converting to/from standard CLEO units

#include "DataHandler/Record.h"
#include "DataHandler/Frame.h"
#include "FrameAccess/extract.h"
#include "FrameAccess/FAItem.h"
#include "FrameAccess/FATable.h"

//RICH example 
//Dedx example
//Event Shape example


// STL classes
// You may have to uncomment some of these or other stl headers 
// depending on what other header files you include (e.g. FrameAccess etc.)!
//#include <string>
//#include <vector>
//#include <set>
//#include <map>
//#include <algorithm>
//#include <utility>

//
// constants, enums and typedefs
//
static const char* const kFacilityString = "Processor.EnderSiAlignment" ;

// ---- cvs-based strings (Id and Tag with which file was checked out)
static const char* const kIdString  = "$Id: processor.cc,v 1.21 2001/09/01 22:44:37 llh14 Exp $";
static const char* const kTagString = "$Name: v06_00_00 $";

//
// static data member definitions
//

//
// constructors and destructor
//
EnderSiAlignment::EnderSiAlignment( void )               // anal1
   : Processor( "EnderSiAlignment" )
     , m_siSurfaceFactory( NULL )
     , m_store( NULL )
{
   report( DEBUG, kFacilityString ) << "here in ctor()" << endl;

   // ---- bind a method to a stream -----
   // These lines ARE VERY IMPORTANT! If you don't bind the 
   // code you've just written (the "action") to a stream, 
   // your code won't get executed!

   bind( &EnderSiAlignment::event,    Stream::kEvent );
   //bind( &EnderSiAlignment::beginRun, Stream::kBeginRun );
   //bind( &EnderSiAlignment::endRun,   Stream::kEndRun );

   // do anything here that needs to be done at creation time
   // (e.g. allocate resources etc.)

}

EnderSiAlignment::~EnderSiAlignment()                    // anal5
{
   report( DEBUG, kFacilityString ) << "here in dtor()" << endl;
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}

//
// member functions
//

// ------------ methods for beginning/end "Interactive" ------------
// --------------------------- init method -------------------------
void
EnderSiAlignment::init( void )          // anal1 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in init()" << endl;

   // do any initialization here based on Parameter Input by User
   // (e.g. run expensive algorithms that are based on parameters
   //  specified by user at run-time)

}

// -------------------- terminate method ----------------------------
void
EnderSiAlignment::terminate( void )     // anal5 "Interactive"
{
   report( DEBUG, kFacilityString ) << "here in terminate()" << endl;

   // do anything here BEFORE New Parameter Change
   // (e.g. write out result based on parameters from user-input)

}

// ---------------- standard place to book histograms ---------------
void
EnderSiAlignment::hist_book( HIHistoManager& iHistoManager )
{
   report( DEBUG, kFacilityString ) << "here in hist_book()" << endl;

   // book your histograms here

   const char* rphi_ntuple_labels[] = { "ladder", "sensor", "xresid", "z" };
   const char* z_ntuple_labels[] = { "ladder", "sensor", "zresid", "cotTheta" };

   m_rphi_ntuple = iHistoManager.ntuple(
      1, "rphi", 4, 262144, rphi_ntuple_labels );
   m_z_ntuple = iHistoManager.ntuple(
      2, "z", 4, 262144, z_ntuple_labels );

}

// --------------------- methods bound to streams -------------------
ActionBase::ActionResult
EnderSiAlignment::event( Frame& iFrame )          // anal3 equiv.
{
   report( DEBUG, kFacilityString ) << "here in event()" << endl;

   if ( m_store == NULL )
   {
      FAItem< ASiStore > store;
      extract( iFrame.record( Stream::kSVAlignment ), store );
      assert( store.valid() );
      m_store = &( (* store) );
   }

   if ( m_siSurfaceFactory == NULL )
      m_siSurfaceFactory = new HISiSurfaceFactory( iFrame, 0, 0, false );

   FATable< NavTrack > navtracks;
   extract( iFrame.record( Stream::kEvent ), navtracks );
   FATable< NavTrack >::const_iterator nav_iter;
   FATable< NavTrack >::const_iterator nav_begin = navtracks.begin();
   FATable< NavTrack >::const_iterator nav_end = navtracks.end();
   FATable< DualTrackHelices > dualtracks;
   extract( iFrame.record( Stream::kEvent ), dualtracks );
   FATable< DualTrackHelices >::const_iterator dualtracks_iter;

   // be sure that we have exactly two good tracks
   if ( navtracks.size() != 2 ) return ActionBase::kFailed;;
   if ( ( nav_iter = nav_begin )->muonQuality()->fitAbort() ) return ActionBase::kFailed;;
   if ( abs( nav_iter->muonHelix()->cotTheta() ) > 1.25 ) return ActionBase::kFailed;;
   if ( nav_iter->seedSVRHits()->size() <= 1 ) return ActionBase::kFailed;;
   if ( nav_iter->seedSVZHits()->size() <= 1 ) return ActionBase::kFailed;;
   if ( ( ++nav_iter )->muonQuality()->fitAbort() ) return ActionBase::kFailed;;
   if ( abs( nav_iter->muonHelix()->cotTheta() ) > 1.25 ) return ActionBase::kFailed;;
   if ( nav_iter->seedSVRHits()->size() <= 1 ) return ActionBase::kFailed;;
   if ( nav_iter->seedSVZHits()->size() <= 1 ) return ActionBase::kFailed;;

   // with no final-state radiation (well, very little... this is
   // one of those infrared divergences, isn't it?
   HepVector3D event_momentum =
   ( ( nav_iter = nav_begin )->muonFit()->momentum() +
     ( ++nav_iter )->muonFit()->momentum() );
   double xdiff2 = sqr( event_momentum.x() + 0.0261 );
   double ydiff2 = sqr( event_momentum.y() + 0.0003 );
   if ( ( xdiff2 + ydiff2 ) > 0.300 ) return ActionBase::kFailed;;
//        if ( abs( ( nav_iter = nav_begin )->muonHelix()->curvature() +
//  		( ++nav_iter )->muonHelix()->curvature()             )
//  	   > 4E-3 ) return ActionBase::kFailed;;
   
   // This is getting a little rediculous...
   if ( ( ( nav_iter = nav_begin )->muonHelix()->curvature() ) *
	( ( ++ nav_iter )->muonHelix()->curvature() ) > 0. ) return ActionBase::kFailed;;
   
   report( DEBUG, kFacilityString ) << "this is a good event." << endl;
   
   for ( nav_iter = nav_begin;  nav_iter != nav_end;  nav_iter++ )
   {
      dualtracks_iter = dualtracks.find( nav_iter->identifier() );

      // Toggle comments for single/dual track fits
//        HIHelix copy_helix( (* nav_iter->muonHelix() ),
//  			  DBCandidate::mass( DBCandidate::Hypo( DBCandidate::kMuon ) ) );
      HIHelix copy_helix( dualtracks_iter->helix() );
      double cotTheta = copy_helix.cotTheta();

      report( DEBUG, kFacilityString )
	 << "Using the following helix: curv = " << copy_helix.curvature()
	 << " cotTheta = " << copy_helix.cotTheta() << " d0 = " << copy_helix.d0()
	 << " z0 = " << copy_helix.z0() << " phi0 = " << copy_helix.phi0() << endl;

      const NavTrack::SVRHitTable* rphi_hits = nav_iter->seedSVRHits();
      const NavTrack::SVZHitTable* z_hits = nav_iter->seedSVZHits();

      if ( rphi_hits->size() == 0  &&  z_hits->size() == 0 ) continue;

      m_siSurfaceFactory->generateCenterSurfacesWithHits( *rphi_hits, *z_hits, 0 );
      report( DEBUG, kFacilityString ) << "generated surfaces" << endl;

      vector< HIIntersectionSurface* > surfaces;
      m_siSurfaceFactory->transferSurfacesTo( surfaces, false );
      report( DEBUG, kFacilityString ) << "transferred surfaces" << endl;
      
      vector< HIIntersectionSurface* >::const_iterator surfaces_iter;
      vector< HIIntersectionSurface* >::const_iterator surfaces_begin = surfaces.begin();
      vector< HIIntersectionSurface* >::const_iterator surfaces_end = surfaces.end();

      vector< HIIntersectionSurface* > composite_surface;
      composite_surface.push_back( (* surfaces_begin) );
      vector< HIIntersectionSurface* >::const_iterator
	 composite_surface_begin = composite_surface.begin();
      report( DEBUG, kFacilityString )
	 << "pushed first surface onto composite" << endl;
      for ( surfaces_iter = surfaces_begin, surfaces_iter++;
	    surfaces_iter != surfaces_end;
	    surfaces_iter++ )
      {
	 HICompositeSurface* tmp_surface
	    = ( (HICompositeSurface*) (* surfaces_iter) );
	 ( (HICompositeSurface*) (* composite_surface_begin) )
	    ->addChildren( *tmp_surface );
      }
      report( DEBUG, kFacilityString ) << "made composite surface" << endl;

      HIHelixIntersector intersector( composite_surface,
				      HIHelixIntersector::kIncreasingRadius,
				      &copy_helix );
      report( DEBUG, kFacilityString ) << "created intersector" << endl;

      for ( HIHelixIntersector::IntersectionStatus status =
	       intersector.swimToCurrentSurface(
		  KTMoveControl::kDirectionForward );
	    status == HIHelixIntersector::kIntersectionOK;
	    status = intersector.swimToNextIntersection(
	       KTMoveControl::kDirectionForward ) )
      {
	 HIIntersectionSurface* surface = intersector.currentSurface();
	 report( DEBUG, kFacilityString )
	    << "  sub-surface in the composite surface" << endl;
	 
	 do { 
	    report( DEBUG, kFacilityString )
	       << "    hit in the sub-surface" << endl;
	    double phi = copy_helix.phi0();
	    double z = copy_helix.position().z();

	    const CalibratedHit* hit = surface->calibratedHit();
	    int sensor = ( (CalibratedSVHit*) (hit) )->sensor();
	    int ladder = m_store->ladderForSensor( sensor );
	    int layer = m_store->layerForSensor( sensor );
	    int layerOrClam = layer;
	    if ( layer == 1  ||  layer == 2 )
	       layerOrClam = m_store->clamshellForHybrid(
		  ( (CalibratedSVHit*) (hit) )->hybrid() );

	    report( DEBUG, kFacilityString )
	       << "    layerOrClam = " << layerOrClam
	       << ", ladder = " << ladder
	       << ", sensor = " << sensor << endl;
	    
	    double residual = surface->dca( copy_helix );
	    
	    if ( hit->deviceType() == CalibratedHit::SVR )
	    {
	       report( DEBUG, kFacilityString )
		  << "    rphi hit (" << layerOrClam
		  << ", " << ladder << ", " << sensor
		  << ") residual = " << residual
		  << " at phi = " << phi << ", z = " << z << endl;

	       float rphivars[] = { float( ladder ), float( sensor ), residual, z };
	       m_rphi_ntuple->fill( rphivars );
	    }
	    else if ( hit->deviceType() == CalibratedHit::SVZ )
	    {
	       report( DEBUG, kFacilityString )
		  << "    z hit (" << layerOrClam
		  << ", " << ladder << ", " << sensor
		  << ") residual = " << residual
		  << " at phi = " << phi << ", z = " << z << endl;
	       
	       float zvars[] = { float( ladder ), float( sensor ), residual, cotTheta };
	       m_z_ntuple->fill( zvars );
	    }

	 } while ( surface->advanceToNextCalibratedHit( copy_helix ) );
      } // end loop over surfaces
      
      report( DEBUG, kFacilityString ) << "deleting surfaces" << endl;
      for ( surfaces_iter = surfaces_begin;
	    surfaces_iter != surfaces_end;
	    surfaces_iter++ )
      {
	 (* surfaces_iter)->deleteCondition();
	 delete (* surfaces_iter );
      }

   } // end of track loop

   return ActionBase::kPassed;
}

/*
ActionBase::ActionResult
EnderSiAlignment::beginRun( Frame& iFrame )       // anal2 equiv.
{
   report( DEBUG, kFacilityString ) << "here in beginRun()" << endl;

   return ActionBase::kPassed;
}
*/

/*
ActionBase::ActionResult
EnderSiAlignment::endRun( Frame& iFrame )         // anal4 equiv.
{
   report( DEBUG, kFacilityString ) << "here in endRun()" << endl;

   return ActionBase::kPassed;
}
*/

//
// const member functions
//

//
// static member functions
//
