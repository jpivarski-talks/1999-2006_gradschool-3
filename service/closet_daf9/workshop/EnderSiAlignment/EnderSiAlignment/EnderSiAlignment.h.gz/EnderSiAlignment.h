// -*- C++ -*-
#if !defined(ENDERSIALIGNMENT_ENDERSIALIGNMENT_H)
#define ENDERSIALIGNMENT_ENDERSIALIGNMENT_H
//
// Package:     <EnderSiAlignment>
// Module:      EnderSiAlignment
//
/**\class EnderSiAlignment EnderSiAlignment.h EnderSiAlignment/EnderSiAlignment.h
 
 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      Jim McCann
// Created:     Thu Sep 13 11:19:01 EDT 2001
// $Id$
//
// Revision history
//
// $Log$
//

// system include files

// user include files
#include "Processor/Processor.h"
#include "HistogramInterface/HistogramPackage.h"
#include "CommandPattern/Parameter.h"

#include "ASiStorePro/ASiStore.h"
#include "SiHits/CalibratedSVRphiHit.h"
#include "SiHits/CalibratedSVZHit.h"
#include "Navigation/NavTrack.h"
#include "HelixIntersection/HIHelix.h"

#include "/home/mccann/workshop/DualTrackHelices/DualTrackHelices/DualTrackHelices.h"

#include "HelixIntersection/HIHelixIntersector.h"
#include "HelixIntersection/HIIntersectionSurface.h"
#include "HelixIntersection/HISiSurfaceFactory.h"
#include "HelixIntersection/HICompositeSurface.h"
#include "KinematicTrajectory/KTHelix.h"
#include "KinematicTrajectory/KTKinematicData.h"

// forward declarations

class EnderSiAlignment : public Processor
{
      // ------------ friend classses and functions --------------

   public:
      // ------------ constants, enums and typedefs --------------
      typedef unsigned int uint;

      // ------------ Constructors and destructor ----------------
      EnderSiAlignment( void );                      // anal1 
      virtual ~EnderSiAlignment();                   // anal5 

      // ------------ member functions ---------------------------

      // methods for beginning/end "Interactive"
      virtual void init( void );             // anal1 "Interactive"
      virtual void terminate( void );        // anal5 "Interactive"

      // standard place for booking histograms
      virtual void hist_book( HIHistoManager& );                  

      // methods for binding to streams (anal2-4 etc.)
      virtual ActionBase::ActionResult event( Frame& iFrame );
      //virtual ActionBase::ActionResult beginRun( Frame& iFrame);
      //virtual ActionBase::ActionResult endRun( Frame& iFrame);
      //virtual ActionBase::ActionResult geometry( Frame& iFrame);
      //virtual ActionBase::ActionResult hardware( Frame& iFrame);
      //virtual ActionBase::ActionResult user( Frame& iFrame);

      // ------------ const member functions ---------------------

      // ------------ static member functions --------------------

   protected:
      // ------------ protected member functions -----------------

      // ------------ protected const member functions -----------

   private:
      // ------------ Constructors and destructor ----------------
      EnderSiAlignment( const EnderSiAlignment& );

      // ------------ assignment operator(s) ---------------------
      const EnderSiAlignment& operator=( const EnderSiAlignment& );

      // ------------ private member functions -------------------
      void bind( 
         ActionBase::ActionResult (EnderSiAlignment::*iMethod)( Frame& ),
	      const Stream::Type& iStream );

      // ------------ private const member functions -------------

      // ------------ data members -------------------------------

      HISiSurfaceFactory* m_siSurfaceFactory;
      const ASiStore* m_store;

      HINtuple* m_rphi_ntuple;
      HINtuple* m_z_ntuple;

      // ------------ static data members ------------------------

};

// inline function definitions

#endif /* ENDERSIALIGNMENT_ENDERSIALIGNMENT_H */
