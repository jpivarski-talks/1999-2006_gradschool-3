#ifndef Rio_Seek_h
#define Rio_Seek_h

//////////////////////////////////////////////////////////////////////////
// Definition of a file pointer .                                       //
//////////////////////////////////////////////////////////////////////////

namespace Rio {

// If changing the belo, have to change the return
// value of IDirectory::seekDirectory.

typedef int Seek;

}

#endif
